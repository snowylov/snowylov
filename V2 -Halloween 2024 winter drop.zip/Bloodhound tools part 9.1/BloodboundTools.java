package com.alex.bloodboundtools;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.client.itemgroup.FabricItemGroupBuilder;
import net.fabricmc.fabric.api.tag.TagFactory;
import net.minecraft.item.*;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.world.World;
import net.minecraft.util.math.BlockPos;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.recipe.Ingredient;
import net.minecraft.recipe.RecipeType;
import net.minecraft.recipe.ShapedRecipe;
import net.minecraft.recipe.book.RecipeCategory;
import net.minecraft.tag.TagKey;
import net.minecraft.util.collection.DefaultedList;

import java.util.ArrayList;
import java.util.List;

public class BloodboundTools implements ModInitializer {
    public static final String MOD_ID = "bloodboundtools";
    public static final Item BLOOD_BANK = new BloodBankItem(new FabricItemSettings().group(ItemGroup.MISC));

    // Define Tags
    public static final TagKey<Item> BLOODBOUND_TOOLS_TAG_C = TagKey.of(Registry.ITEM_KEY, new Identifier(MOD_ID, "c:bloodbound_tools"));
    public static final TagKey<Item> BLOODBOUND_TOOLS_TAG_SMALL_C = TagKey.of(Registry.ITEM_KEY, new Identifier(MOD_ID, "bloodbound_tools"));
    public static final TagKey<Item> BLOOD_BANK_TAG_C = TagKey.of(Registry.ITEM_KEY, new Identifier(MOD_ID, "c:blood_bank"));
    public static final TagKey<Item> BLOOD_BANK_TAG_SMALL_C = TagKey.of(Registry.ITEM_KEY, new Identifier(MOD_ID, "blood_bank"));

    @Override
    public void onInitialize() {
        Registry.register(Registry.ITEM, new Identifier(MOD_ID, "blood_bank"), BLOOD_BANK);
        Registry.register(Registry.ITEM, new Identifier(MOD_ID, "bloodbound_sword"), BLOODBOUND_SWORD);
        Registry.register(Registry.ITEM, new Identifier(MOD_ID, "bloodbound_hoe"), BLOODBOUND_HOE);
        Registry.register(Registry.ITEM, new Identifier(MOD_ID, "bloodbound_pickaxe"), BLOODBOUND_PICKAXE);
        Registry.register(Registry.ITEM, new Identifier(MOD_ID, "bloodbound_shovel"), BLOODBOUND_SHOVEL);
        Registry.register(Registry.ITEM, new Identifier(MOD_ID, "bloodbound_axe"), BLOODBOUND_AXE);

        // Registering crafting recipes
        addRecipes();

        // Generate item models
        generateItemModels();

        // Add Items to Tags
        addItemsToTags();
    }

    // BloodBankItem Class
    public static class BloodBankItem extends Item {
        public BloodBankItem(Settings settings) {
            super(settings);
        }

        @Override
        public boolean postHit(ItemStack stack, LivingEntity target, LivingEntity attacker) {
            if (!attacker.world.isClient) {
                int healthToDrain = (int) target.getHealth();
                target.damage(DamageSource.GENERIC, healthToDrain);
                storeHealthInBloodBank(stack, healthToDrain);
            }
            return super.postHit(stack, target, attacker);
        }

        private void storeHealthInBloodBank(ItemStack stack, int health) {
            NbtCompound nbt = stack.getOrCreateNbt();
            int currentHealth = nbt.getInt("health");
            nbt.putInt("health", currentHealth + health);
        }

        public static int getAvailableHealth(ItemStack stack) {
            NbtCompound nbt = stack.getOrCreateNbt();
            return nbt.getInt("health");
        }
    }

    // Interface IBloodBank
    public interface IBloodBank {
        default void useBloodForDurability(ItemStack toolStack, ItemStack bloodBankStack) {
            int availableHealth = BloodBankItem.getAvailableHealth(bloodBankStack);
            if (availableHealth > 0 && toolStack.isDamaged()) {
                int repairAmount = Math.min(availableHealth, toolStack.getDamage());
                toolStack.setDamage(toolStack.getDamage() - repairAmount);

                // Update the blood bank NBT
                NbtCompound nbt = bloodBankStack.getOrCreateNbt();
                nbt.putInt("health", availableHealth - repairAmount);
            }
        }
    }

    // Bloodbound Sword that Implements IBloodBank and Gathers Blood
    public static class BloodboundSword extends Item implements IBloodBank {
        public BloodboundSword(Settings settings) {
            super(settings);
        }

        @Override
        public boolean postHit(ItemStack stack, LivingEntity target, LivingEntity attacker) {
            if (!attacker.world.isClient) {
                int healthToDrain = (int) target.getHealth();
                target.damage(DamageSource.GENERIC, healthToDrain);
                Hand[] hands = Hand.values();
                for (Hand hand : hands) {
                    ItemStack heldItem = attacker.getStackInHand(hand);
                    if (heldItem.getItem() instanceof BloodBankItem) {
                        NbtCompound nbt = heldItem.getOrCreateNbt();
                        int currentHealth = nbt.getInt("health");
                        nbt.putInt("health", currentHealth + healthToDrain);
                    }
                }
            }
            return super.postHit(stack, target, attacker);
        }
    }

    // Add crafting recipes for blood bank and tools
    private void addRecipes() {
        // Blood Bank Recipe
        DefaultedList<Ingredient> bloodBankIngredients = DefaultedList.ofSize(9, Ingredient.EMPTY);
        bloodBankIngredients.set(0, Ingredient.ofItems(Items.REDSTONE_BLOCK));
        bloodBankIngredients.set(1, Ingredient.ofItems(Items.REDSTONE_BLOCK));
        bloodBankIngredients.set(2, Ingredient.ofItems(Items.REDSTONE_BLOCK));
        bloodBankIngredients.set(3, Ingredient.ofItems(Items.NETHERITE_INGOT));
        bloodBankIngredients.set(4, Ingredient.ofItems(Items.DIAMOND));
        bloodBankIngredients.set(5, Ingredient.ofItems(Items.NETHERITE_INGOT));
        bloodBankIngredients.set(6, Ingredient.ofItems(Items.REDSTONE_BLOCK));
        bloodBankIngredients.set(7, Ingredient.ofItems(Items.REDSTONE_BLOCK));
        bloodBankIngredients.set(8, Ingredient.ofItems(Items.REDSTONE_BLOCK));
        Registry.register(Registry.RECIPE_SERIALIZER, new Identifier(MOD_ID, "blood_bank"), new ShapedRecipe(new Identifier(MOD_ID, "blood_bank"), "", new RecipeCategory(ItemGroup.MISC), 3, 3, bloodBankIngredients, new ItemStack(BLOOD_BANK)).setSerializer(RecipeType.CRAFTING));

        // Bloodbound Tool Recipes
        addToolRecipe("bloodbound_sword", Items.DIAMOND_SWORD, BLOODBOUND_SWORD);
        addToolRecipe("bloodbound_pickaxe", Items.DIAMOND_PICKAXE, BLOODBOUND_PICKAXE);
        addToolRecipe("bloodbound_axe", Items.DIAMOND_AXE, BLOODBOUND_AXE);
        addToolRecipe("bloodbound_shovel", Items.DIAMOND_SHOVEL, BLOODBOUND_SHOVEL);
        addToolRecipe("bloodbound_hoe", Items.DIAMOND_HOE, BLOODBOUND_HOE);
    }

    private void addToolRecipe(String name, Item baseTool, Item resultTool) {
        DefaultedList<Ingredient> ingredients = DefaultedList.ofSize(3, Ingredient.EMPTY);
        ingredients.set(0, Ingredient.ofItems(baseTool));
        ingredients.set(1, Ingredient.ofItems(BLOOD_BANK));
        ingredients.set(2, Ingredient.ofItems(Items.DIAMOND));
        Registry.register(Registry.RECIPE_SERIALIZER, new Identifier(MOD_ID, name), new ShapedRecipe(new Identifier(MOD_ID, name), "", new RecipeCategory(ItemGroup.TOOLS), 1, 3, ingredients, new ItemStack(resultTool)).setSerializer(RecipeType.CRAFTING));
    }

    // Bloodbound Hoe that Implements IBloodBank
    public static class BloodboundHoe extends HoeItem implements IBloodBank {
        public BloodboundHoe(ToolMaterial material, int attackDamage, float attackSpeed, Settings settings) {
            super(material, attackDamage, attackSpeed, settings);
        }
    }

    // Bloodbound Pickaxe that Implements IBloodBank
    public static class BloodboundPickaxe extends PickaxeItem implements IBloodBank {
        public BloodboundPickaxe(ToolMaterial material, int attackDamage, float attackSpeed, Settings settings) {
            super(material, attackDamage, attackSpeed, settings);
        }
    }

    // Bloodbound Shovel that Implements IBloodBank
    public static class BloodboundShovel extends ShovelItem implements IBloodBank {
        public BloodboundShovel(ToolMaterial material, float attackDamage, float attackSpeed, Settings settings) {
            super(material, attackDamage, attackSpeed, settings);
        }
    }

    // Bloodbound Axe that Implements IBloodBank
    public static class BloodboundAxe extends AxeItem implements IBloodBank {
        public BloodboundAxe(ToolMaterial material, float attackDamage, float attackSpeed, Settings settings) {
            super(material, attackDamage, attackSpeed, settings);
        }
    }

    // Register the Bloodbound Sword
    public static final Item BLOODBOUND_SWORD = new BloodboundSword(new FabricItemSettings().group(ItemGroup.COMBAT).maxDamage(800));
    // Register the Bloodbound Hoe
    public static final Item BLOODBOUND_HOE = new BloodboundHoe(ToolMaterials.DIAMOND, -1, -2.0F, new FabricItemSettings().group(ItemGroup.TOOLS).maxDamage(800));
    // Register the Bloodbound Pickaxe
    public static final Item BLOODBOUND_PICKAXE = new BloodboundPickaxe(ToolMaterials.DIAMOND, 1, -2.8F, new FabricItemSettings().group(ItemGroup.TOOLS).maxDamage(800));
    // Register the Bloodbound Shovel
    public static final Item BLOODBOUND_SHOVEL = new BloodboundShovel(ToolMaterials.DIAMOND, 1.5F, -3.0F, new FabricItemSettings().group(ItemGroup.TOOLS).maxDamage(800));
    // Register the Bloodbound Axe
    public static final Item BLOODBOUND_AXE = new BloodboundAxe(ToolMaterials.DIAMOND, 6.0F, -3.1F, new FabricItemSettings().group(ItemGroup.TOOLS).maxDamage(800));

    // Generate Item Models for all Tools and Blood Bank
    private void generateItemModels() {
    if (getAvailableHealth(new ItemStack(BLOOD_BANK)) > 0) {
        generateItemModel("blood_bank", "textures/item/blood_bank_filled.png");
    } else {
        generateItemModel("blood_bank", "textures/item/blood_bank_empty.png");
    }

        // Bloodbound Tools Item Models
        generateItemModel("bloodbound_sword", "textures/item/bloodbound_sword.png");
        generateItemModel("bloodbound_hoe", "textures/item/bloodbound_hoe.png");
        generateItemModel("bloodbound_pickaxe", "textures/item/bloodbound_pickaxe.png");
        generateItemModel("bloodbound_shovel", "textures/item/bloodbound_shovel.png");
        generateItemModel("bloodbound_axe", "textures/item/bloodbound_axe.png");
    }

    private void generateItemModel(String itemName, String texturePath) {
        // Placeholder for item model generation logic
        System.out.println("Generating item model for: " + itemName + " with texture: " + texturePath);
    }

    // Add Items to Tags
    private void addItemsToTags() {
        Registry.ITEM.getOrCreateEntry(BLOODBOUND_TOOLS_TAG_C).add(BLOODBOUND_SWORD, BLOODBOUND_HOE, BLOODBOUND_PICKAXE, BLOODBOUND_SHOVEL, BLOODBOUND_AXE);
        Registry.ITEM.getOrCreateEntry(BLOODBOUND_TOOLS_TAG_SMALL_C).add(BLOODBOUND_SWORD, BLOODBOUND_HOE, BLOODBOUND_PICKAXE, BLOODBOUND_SHOVEL, BLOODBOUND_AXE);
        Registry.ITEM.getOrCreateEntry(BLOOD_BANK_TAG_C).add(BLOOD_BANK);
        Registry.ITEM.getOrCreateEntry(BLOOD_BANK_TAG_SMALL_C).add(BLOOD_BANK);
    }
}
