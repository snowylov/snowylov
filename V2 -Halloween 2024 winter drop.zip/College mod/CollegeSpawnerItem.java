package com.yourname.corvuscampuscollege;

import net.minecraft.block.Blocks;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.text.Text;

public class CollegeSpawnerItem extends Item {

    public CollegeSpawnerItem(Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext context) {
        World world = context.getWorld();
        PlayerEntity player = context.getPlayer();
        BlockPos pos = context.getBlockPos();

        if (world.isClient()) {
            return ActionResult.SUCCESS; // Only run on the server
        }

        // Check if there's enough space to spawn the college
        if (hasEnoughRoom(world, pos)) {
            CampusSpawner.spawnCollegeCampus(world, pos, 500); // Spawn the campus with default size
            player.sendMessage(Text.literal("Campus spawned successfully!"), false);
            return ActionResult.SUCCESS;
        } else {
            player.sendMessage(Text.literal("Not enough room to spawn the campus!"), false);
            return ActionResult.FAIL;
        }
    }

    // Method to check if there is enough room to spawn the campus
    private boolean hasEnoughRoom(World world, BlockPos origin) {
        int radius = 250; // Check a radius around the origin
        for (int x = -radius; x < radius; x++) {
            for (int z = -radius; z < radius; z++) {
                BlockPos checkPos = origin.add(x, 0, z);
                if (!world.isAir(checkPos)) {
                    return false; // Not enough room if there are blocks in the way
                }
            }
        }
        return true; // Enough room if the area is clear
    }
}