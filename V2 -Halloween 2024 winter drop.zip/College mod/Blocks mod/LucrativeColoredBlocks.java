package net.lucrative.coloredblocks;

import net.fabricmc.api.ModInitializer;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.SlabBlock;
import net.minecraft.block.StairsBlock;
import net.minecraft.block.WallBlock;
import net.minecraft.block.FenceBlock;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

public class LucrativeColoredBlocks implements ModInitializer {

    public static final String MOD_ID = "lucrative_colored_blocks";
    private static final String[] COLORS = {"white", "orange", "magenta", "light_blue", "yellow", "lime", "pink", "gray", "light_gray", "cyan", "purple", "blue", "brown", "green", "red", "black"};
    private static final String[] MATERIALS = {"concrete", "terracotta", "stained_terracotta", "wool"};

    @Override
    public void onInitialize() {
        for (String material : MATERIALS) {
            for (String color : COLORS) {
                registerColoredBlockVariants(color, material);
            }
        }
    }

    private void registerColoredBlockVariants(String color, String material) {
        String blockBase = color + "_" + material;

        // Register Stairs
        Block stairs = new StairsBlock(() -> getVanillaBlock(color, material).getDefaultState(), Block.Settings.copy(getVanillaBlock(color, material)));
        registerBlock(stairs, blockBase + "_stairs");

        // Register Slabs
        Block slab = new SlabBlock(Block.Settings.copy(getVanillaBlock(color, material)));
        registerBlock(slab, blockBase + "_slab");

        // Register Walls
        Block wall = new WallBlock(Block.Settings.copy(getVanillaBlock(color, material)));
        registerBlock(wall, blockBase + "_wall");

        // Register Fences
        Block fence = new FenceBlock(Block.Settings.copy(getVanillaBlock(color, material)));
        registerBlock(fence, blockBase + "_fence");
    }

    private Block getVanillaBlock(String color, String material) {
        switch (material) {
            case "concrete":
                return Blocks.getBlock(new Identifier("minecraft", color + "_concrete"));
            case "terracotta":
                return Blocks.TERRACOTTA;
            case "stained_terracotta":
                return Blocks.getBlock(new Identifier("minecraft", color + "_terracotta"));
            case "wool":
                return Blocks.getBlock(new Identifier("minecraft", color + "_wool"));
            default:
                throw new IllegalArgumentException("Invalid material type: " + material);
        }
    }

    private void registerBlock(Block block, String name) {
        Registry.register(Registry.BLOCK, new Identifier(MOD_ID, name), block);
        Registry.register(Registry.ITEM, new Identifier(MOD_ID, name), new BlockItem(block, new Item.Settings().group(ItemGroup.BUILDING_BLOCKS)));
    }
}