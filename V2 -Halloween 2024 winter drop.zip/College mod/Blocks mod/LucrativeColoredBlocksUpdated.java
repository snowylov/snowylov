package net.lucrative.coloredblocks;

import net.fabricmc.api.ModInitializer;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.data.server.recipe.RecipeProvider;
import net.minecraft.item.Items;
import net.minecraft.recipe.Ingredient;
import net.minecraft.recipe.RecipeSerializer;
import net.minecraft.recipe.ShapedRecipe;
import net.minecraft.recipe.SpecialRecipeSerializer;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

public class LucrativeColoredBlocks implements ModInitializer {

    public static final String MOD_ID = "lucrative_colored_blocks";
    private static final String[] COLORS = {"white", "orange", "magenta", "light_blue", "yellow", "lime", "pink", "gray", "light_gray", "cyan", "purple", "blue", "brown", "green", "red", "black"};
    private static final String[] MATERIALS = {"concrete", "terracotta", "stained_terracotta", "wool"};

    @Override
    public void onInitialize() {
        for (String material : MATERIALS) {
            for (String color : COLORS) {
                registerColoredBlockVariants(color, material);
            }
        }
    }

    private void registerColoredBlockVariants(String color, String material) {
        String blockBase = color + "_" + material;

        Block stairs = registerStairs(color, material, blockBase);
        Block slab = registerSlabs(color, material, blockBase);
        Block wall = registerWalls(color, material, blockBase);
        Block fence = registerFences(color, material, blockBase);

        // Automatically add recipes for these blocks
        addRecipeForStairs(stairs, getVanillaBlock(color, material));
        addRecipeForSlab(slab, getVanillaBlock(color, material));
        addRecipeForWall(wall, getVanillaBlock(color, material));
        addRecipeForFence(fence, getVanillaBlock(color, material));
    }

    private Block registerStairs(String color, String material, String blockBase) {
        Block stairs = new StairsBlock(() -> getVanillaBlock(color, material).getDefaultState(), Block.Settings.copy(getVanillaBlock(color, material)));
        registerBlock(stairs, blockBase + "_stairs");
        return stairs;
    }

    private Block registerSlabs(String color, String material, String blockBase) {
        Block slab = new SlabBlock(Block.Settings.copy(getVanillaBlock(color, material)));
        registerBlock(slab, blockBase + "_slab");
        return slab;
    }

    private Block registerWalls(String color, String material, String blockBase) {
        Block wall = new WallBlock(Block.Settings.copy(getVanillaBlock(color, material)));
        registerBlock(wall, blockBase + "_wall");
        return wall;
    }

    private Block registerFences(String color, String material, String blockBase) {
        Block fence = new FenceBlock(Block.Settings.copy(getVanillaBlock(color, material)));
        registerBlock(fence, blockBase + "_fence");
        return fence;
    }

    private void addRecipeForStairs(Block stairs, Block materialBlock) {
        ShapedRecipe stairsRecipe = new ShapedRecipe(
            new Identifier(MOD_ID, Registry.BLOCK.getId(stairs).getPath()),
            "",
            3, 3,
            Ingredient.ofItems(materialBlock),
            stairs
        );
        Registry.register(Registry.RECIPE_SERIALIZER, stairsRecipe.getId(), RecipeSerializer.SHAPED);
    }

    private void addRecipeForSlab(Block slab, Block materialBlock) {
        ShapedRecipe slabRecipe = new ShapedRecipe(
            new Identifier(MOD_ID, Registry.BLOCK.getId(slab).getPath()),
            "",
            3, 1,
            Ingredient.ofItems(materialBlock),
            slab
        );
        Registry.register(Registry.RECIPE_SERIALIZER, slabRecipe.getId(), RecipeSerializer.SHAPED);
    }

    private void addRecipeForWall(Block wall, Block materialBlock) {
        ShapedRecipe wallRecipe = new ShapedRecipe(
            new Identifier(MOD_ID, Registry.BLOCK.getId(wall).getPath()),
            "",
            3, 2,
            Ingredient.ofItems(materialBlock),
            wall
        );
        Registry.register(Registry.RECIPE_SERIALIZER, wallRecipe.getId(), RecipeSerializer.SHAPED);
    }

    private void addRecipeForFence(Block fence, Block materialBlock) {
        ShapedRecipe fenceRecipe = new ShapedRecipe(
            new Identifier(MOD_ID, Registry.BLOCK.getId(fence).getPath()),
            "",
            3, 2,
            Ingredient.ofItems(Items.STICK),
            fence
        );
        Registry.register(Registry.RECIPE_SERIALIZER, fenceRecipe.getId(), RecipeSerializer.SHAPED);
    }

    private Block getVanillaBlock(String color, String material) {
        switch (material) {
            case "concrete":
                return Blocks.getBlock(new Identifier("minecraft", color + "_concrete"));
            case "terracotta":
                return Blocks.TERRACOTTA;
            case "stained_terracotta":
                return Blocks.getBlock(new Identifier("minecraft", color + "_terracotta"));
            case "wool":
                return Blocks.getBlock(new Identifier("minecraft", color + "_wool"));
            default:
                throw new IllegalArgumentException("Invalid material type: " + material);
        }
    }

    private void registerBlock(Block block, String name) {
        Registry.register(Registry.BLOCK, new Identifier(MOD_ID, name), block);
        Registry.register(Registry.ITEM, new Identifier(MOD_ID, name), new BlockItem(block, new Item.Settings().group(ItemGroup.BUILDING_BLOCKS)));
    }
}