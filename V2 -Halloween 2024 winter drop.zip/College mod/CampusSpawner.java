package com.yourname.corvuscampuscollege;

import net.minecraft.block.Blocks;
import net.minecraft.block.BlockState;
import net.minecraft.block.enums.DoubleBlockHalf;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class CampusSpawner {

    // Method to spawn the entire campus
    public static void spawnCollegeCampus(World world, BlockPos origin, int campusSize) {
        // Example of placing the main building
        spawnMainBuilding(world, origin.add(50, 0, 50), campusSize / 10, campusSize / 10, 20);

        // Add the lecture hall
        spawnLectureHall(world, origin.add(600, 0, 200), 80, 50, 20); // Add the lecture hall building

        // Add more buildings (e.g., dormitories, cafeteria, library)
        spawnDormitory(world, origin.add(800, 0, 100), 80, 60, 25);  // Add dormitory
        spawnCafeteria(world, origin.add(300, 0, 150), 80, 60, 20);  // Add cafeteria
        spawnLibrary(world, origin.add(1000, 0, 300), 60, 40, 20);   // Add library
        spawnStudio(world, origin.add(200, 0, 400), 60, 30, 15);     // Add studio building
        spawnParkingLot(world, origin.add(300, 0, -100), 60, 80);    // Add parking lot
        spawnLake(world, origin.add(500, 0, 400));                   // Add lake
        spawnCampusWall(world, origin.add(-200, 0, -200), 1000, 1000); // Add campus wall
    }

    // Main Building (for reference)
    private static void spawnMainBuilding(World world, BlockPos origin, int length, int width, int height) {
        BlockState wallMaterial = Blocks.QUARTZ_BRICKS.getDefaultState();
        BlockState floorMaterial = Blocks.BLACK_WOOL.getDefaultState();
        BlockState roofMaterial = Blocks.BLUE_STAINED_GLASS.getDefaultState();

        for (int x = 0; x < length; x++) {
            for (int z = 0; z < width; z++) {
                for (int y = 0; y < height; y++) {
                    BlockPos pos = origin.add(x, y, z);
                    if (y == 0) {
                        world.setBlockState(pos, floorMaterial); // Floor
                    } else if (y == height - 1) {
                        world.setBlockState(pos, roofMaterial); // Ceiling
                    } else if (x == 0 || x == length - 1 || z == 0 || z == width - 1) {
                        world.setBlockState(pos, wallMaterial); // Walls
                    }
                }
            }
        }

        // Add a door to the main building
        BlockPos doorPosBottom = origin.add(length / 2, 1, 0); // Bottom half of door
        BlockPos doorPosTop = origin.add(length / 2, 2, 0); // Top half of door
        world.setBlockState(doorPosBottom, Blocks.OAK_DOOR.getDefaultState()); // Place bottom half of door
        world.setBlockState(doorPosTop, Blocks.OAK_DOOR.getDefaultState().with(Blocks.OAK_DOOR.getDefaultState().getStateManager().getProperty("half"), DoubleBlockHalf.UPPER)); // Place top half of door
    }

    // Lecture Hall (for reference)
    private static void spawnLectureHall(World world, BlockPos origin, int length, int width, int height) {
        BlockState wallMaterial = Blocks.QUARTZ_BRICKS.getDefaultState();
        BlockState floorMaterial = Blocks.DARK_OAK_PLANKS.getDefaultState();
        BlockState roofMaterial = Blocks.BLUE_STAINED_GLASS.getDefaultState();
        BlockState door = Blocks.OAK_DOOR.getDefaultState();

        for (int x = 0; x < length; x++) {
            for (int z = 0; z < width; z++) {
                for (int y = 0; y < height; y++) {
                    BlockPos pos = origin.add(x, y, z);
                    if (y == 0) {
                        world.setBlockState(pos, floorMaterial); // Dark oak floor
                    } else if (y == height - 1) {
                        world.setBlockState(pos, roofMaterial); // Glass roof
                    } else if (x == 0 || x == length - 1 || z == 0 || z == width - 1) {
                        world.setBlockState(pos, wallMaterial); // Walls
                    }
                }
            }
        }

        // Add door
        BlockPos doorPosBottom = origin.add(length / 2, 1, 0);
        BlockPos doorPosTop = origin.add(length / 2, 2, 0);
        world.setBlockState(doorPosBottom, door);
        world.setBlockState(doorPosTop, door.with(Blocks.OAK_DOOR.getDefaultState().getStateManager().getProperty("half"), DoubleBlockHalf.UPPER));
    }

    // Studio Building with soundproofing
    private static void spawnStudio(World world, BlockPos origin, int length, int width, int height) {
        BlockState wallMaterial = Blocks.DARK_OAK_PLANKS.getDefaultState();
        BlockState floorMaterial = Blocks.BLACK_WOOL.getDefaultState();
        BlockState ceilingMaterial = Blocks.WHITE_CONCRETE.getDefaultState();
        BlockState soundProofing = Blocks.BLACK_WOOL.getDefaultState(); // Replace with custom soundproofing if available

        for (int x = 0; x < length; x++) {
            for (int z = 0; z < width; z++) {
                for (int y = 0; y < height; y++) {
                    BlockPos pos = origin.add(x, y, z);
                    if (y == 0) {
                        world.setBlockState(pos, floorMaterial); // Black wool floor
                    } else if (y == height - 1) {
                        world.setBlockState(pos, ceilingMaterial); // White concrete ceiling
                    } else if (x == 0 || x == length - 1 || z == 0 || z == width - 1) {
                        world.setBlockState(pos, wallMaterial); // Dark oak walls
                    } else if (y >= height / 2 && (x == length / 2 || z == width / 2)) {
                        world.setBlockState(pos, soundProofing); // Soundproofing on walls
                    }
                }
            }
        }

        // Add door and bathroom
        BlockPos doorPosBottom = origin.add(length / 2, 1, 0);
        BlockPos doorPosTop = origin.add(length / 2, 2, 0);
        world.setBlockState(doorPosBottom, Blocks.OAK_DOOR.getDefaultState());
        world.setBlockState(doorPosTop, Blocks.OAK_DOOR.getDefaultState().with(Blocks.OAK_DOOR.getDefaultState().getStateManager().getProperty("half"), DoubleBlockHalf.UPPER));
        
        // Add bathroom
        spawnBathroom(world, origin.add(length - 10, 0, width - 10), 5, 5, 5); // Add bathroom in the corner of the studio
    }

    // Parking Lot
    private static void spawnParkingLot(World world, BlockPos origin, int length, int width) {
        BlockState roadMaterial = Blocks.BLACK_CONCRETE.getDefaultState();
        BlockState lineMaterial = Blocks.WHITE_CONCRETE.getDefaultState();

        // Generate the parking lot with black concrete and white lines
        for (int x = 0; x < length; x++) {
            for (int z = 0; z < width; z++) {
                BlockPos pos = origin.add(x, 0, z);
                if (x % 10 == 0 || z % 10 == 0) {
                    world.setBlockState(pos, lineMaterial); // Parking lot lines
                } else {
                    world.setBlockState(pos, roadMaterial); // Asphalt
                }
            }
        }
    }

    // Lake
    private static void spawnLake(World world, BlockPos origin) {
        BlockState water = Blocks.WATER.getDefaultState();
        BlockState grass = Blocks.GRASS_BLOCK.getDefaultState();

        int length = 15;
        int width = 10;
        int depth = 2;

        // Create rounded lake (basic shape)
        for (int x = -length / 2; x <= length / 2; x++) {
            for (int z = -width / 2; z <= width / 2; z++) {
                for (int y = 0; y <= depth; y++) {
                    BlockPos pos = origin.add(x, -y, z);
                    if (y == depth) {
                        world.setBlockState(pos, water); // Water layer
                    } else {
                        world.setBlockState(pos, grass); // Grass around the lake
                    }
                }
            }
        }
    }

    // Campus Wall
    private static void spawnCampusWall(World world, BlockPos origin, int length, int width) {
        BlockState wallMaterial = Blocks.QUARTZ_BRICKS.getDefaultState();
        BlockState slabMaterial = Blocks.QUARTZ_SLAB.getDefaultState();

        // Create a wall around the campus with slabs on top
        for (int x = 0; x <= length; x++) {
            for (int z = 0; z <= width; z++) {
                BlockPos pos = origin.add(x, 0, z);
                world.setBlockState(pos, wallMaterial); // Wall bricks
                world.setBlockState(pos.up(1), slabMaterial); // Slabs on top
            }
        }

        // Leave a gap for the parking lot as the exit
        for (int x = length / 2 - 5; x < length / 2 + 5; x++) {
            for (int z = width - 5; z <= width; z++) {
                BlockPos pos = origin.add(x, 0, z);
                world.setBlockState(pos, Blocks.AIR.getDefaultState()); // Gap for the exit
            }
        }
    }

    // Bathroom (for reuse in buildings)
    private static void spawnBathroom(World world, BlockPos origin, int length, int width, int height) {
        BlockState wallMaterial = Blocks.QUARTZ_BRICKS.getDefaultState();
        BlockState floorMaterial = Blocks.POLISHED_ANDESITE.getDefaultState();
        BlockState door = Blocks.OAK_DOOR.getDefaultState();

        // Generate the bathroom
        for (int x = 0; x < length; x++) {
            for (int z = 0; z < width; z++) {
                for (int y = 0; y < height; y++) {
                    BlockPos pos = origin.add(x, y, z);
                    if (y == 0) {
                        world.setBlockState(pos, floorMaterial); // Polished andesite floor
                    } else if (y == height - 1) {
                        world.setBlockState(pos, Blocks.WHITE_CONCRETE.getDefaultState()); // Ceiling
                    } else if (x == 0 || x == length - 1 || z == 0 || z == width - 1) {
                        world.setBlockState(pos, wallMaterial); // Walls
                    }
                }
            }
        }

        // Add a door
        BlockPos doorPosBottom = origin.add(length / 2, 1, 0);
        BlockPos doorPosTop = origin.add(length / 2, 2, 0);
        world.setBlockState(doorPosBottom, door);
        world.setBlockState(doorPosTop, door.with(Blocks.OAK_DOOR.getDefaultState().getStateManager().getProperty("half"), DoubleBlockHalf.UPPER));
    }
}