package com.yourdomain.wildcrops;

import net.minecraft.block.Block;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;
import net.minecraft.world.gen.feature.ConfiguredFeatures;
import net.minecraft.world.gen.feature.DefaultBiomeFeatures;
import net.minecraft.world.gen.feature.Feature;
import net.minecraft.world.gen.feature.RandomPatchFeatureConfig;
import net.minecraft.world.gen.feature.VegetationPlacedFeatures;
import net.minecraft.world.gen.placementmodifier.PlacementModifiers;
import net.minecraft.world.gen.stateprovider.BlockStateProvider;
import org.quiltmc.loader.api.ModContainer;
import org.quiltmc.qsl.base.api.entrypoint.ModInitializer;
import org.quiltmc.qsl.worldgen.biome.api.BiomeModifications;

public class WildCropsMod implements ModInitializer {
    public static final Block WILD_CARROTS = new WildCropBlock(BlockStateProvider.of(Blocks.CARROTS.getDefaultState().with(CarrotBlock.AGE, 7)));
    public static final Block WILD_BEETROOTS = new WildCropBlock(BlockStateProvider.of(Blocks.BEETROOTS.getDefaultState().with(BeetrootBlock.AGE, 3)));
    public static final Block WILD_POTATOES = new WildCropBlock(BlockStateProvider.of(Blocks.POTATOES.getDefaultState().with(PotatoBlock.AGE, 7)));
    public static final Block WILD_WHEAT = new WildCropBlock(BlockStateProvider.of(Blocks.WHEAT.getDefaultState().with(WheatBlock.AGE, 7)));

    @Override
    public void onInitialize(ModContainer mod) {
        Registry.register(Registry.BLOCK, new Identifier("wild_crops", "wild_carrots"), WILD_CARROTS);
        Registry.register(Registry.BLOCK, new Identifier("wild_crops", "wild_beetroots"), WILD_BEETROOTS);
        Registry.register(Registry.BLOCK, new Identifier("wild_crops", "wild_potatoes"), WILD_POTATOES);
        Registry.register(Registry.BLOCK, new Identifier("wild_crops", "wild_wheat"), WILD_WHEAT);
        
        registerCropFeature(WILD_CARROTS, "wild_carrots");
        registerCropFeature(WILD_BEETROOTS, "wild_beetroots");
        registerCropFeature(WILD_POTATOES, "wild_potatoes");
        registerCropFeature(WILD_WHEAT, "wild_wheat");
    }

    private void registerCropFeature(Block crop, String name) {
        var feature = Feature.VEGETATION_PATCH.configure(new RandomPatchFeatureConfig.Builder(BlockStateProvider.of(crop), SimpleBlockPlacer.INSTANCE)
            .tries(64) // Number of attempts per chunk
            .whitelist(ImmutableSet.of(Blocks.GRASS_BLOCK)) // Base block type
            .cannotProject() // Do not project upwards
            .build());
        var placedFeature = feature.withPlacement(
            VegetationPlacedFeatures.modifiersWithWouldSurvive(
                PlacedFeatures.createCountExtraModifier(1, 0.1f, 2), crop));

        RegistryKey<PlacedFeature> placedKey = RegistryKey.of(Registry.PLACED_FEATURE_KEY, new Identifier("wild_crops", name));
        Registry.register(BuiltinRegistries.PLACED_FEATURE, placedKey.getValue(), placedFeature);
        BiomeModifications.addFeature(biomeSelectionContext ->
            biomeSelectionContext.getBiome().getPrecipitation() == Biome.Precipitation.NONE &&
            biomeSelectionContext.getBiome().getCategory() != Biome.Category.DESERT,
            GenerationStep.Feature.VEGETAL_DECORATION, placedKey);
    }
}