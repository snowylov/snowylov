package com.yourdomain.wildcrops;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.item.ItemStack;
import net.minecraft.loot.context.LootContext;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

import java.util.List;
import java.util.Random;

public class WildCropBlock extends Block {
    private final Identifier dropItem;

    public WildCropBlock(Settings settings, Identifier dropItem) {
        super(settings);
        this.dropItem = dropItem;
    }

    @Override
    public List<ItemStack> getDroppedStacks(BlockState state, LootContext.Builder builder) {
        Random random = builder.getRandom();
        int count = 5 + random.nextInt(5); // Generates a number between 5 and 9
        return List.of(new ItemStack(Registry.ITEM.get(dropItem), count));
    }
}