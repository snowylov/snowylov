
package net.alex.planes_blimps_and_balloons.entities;

import com.jozufozu.flywheel.api.Flywheel;
import com.jozufozu.flywheel.api.structure.Structure;
import net.alex.planes_blimps_and_balloons.blocks.BalloonBlock;
import net.alex.planes_blimps_and_balloons.items.ZeppelinPaste;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.MovementType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.vehicle.BoatEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.Set;

public class ZeppelinEntity extends BoatEntity {
    private static final double BASE_SPEED = 0.1;
    private static final double DESCENT_RATE = 0.05;

    private Structure zeppelinStructure;
    private PlayerEntity controllingPlayer;
    private int totalLiftCapacity = 0;
    private int structureWeight = 0;

    public ZeppelinEntity(EntityType<? extends ZeppelinEntity> type, World world, Set<BlockPos> gluedPositions) {
        super(type, world);
        this.zeppelinStructure = Flywheel.createStructure(world, gluedPositions.iterator().next());
        gatherStructure(gluedPositions);
        calculateLiftCapacity();
    }

    public void setControllingPlayer(PlayerEntity player) {
        this.controllingPlayer = player;
    }

    @Override
    public void tick() {
        super.tick();
        if (controllingPlayer != null) {
            handleControls();
        } else {
            this.setVelocity(this.getVelocity().add(0, -DESCENT_RATE, 0));
        }
        zeppelinStructure.setPosition(this.getPos());
    }

    private void handleControls() {
        double lift = calculateLift();
        if (controllingPlayer.input.jumping && lift > structureWeight) {
            this.setVelocity(this.getVelocity().add(0, BASE_SPEED, 0)); // Ascend
        } else if (controllingPlayer.input.sneaking) {
            this.setVelocity(this.getVelocity().add(0, -BASE_SPEED, 0)); // Descend faster
        } else if (controllingPlayer.input.pressingForward) {
            Vec3d direction = Vec3d.fromPolar(0, controllingPlayer.getYaw()).normalize();
            this.setVelocity(direction.multiply(BASE_SPEED)); // Forward movement
        }
        this.move(MovementType.SELF, this.getVelocity());
    }

    private void gatherStructure(Set<BlockPos> gluedPositions) {
        gluedPositions.forEach(zeppelinStructure::gatherBlock);
        zeppelinStructure.build();
    }

    private void calculateLiftCapacity() {
        totalLiftCapacity = 0;
        structureWeight = 0;
        for (BlockPos pos : zeppelinStructure.getBlocks()) {
            if (world.getBlockState(pos).getBlock() instanceof BalloonBlock balloonBlock) {
                totalLiftCapacity += balloonBlock.getLiftCapacity();
            }
            structureWeight++;
        }
    }

    private double calculateLift() {
        return totalLiftCapacity - structureWeight;
    }
}
//