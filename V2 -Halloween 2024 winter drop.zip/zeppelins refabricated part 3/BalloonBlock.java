
package net.alex.planes_blimps_and_balloons.blocks;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Material;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.DyeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.EnumProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.ActionResult;
import net.minecraft.util.DyeColor;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class BalloonBlock extends Block {
    public static final EnumProperty<DyeColor> COLOR = Properties.COLOR;
    private static final int LIFT_CAPACITY = 10; // Lift capacity per balloon block

    public BalloonBlock() {
        super(Settings.of(Material.WOOL).strength(0.5f).nonOpaque());
        this.setDefaultState(this.getStateManager().getDefaultState().with(COLOR, DyeColor.WHITE));
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(COLOR);
    }

    @Override
    public ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, Hand hand, BlockHitResult hit) {
        ItemStack heldItem = player.getStackInHand(hand);
        if (heldItem.getItem() instanceof DyeItem dyeItem) {
            world.setBlockState(pos, state.with(COLOR, dyeItem.getColor()));
            heldItem.decrement(1);
            return ActionResult.SUCCESS;
        }
        return ActionResult.PASS;
    }

    public int getLiftCapacity() {
        return LIFT_CAPACITY;
    }
}
