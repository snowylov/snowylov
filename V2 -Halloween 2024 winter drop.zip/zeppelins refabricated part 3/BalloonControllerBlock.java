
package net.alex.planes_blimps_and_balloons.blocks;

import net.alex.planes_blimps_and_balloons.entities.BalloonEntities;
import net.alex.planes_blimps_and_balloons.items.ZeppelinPaste;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.Set;

public class BalloonControllerBlock extends Block {

    public BalloonControllerBlock(Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, Hand hand, BlockHitResult hit) {
        // Check if the player is holding ZeppelinPaste
        if (!world.isClient && player.getStackInHand(hand).getItem() instanceof ZeppelinPaste) {
            ZeppelinPaste paste = (ZeppelinPaste) player.getStackInHand(hand).getItem();
            Set<BlockPos> gluedPositions = paste.getGluedPositions();

            // Count the number of balloon blocks in the glued positions
            long balloonCount = gluedPositions.stream()
                .filter(blockPos -> world.getBlockState(blockPos).getBlock() instanceof BalloonBlock)
                .count();

            if (balloonCount > 0) { // Requires at least one balloon block
                // Create and spawn the ZeppelinEntity
                BalloonEntities.ZeppelinEntity zeppelin = new BalloonEntities.ZeppelinEntity(BalloonEntities.BALLOON_ENTITY, world, gluedPositions);
                zeppelin.setPosition(pos.getX(), pos.getY(), pos.getZ());
                world.spawnEntity(zeppelin);

                player.sendMessage(Text.of("Zeppelin created!"), true);
                return ActionResult.SUCCESS;
            } else {
                player.sendMessage(Text.of("Requires at least one balloon block to create a Zeppelin."), true);
            }
        }
        return ActionResult.PASS;
    }
}
