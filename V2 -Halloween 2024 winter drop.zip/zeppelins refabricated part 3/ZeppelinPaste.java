
package net.alex.planes_blimps_and_balloons.items;

import com.jozufozu.flywheel.api.Flywheel;
import com.jozufozu.flywheel.api.structure.Structure;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.HashSet;
import java.util.Set;

public class ZeppelinPaste extends Item {
    private final Set<BlockPos> gluedPositions = new HashSet<>();
    private Structure structure;

    public ZeppelinPaste(Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext context) {
        World world = context.getWorld();
        BlockPos pos = context.getBlockPos();
        PlayerEntity player = context.getPlayer();
        
        if (!world.isClient && player != null) {
            if (gluedPositions.contains(pos)) {
                gluedPositions.remove(pos); // Unglue if already glued
                player.sendMessage(Text.of("Block unlinked"), true);
            } else {
                gluedPositions.add(pos); // Add block to structure
                player.sendMessage(Text.of("Block linked"), true);
            }

            updateStructure(world);
            return ActionResult.SUCCESS;
        }
        return ActionResult.PASS;
    }

    private void updateStructure(World world) {
        if (structure != null) {
            structure.clear();
        }
        structure = Flywheel.createStructure(world, gluedPositions.iterator().next());
        gluedPositions.forEach(structure::gatherBlock);
        structure.build();
    }

    public Set<BlockPos> getGluedPositions() {
        return gluedPositions;
    }
}