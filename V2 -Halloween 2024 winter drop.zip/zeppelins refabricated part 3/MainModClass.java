package net.alex.planes_blimps_and_balloons;

import net.fabricmc.api.ModInitializer;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;
import net.alex.planes_blimps_and_balloons.blocks.BalloonBlock;
import net.alex.planes_blimps_and_balloons.blocks.BalloonControllerBlock;
import net.alex.planes_blimps_and_balloons.items.ZeppelinPaste;
import net.alex.planes_blimps_and_balloons.entities.ZeppelinEntity;

public class MainModClass implements ModInitializer {
    public static final String MOD_ID = "planes_blimps_and_balloons";
    
    // Registering the blocks
    public static final BalloonBlock BALLOON_BLOCK = new BalloonBlock();
    public static final BalloonControllerBlock BALLOON_CONTROLLER_BLOCK = new BalloonControllerBlock();

    // Registering the items
    public static final ZeppelinPaste ZEPPELIN_PASTE = new ZeppelinPaste(new Item.Settings().group(ItemGroup.MISC));

    @Override
    public void onInitialize() {
        // Register blocks
        Registry.register(Registry.BLOCK, new Identifier(MOD_ID, "balloon_block"), BALLOON_BLOCK);
        Registry.register(Registry.BLOCK, new Identifier(MOD_ID, "balloon_controller_block"), BALLOON_CONTROLLER_BLOCK);

        // Register block items
        Registry.register(Registry.ITEM, new Identifier(MOD_ID, "balloon_block"), new BlockItem(BALLOON_BLOCK, new Item.Settings().group(ItemGroup.DECORATIONS)));
        Registry.register(Registry.ITEM, new Identifier(MOD_ID, "balloon_controller_block"), new BlockItem(BALLOON_CONTROLLER_BLOCK, new Item.Settings().group(ItemGroup.MISC)));
        
        // Register Zeppelin Paste
        Registry.register(Registry.ITEM, new Identifier(MOD_ID, "zeppelin_paste"), ZEPPELIN_PASTE);

        // Register the Zeppelin Entity if needed
        Registry.register(Registry.ENTITY_TYPE, new Identifier(MOD_ID, "zeppelin_entity"), ZeppelinEntity.ZEPPELIN_ENTITY);
    }
}