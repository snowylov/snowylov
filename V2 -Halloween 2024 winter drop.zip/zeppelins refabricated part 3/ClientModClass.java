package net.alex.planes_blimps_and_balloons.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.ColorProviderRegistry;
import net.minecraft.client.color.world.BlockColors;
import net.minecraft.util.DyeColor;
import net.alex.planes_blimps_and_balloons.MainModClass;
import net.alex.planes_blimps_and_balloons.blocks.BalloonBlock;

public class ClientModClass implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // Register color provider for BalloonBlock
        ColorProviderRegistry.BLOCK.register((state, world, pos, tintIndex) -> {
            if (tintIndex == 0) {
                DyeColor color = state.get(BalloonBlock.COLOR); // Assumes BalloonBlock.COLOR is an EnumProperty<DyeColor>
                return color.getFireworkColor();
            }
            return 0xFFFFFF;
        }, MainModClass.BALLOON_BLOCK);

        // Register color provider for the BalloonBlock as an item
        ColorProviderRegistry.ITEM.register((stack, tintIndex) -> {
            if (tintIndex == 0) {
                DyeColor color = DyeColor.byId(stack.getDamage());
                return color.getFireworkColor();
            }
            return 0xFFFFFF;
        }, MainModClass.BALLOON_BLOCK.asItem());
    }
}