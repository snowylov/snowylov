{
  "type": "minecraft:crafting_shapeless",
  "ingredients": [
    { "item": "minecraft:slime_ball" },
    { "item": "minecraft:moss_block" }
  ],
  "result": {
    "item": "planes_blimps_and_balloons:zeppelin_paste",
    "count": 32
  }
}