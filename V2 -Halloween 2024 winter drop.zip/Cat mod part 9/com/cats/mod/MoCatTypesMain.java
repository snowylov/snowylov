package com.cats.mod;

import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.client.render.entity.CatEntityRenderer;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.passive.CatEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;
import net.minecraft.world.biome.BiomeKeys;
import net.minecraft.world.gen.feature.ConfiguredStructureFeatures;
import net.minecraft.world.spawner.SpawnRestriction;
import org.quiltmc.loader.api.ModContainer;
import org.quiltmc.qsl.base.api.entrypoint.client.ClientModInitializer;
import org.quiltmc.qsl.entity.client.api.ClientEntityRendererRegistry;

import java.util.HashMap;
import java.util.Map;

public class MoCatTypesMain implements ClientModInitializer {
    // Map of variant names and their texture paths
    private static final Map<String, String> CAT_VARIANTS = new HashMap<>();

    static {
        CAT_VARIANTS.put("cream", "textures/entity/cat/cat_variant_1.png");
        CAT_VARIANTS.put("turkish_van", "textures/entity/cat/cat_variant_2.png");
        CAT_VARIANTS.put("blue_russian", "textures/entity/cat/cat_variant_3.png");
        CAT_VARIANTS.put("fawn", "textures/entity/cat/cat_variant_4.png");
        CAT_VARIANTS.put("maui", "textures/entity/cat/cat_variant_5.png");
        CAT_VARIANTS.put("tortoiseshell", "textures/entity/cat/cat_variant_6.png");
        CAT_VARIANTS.put("grey_tabby", "textures/entity/cat/cat_variant_7.png");
        CAT_VARIANTS.put("skeleton", "textures/entity/cat/skeleton_cat.png"); // Add the Skeleton Cat texture
    }

    @Override
    public void onInitializeClient(ModContainer mod) {
        // Register all cat variants and their textures
        registerCatVariants();

        // Register the Skeleton Cat's specific behavior
        registerSkeletonCatBehavior();
    }

    private void registerCatVariants() {
        CAT_VARIANTS.forEach((variant, texturePath) -> {
            Identifier texture = new Identifier("mo_cat_types", texturePath);
            ClientEntityRendererRegistry.register(CatEntity.TYPE, (ctx) -> new CatEntityRenderer(ctx, texture));
        });
    }

    private void registerSkeletonCatBehavior() {
        // Spawn only in witch huts with the same attributes as black cats
        FabricDefaultAttributeRegistry.register(CatEntity.TYPE, CatEntity.createCatAttributes());

        // Restrict spawning to witch huts (similar to black cats)
        SpawnRestriction.register(CatEntity.TYPE, SpawnRestriction.Location.ON_GROUND, BiomeKeys.SWAMP_HUT);

        // Registering spawn conditions to mirror black cat spawning conditions in witch huts
        Registry.register(Registry.ENTITY_TYPE, new Identifier("mo_cat_types", "skeleton_cat"), EntityType.CAT);
        EntityType.CAT.spawnGroup = SpawnGroup.CREATURE;
    }
}