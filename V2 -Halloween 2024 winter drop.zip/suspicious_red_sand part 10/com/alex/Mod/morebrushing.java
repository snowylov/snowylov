package com.alex.morebrushing;

import net.fabricmc.api.ModInitializer;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.BrushableBlock;
import net.minecraft.block.Material;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.IntProperty;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.registry.Registry;
import net.minecraft.world.World;

import java.util.Random;

public class MoreBrushing implements ModInitializer {
    public static final String MOD_ID = "morebrushing";
    public static final Block SUSPICIOUS_RED_SAND = new SuspiciousRedSandBlock();

    @Override
    public void onInitialize() {
        Registry.register(Registry.BLOCK, new Identifier(MOD_ID, "suspicious_red_sand"), SUSPICIOUS_RED_SAND);
        Registry.register(Registry.ITEM, new Identifier(MOD_ID, "suspicious_red_sand"), 
            new BlockItem(SUSPICIOUS_RED_SAND, new Item.Settings().group(ItemGroup.MISC))
        );
        System.out.println("More Brushing Mod has been initialized!");
    }

    public static class SuspiciousRedSandBlock extends BrushableBlock {
        public static final IntProperty BRUSHING_STAGE = IntProperty.of("brushing_stage", 0, 3);
        private static final Random random = new Random();

        public SuspiciousRedSandBlock() {
            super(Settings.of(Material.AGGREGATE).strength(0.5f));
            setDefaultState(this.stateManager.getDefaultState().with(BRUSHING_STAGE, 0));
        }

        @Override
        protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
            builder.add(BRUSHING_STAGE);
        }

        @Override
        protected void onBrushed(World world, BlockState state, BlockPos pos, PlayerEntity player) {
            int stage = state.get(BRUSHING_STAGE);
            if (stage < 3) {
                world.setBlockState(pos, state.with(BRUSHING_STAGE, stage + 1));
            } else if (!world.isClient && world instanceof ServerWorld) {
                if (random.nextBoolean()) {
                    player.giveItemStack(new ItemStack(Items.EMERALD));
                }
                world.setBlockState(pos, Blocks.RED_SAND.getDefaultState());
            }
        }
    }
}