public class DesertMod {
    // Static Block Declarations (for flowers and FishEggs block)
    public static final Block MEADOW_VIOLET = new FlowerBlock(StatusEffects.REGENERATION, 8, Block.Settings.copy(Blocks.DANDELION));
    public static final Block GOLDEN_PETAL = new FlowerBlock(StatusEffects.SPEED, 8, Block.Settings.copy(Blocks.DANDELION));
    public static final Block DUSKY_DAISY = new FlowerBlock(StatusEffects.NIGHT_VISION, 8, Block.Settings.copy(Blocks.DANDELION));
    public static final Block ROYAL_BLOOM = new FlowerBlock(StatusEffects.LUCK, 8, Block.Settings.copy(Blocks.DANDELION));  // Custom flower example
    public static final Block FISH_EGGS = new FrogspawnBlock(Block.Settings.copy(Blocks.WATER)); // Renamed FishEggs block
    
    // Static Biome Declarations
    public static final Biome RED_SAND_DESERT = createRedSandDesertBiome();
    public static final Biome SNOWY_RED_SAND_DESERT = createSnowyRedSandDesertBiome();
    public static final Biome SNOWY_DESERT = createSnowyDesertBiome();
    public static final Biome GROVE = createGroveBiome();
    public static final Biome TREELESS_GROVE = createTreelessGroveBiome();
    public static final Biome LEGACY_FROZEN_OCEAN = createLegacyFrozenOceanBiome();

    // Deeper Deep Ocean Variants
    public static final Biome DEEPER_DEEP_OCEAN = createDeeperDeepOceanBiome();
    public static final Biome DEEPER_DEEP_FROZEN_OCEAN = createDeeperDeepFrozenOceanBiome();
    public static final Biome DEEPER_DEEP_LEGACY_FROZEN_OCEAN = createDeeperDeepLegacyFrozenOceanBiome();
    

    // Gravel Beaches
    public static final Biome GRAVEL_BEACH = createGravelBeachBiome();

    // Two-Block Warm Ocean
    public static final Biome SHALLOW_WARM_OCEAN = createShallowWarmOceanBiome();

    // Static Class Initialization Block
    static {
        // Register blocks and biomes from code
        registerAll();
    }

    // Block and Biome Registration from code
    private static void registerAll() {
        // Register Flowers and FishEggs block
        registerBlock("meadow_violet", MEADOW_VIOLET);
        registerBlock("golden_petal", GOLDEN_PETAL);
        registerBlock("dusky_daisy", DUSKY_DAISY);
        registerBlock("royal_bloom", ROYAL_BLOOM);
        registerBlock("fish_eggs", FISH_EGGS);

        // Register Biomes (from code)
        registerBiome("red_sand_desert", RED_SAND_DESERT);
        registerBiome("snowy_red_sand_desert", SNOWY_RED_SAND_DESERT);
        registerBiome("snowy_desert", SNOWY_DESERT);
        registerBiome("grove", GROVE);
        registerBiome("treeless_grove", TREELESS_GROVE);
        registerBiome("legacy_frozen_ocean", LEGACY_FROZEN_OCEAN);

        // Register Deeper Deep Oceans and Gravel Beach
        registerBiome("deeper_deep_ocean", DEEPER_DEEP_OCEAN);
        registerBiome("deeper_deep_frozen_ocean", DEEPER_DEEP_FROZEN_OCEAN);
        registerBiome("deeper_deep_legacy_frozen_ocean", DEEPER_DEEP_LEGACY_FROZEN_OCEAN);
        registerBiome("gravel_beach", GRAVEL_BEACH);
        
        // Register Two-Block Warm Ocean
        registerBiome("shallow_warm_ocean", SHALLOW_WARM_OCEAN);
    }

    private static void registerBlock(String id, Block block) {
        Registry.register(Registry.BLOCK, new Identifier("modid", id), block);
        Registry.register(Registry.ITEM, new Identifier("modid", id), new BlockItem(block, new Item.Settings()));
    }

    private static void registerBiome(String id, Biome biome) {
        Registry.register(Registry.BIOME, new Identifier("modid", id), biome);
    }

    // Red Sand Desert Biome Creation (with Red Sandstone)
    private static Biome createRedSandDesertBiome() {
        return new Biome.Builder()
            .temperature(2.0F)
            .downfall(0.0F)
            .precipitation(Biome.Precipitation.NONE)
            .category(Biome.Category.DESERT)
            .surfaceBuilder(SurfaceBuilder.DEFAULT.withConfig(new SurfaceConfig(
                Blocks.RED_SAND.getDefaultState(),
                Blocks.RED_SANDSTONE.getDefaultState(),
                Blocks.STONE.getDefaultState())))
            .build();
    }

    // Snowy Red Sand Desert Biome Creation (with Red Sandstone)
    private static Biome createSnowyRedSandDesertBiome() {
        return new Biome.Builder()
            .temperature(0.0F)
            .downfall(0.5F)
            .precipitation(Biome.Precipitation.SNOW)
            .category(Biome.Category.DESERT)
            .surfaceBuilder(SurfaceBuilder.DEFAULT.withConfig(new SurfaceConfig(
                Blocks.RED_SAND.getDefaultState(),
                Blocks.RED_SANDSTONE.getDefaultState(),
                Blocks.STONE.getDefaultState())))
            .build();
    }

    // Snowy Desert Biome Creation (with regular sand and sandstone)
    private static Biome createSnowyDesertBiome() {
        return new Biome.Builder()
            .temperature(0.0F)
            .downfall(0.5F)
            .precipitation(Biome.Precipitation.SNOW)
            .category(Biome.Category.DESERT)
            .surfaceBuilder(SurfaceBuilder.DEFAULT.withConfig(new SurfaceConfig(
                Blocks.SAND.getDefaultState(),
                Blocks.SANDSTONE.getDefaultState(),
                Blocks.STONE.getDefaultState())))
            .build();
    }

    // Gravel Beach Biome Creation
    private static Biome createGravelBeachBiome() {
        return new Biome.Builder()
            .temperature(0.8F)
            .downfall(0.2F)
            .precipitation(Biome.Precipitation.RAIN)
            .category(Biome.Category.BEACH)
            .surfaceBuilder(SurfaceBuilder.DEFAULT.withConfig(new SurfaceConfig(
                Blocks.GRAVEL.getDefaultState(),  // Surface layer is gravel
                Blocks.STONE.getDefaultState(),
                Blocks.STONE.getDefaultState())))
            .build();
    }

    // Deeper Deep Ocean Biomes
    private static Biome createDeeperDeepOceanBiome() {
        return new Biome.Builder()
            .temperature(0.5F)
            .downfall(0.5F)
            .precipitation(Biome.Precipitation.RAIN)
            .category(Biome.Category.OCEAN)
            .depth(-2.2F)  // Deeper ocean depth
            .scale(0.1F)
            .surfaceBuilder(SurfaceBuilder.DEFAULT.withConfig(new SurfaceConfig(
                Blocks.WATER.getDefaultState(),
                Blocks.GRAVEL.getDefaultState(),
                Blocks.STONE.getDefaultState())))
            .build();
    }

    private static Biome createDeeperDeepFrozenOceanBiome() {
        return new Biome.Builder()
            .temperature(0.0F)
            .downfall(0.5F)
            .precipitation(Biome.Precipitation.SNOW)
            .category(Biome.Category.OCEAN)
            .depth(-2.2F)
            .scale(0.1F)
            .surfaceBuilder(SurfaceBuilder.DEFAULT.withConfig(new SurfaceConfig(
                Blocks.ICE.getDefaultState(),
                Blocks.PACKED_ICE.getDefaultState(),
                Blocks.STONE.getDefaultState())))
            .build();
    }

    private static Biome createDeeperDeepLegacyFrozenOceanBiome() {
        return new Biome.Builder()
            .temperature(0.0F)
            .downfall(0.5F)
            .precipitation(Biome.Precipitation.SNOW)
            .category(Biome.Category.OCEAN)
            .depth(-2.2F)
            .scale(0.1F)
            .surfaceBuilder(SurfaceBuilder.DEFAULT.withConfig(new SurfaceConfig(
                Blocks.ICE.getDefaultState(),
                Blocks.PACKED_ICE.getDefaultState(),
                Blocks.STONE.getDefaultState())))
            .build();
    }

    // Shallow Warm Ocean Biome with FishEggs Block and Short Seagrass
    private static Biome createShallowWarmOceanBiome() {
        return new Biome.Builder()
            .temperature(1.0F)
            .downfall(0.5F)
            .precipitation(Biome.Precipitation.RAIN)
            .category(Biome.Category.OCEAN)
            .depth(-0.2F)  // Shallow depth, only 2 blocks deep
            .scale(0.1F)
            .surfaceBuilder(SurfaceBuilder.DEFAULT.withConfig(new SurfaceConfig(
                Blocks.WATER.getDefaultState(),
                Blocks.SAND.getDefaultState(),
                Blocks.STONE.getDefaultState())))
            .spawnSettings(new SpawnSettings.Builder()
                .spawn(SpawnGroup.WATER_AMBIENT, new SpawnEntry(EntityType.TROPICAL_FISH, 20, 2, 5))

  // Spawn tropical fish
                .build())
            .generationSettings(new GenerationSettings.Builder()
                .feature(GenerationStep.Feature.VEGETAL_DECORATION, Feature.SEAGRASS.withConfiguration(new ProbabilityConfig(0.3F)))  // Short seagrass
                .feature(GenerationStep.Feature.VEGETAL_DECORATION, Feature.RANDOM_PATCH.withConfiguration(new BlockClusterFeatureConfig.Builder(new SimpleBlockStateProvider(FISH_EGGS.getDefaultState()), SimpleBlockPlacer.INSTANCE).tries(64).build()))  // FishEggs block
                .build())
            .build();
    }
}