
package com.example.golemacy;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.passive.IronGolemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.*;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.registry.Registry;
import net.minecraft.util.registry.BuiltinRegistries;
import net.minecraft.world.World;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.biome.BiomeKeys;
import net.minecraft.world.biome.SpawnSettings;
import net.minecraft.world.explosion.Explosion;
import net.minecraft.text.Text;
import net.minecraft.text.TranslatableText;
import net.minecraft.util.Formatting;

import java.util.List;

public class GolemacyMod implements ModInitializer {
    public static final String MOD_ID = "golemacy";
    public static final EntityType<FurnaceGolemEntity> FURNACE_GOLEM = Registry.register(
            Registry.ENTITY_TYPE,
            new Identifier(MOD_ID, "furnace_golem"),
            FabricEntityTypeBuilder.createMob().entityFactory(FurnaceGolemEntity::new).dimensions(EntityType.IRON_GOLEM.getDimensions()).build()
    );
    public static final EntityType<StoneGolemEntity> STONE_GOLEM = Registry.register(
            Registry.ENTITY_TYPE,
            new Identifier(MOD_ID, "stone_golem"),
            FabricEntityTypeBuilder.createMob().entityFactory(StoneGolemEntity::new).dimensions(EntityType.IRON_GOLEM.getDimensions()).build()
    );
    public static final EntityType<BlackstoneGolemEntity> BLACKSTONE_GOLEM = Registry.register(
            Registry.ENTITY_TYPE,
            new Identifier(MOD_ID, "blackstone_golem"),
            FabricEntityTypeBuilder.createMob().entityFactory(BlackstoneGolemEntity::new).dimensions(EntityType.IRON_GOLEM.getDimensions()).build()
    );
    public static final EntityType<SwampGolemEntity> SWAMP_GOLEM = Registry.register(
            Registry.ENTITY_TYPE,
            new Identifier(MOD_ID, "swamp_golem"),
            FabricEntityTypeBuilder.createMob().entityFactory(SwampGolemEntity::new).dimensions(EntityType.IRON_GOLEM.getDimensions()).build()
    );
    public static final EntityType<PoisonGolemEntity> POISON_GOLEM = Registry.register(
            Registry.ENTITY_TYPE,
            new Identifier(MOD_ID, "poison_golem"),
            FabricEntityTypeBuilder.createMob().entityFactory(PoisonGolemEntity::new).spawnGroup(SpawnGroup.MONSTER).dimensions(EntityType.IRON_GOLEM.getDimensions()).build()
    );
    public static final Item SCROLL_OF_AWAKENING = new ScrollOfAwakening(new Item.Settings().group(ItemGroup.MISC).maxCount(1));

    @Override
    public void onInitialize() {
        // Register all golem entity attributes
        FabricDefaultAttributeRegistry.register(FURNACE_GOLEM, IronGolemEntity.createIronGolemAttributes());
        
        FabricDefaultAttributeRegistry.register(STONE_GOLEM, IronGolemEntity.createIronGolemAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 50.0) // 50% less health than Iron Golem
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 7.0) // Reduced attack damage
        );

        FabricDefaultAttributeRegistry.register(BLACKSTONE_GOLEM, IronGolemEntity.createIronGolemAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 60.0) // 40% less health than Iron Golem
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 9.0) // Reduced attack damage
        );

        FabricDefaultAttributeRegistry.register(SWAMP_GOLEM, IronGolemEntity.createIronGolemAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 50.0) // 50% less health than Iron Golem
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 6.0) // Reduced attack damage
        );

        FabricDefaultAttributeRegistry.register(POISON_GOLEM, IronGolemEntity.createIronGolemAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 144.0) // 20% more health than Iron Golem
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 18.0) // Increased attack damage
        );

        // Register the Scroll of Awakening
        Registry.register(Registry.ITEM, new Identifier(MOD_ID, "scroll_of_awakening"), SCROLL_OF_AWAKENING);

        // Add poison golem spawn near witch huts
        BiomeModifications.addSpawn(biomeSelectionContext -> biomeSelectionContext.getBiomeKey().equals(BiomeKeys.SWAMP),
                SpawnGroup.MONSTER, POISON_GOLEM, 1, 1, 1);
    }

    // Golem Entity Definitions
    public static class FurnaceGolemEntity extends IronGolemEntity {
        public FurnaceGolemEntity(EntityType<? extends IronGolemEntity> entityType, World world) {
            super(entityType, world);
        }

        @Override
        public void onDeath() {
            if (!this.world.isClient) {
                // Create an explosion that doesn't break blocks but deals damage
                this.world.createExplosion(this, this.getX(), this.getY(), this.getZ(), 4.0F, false, Explosion.DestructionType.NONE);
            }
            super.onDeath();
        }
    }

    public static class StoneGolemEntity extends IronGolemEntity {
        public StoneGolemEntity(EntityType<? extends IronGolemEntity> entityType, World world) {
            super(entityType, world);
        }
    }

    public static class BlackstoneGolemEntity extends IronGolemEntity {
        public BlackstoneGolemEntity(EntityType<? extends IronGolemEntity> entityType, World world) {
            super(entityType, world);
        }
    }

    public static class SwampGolemEntity extends IronGolemEntity {
        public SwampGolemEntity(EntityType<? extends IronGolemEntity> entityType, World world) {
            super(entityType, world);
        }

        @Override
        public boolean canHaveStatusEffect(StatusEffectInstance effect) {
            // Make the Swamp Golem immune to all potion effects
            return false;
        }
    }

    public static class PoisonGolemEntity extends HostileEntity {
        public PoisonGolemEntity(EntityType<? extends HostileEntity> entityType, World world) {
            super(entityType, world);
        }

        @Override
        protected void initAttributes() {
            super.initAttributes();
            this.getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH).setBaseValue(144.0); // 20% more health than Iron Golem
            this.getAttributeInstance(EntityAttributes.GENERIC_ATTACK_DAMAGE).setBaseValue(18.0); // Increased attack damage
        }

        @Override
        public boolean canHaveStatusEffect(StatusEffectInstance effect) {
            // Make the Poison Golem immune to all potion effects
            return false;
        }

        @Override
        public boolean tryAttack(Entity target) {
            if (super.tryAttack(target)) {
                // Optionally, apply poison effect to target on hit
                if (target instanceof LivingEntity) {
                    ((LivingEntity) target).addStatusEffect(new StatusEffectInstance(StatusEffects.POISON, 100, 1));
                }
                return true;
            }
            return false;
        }
    }

    // Scroll of Awakening Item
    public static class ScrollOfAwakening extends Item {
        public ScrollOfAwakening(Settings settings) {
            super(settings);
        }

        @Override
        public ActionResult useOnBlock(ItemUsageContext context) {
            World world = context.getWorld();
            BlockPos pos = context.getBlockPos();
            PlayerEntity player = context.getPlayer();
            Hand hand = context.getHand();
            BlockHitResult hit = new BlockHitResult(context.getHitPos(), context.getSide(), pos, false);

            if (!world.isClient && player != null) {
                return tryToSpawnGolem(world, pos, player, hand, hit);
            }
            return ActionResult.PASS;
        }

        @Override
        public void appendTooltip(ItemStack stack, World world, List<Text> tooltip, TooltipContext context) {
            tooltip.add(new TranslatableText("item.golemacy.scroll_of_awakening.desc").formatted(Formatting.GRAY));
        }
    }

    // Helper method for spawning golems
    public static ActionResult tryToSpawnGolem(World world, BlockPos pos, PlayerEntity player, Hand hand, BlockHitResult hit) {
        // Placeholder implementation for spawning golems based on block structure
        return ActionResult.SUCCESS;
    }
}
