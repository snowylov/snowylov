
package com.example.bigdaddygolem;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.block.Blocks;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.passive.IronGolemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.TooltipContext;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.text.TranslatableText;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.registry.Registry;
import net.minecraft.world.World;

import java.util.List;

public class BigDaddyGolemMod implements ModInitializer {
    public static final String MOD_ID = "big_daddy_golem_mod";
    public static final EntityType<CleanGolemEntity> CLEAN_GOLEM = Registry.register(
            Registry.ENTITY_TYPE,
            new Identifier(MOD_ID, "clean_golem"),
            FabricEntityTypeBuilder.createMob().entityFactory(CleanGolemEntity::new).dimensions(EntityType.IRON_GOLEM.getDimensions()).build()
    );
    public static final EntityType<DaddyOTronEntity> DADDY_O_TRON = Registry.register(
            Registry.ENTITY_TYPE,
            new Identifier(MOD_ID, "daddy_o_tron"),
            FabricEntityTypeBuilder.createMob().entityFactory(DaddyOTronEntity::new).spawnGroup(SpawnGroup.MONSTER).dimensions(EntityType.IRON_GOLEM.getDimensions().scaled(10.0F)).build()
    );

    @Override
    public void onInitialize() {
        // Register clean golem entity attributes
        FabricDefaultAttributeRegistry.register(CLEAN_GOLEM, IronGolemEntity.createIronGolemAttributes());

        // Register Daddy-O-Tron entity attributes
        FabricDefaultAttributeRegistry.register(DADDY_O_TRON, IronGolemEntity.createIronGolemAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 5000.0) // Daddy-O-Tron has 5000 health
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 50.0) // Daddy-O-Tron deals 50 damage
        );
    }

    // Golem Entity Definitions
    public static class CleanGolemEntity extends IronGolemEntity {
        public CleanGolemEntity(EntityType<? extends IronGolemEntity> entityType, World world) {
            super(entityType, world);
        }

        @Override
        public void onDeath() {
            super.onDeath();
            // Summon Daddy-O-Tron on death
            if (!this.world.isClient) {
                DaddyOTronEntity daddyOTron = DADDY_O_TRON.create(world);
                if (daddyOTron != null) {
                    daddyOTron.refreshPositionAndAngles(this.getX(), this.getY(), this.getZ(), this.yaw, this.pitch);
                    world.spawnEntity(daddyOTron);
                }
            }
        }
    }

    public static class DaddyOTronEntity extends HostileEntity {
        public DaddyOTronEntity(EntityType<? extends HostileEntity> entityType, World world) {
            super(entityType, world);
        }

        @Override
        protected void initAttributes() {
            super.initAttributes();
            this.getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH).setBaseValue(5000.0);
            this.getAttributeInstance(EntityAttributes.GENERIC_ATTACK_DAMAGE).setBaseValue(50.0);
        }

        @Override
        public boolean isImmuneToExplosion() {
            // Daddy-O-Tron is immune to explosions
            return true;
        }
    }
}
