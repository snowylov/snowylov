package net.alex.illogical_energetics;

import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.minecraft.block.*;
import net.minecraft.item.*;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

public class ModBlocksItems {
    // Boolean Properties
    public static final BooleanProperty STICKY = BooleanProperty.of("sticky");
    public static final BooleanProperty MATCHING = BooleanProperty.of("matching");
    public static final BooleanProperty WATERLOGGED = BooleanProperty.of("waterlogged");
    public static final BooleanProperty VERTICAL_PLACEMENT = BooleanProperty.of("vertical_placement");
    public static final BooleanProperty HORIZONTAL_PLACEMENT = BooleanProperty.of("horizontal_placement");

    // Items
    public static final Item SUPERGLUE = new Item(new Item.Settings().group(ItemGroup.TOOLS));
    public static final Item ADVANCED_LOGISTICS_SOCKET_WRENCH = new Item(new Item.Settings().group(ItemGroup.TOOLS).maxCount(1).fireproof());
    public static final Item DEEP_REDSTONE_DUST = new Item(new Item.Settings().group(ItemGroup.REDSTONE));

    // Blocks
    public static final Block TURN_TABLE = new TurnTableBlock(FabricBlockSettings.of(Material.METAL).strength(2.0f).sounds(BlockSoundGroup.METAL));
    public static final Block STICKY_TURN_TABLE = new StickyTurnTableBlock(FabricBlockSettings.of(Material.METAL).strength(2.0f).sounds(BlockSoundGroup.METAL));
    public static final Block MECHANICAL_SLIDER = new MechanicalSliderBlock(FabricBlockSettings.of(Material.METAL).strength(3.0f).sounds(BlockSoundGroup.METAL));
    public static final Block REDSTONE_BLOCK_READER = new RedstoneBlockReaderBlock(FabricBlockSettings.of(Material.METAL).strength(3.0f).sounds(BlockSoundGroup.METAL).nonOpaque());
    public static final Block MAP_DISPLAY = new MapDisplayBlock(FabricBlockSettings.of(Material.WOOD).strength(1.0f).sounds(BlockSoundGroup.WOOD).nonOpaque());

    public static void registerAll() {
        // Register items
        Registry.register(Registry.ITEM, new Identifier(IllogicalEnergeticsMod.MOD_ID, "superglue"), SUPERGLUE);
        Registry.register(Registry.ITEM, new Identifier(IllogicalEnergeticsMod.MOD_ID, "advanced_logistics_socket_wrench"), ADVANCED_LOGISTICS_SOCKET_WRENCH);
        Registry.register(Registry.ITEM, new Identifier(IllogicalEnergeticsMod.MOD_ID, "deep_redstone_dust"), DEEP_REDSTONE_DUST);

        // Register blocks and block items
        Registry.register(Registry.BLOCK, new Identifier(IllogicalEnergeticsMod.MOD_ID, "turn_table"), TURN_TABLE);
        Registry.register(Registry.ITEM, new Identifier(IllogicalEnergeticsMod.MOD_ID, "turn_table"), new BlockItem(TURN_TABLE, new Item.Settings().group(ItemGroup.REDSTONE)));
        
        Registry.register(Registry.BLOCK, new Identifier(IllogicalEnergeticsMod.MOD_ID, "sticky_turn_table"), STICKY_TURN_TABLE);
        Registry.register(Registry.ITEM, new Identifier(IllogicalEnergeticsMod.MOD_ID, "sticky_turn_table"), new BlockItem(STICKY_TURN_TABLE, new Item.Settings().group(ItemGroup.REDSTONE)));

        Registry.register(Registry.BLOCK, new Identifier(IllogicalEnergeticsMod.MOD_ID, "mechanical_slider"), MECHANICAL_SLIDER);
        Registry.register(Registry.ITEM, new Identifier(IllogicalEnergeticsMod.MOD_ID, "mechanical_slider"), new BlockItem(MECHANICAL_SLIDER, new Item.Settings().group(ItemGroup.REDSTONE)));

        Registry.register(Registry.BLOCK, new Identifier(IllogicalEnergeticsMod.MOD_ID, "redstone_block_reader"), REDSTONE_BLOCK_READER);
        Registry.register(Registry.ITEM, new Identifier(IllogicalEnergeticsMod.MOD_ID, "redstone_block_reader"), new BlockItem(REDSTONE_BLOCK_READER, new Item.Settings().group(ItemGroup.REDSTONE)));

        Registry.register(Registry.BLOCK, new Identifier(IllogicalEnergeticsMod.MOD_ID, "map_display"), MAP_DISPLAY);
        Registry.register(Registry.ITEM, new Identifier(IllogicalEnergeticsMod.MOD_ID, "map_display"), new BlockItem(MAP_DISPLAY, new Item.Settings().group(ItemGroup.DECORATIONS)));
    }
}
