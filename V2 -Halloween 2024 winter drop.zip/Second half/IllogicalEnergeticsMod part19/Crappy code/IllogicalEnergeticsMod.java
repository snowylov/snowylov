package net.alex.illogical_energetics;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.fabricmc.fabric.api.registry.FlammableBlockRegistry;
import net.fabricmc.fabric.api.datagen.v1.FabricDataGenerator;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricBlockLootTableProvider;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricBlockModelProvider;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricBlockStateProvider;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricItemModelProvider;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.block.*;
import net.minecraft.item.*;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.registry.Registry;
import net.minecraft.world.World;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.BlockView;
import net.minecraft.world.tick.OrderedTick;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.map.MapItem;
import net.minecraft.item.map.MapState;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.world.WorldView;
import net.minecraft.world.level.LevelProperties;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

public class IllogicalEnergeticsMod implements ModInitializer {
    public static final String MOD_ID = "illogical_energetics";
    public static final BooleanProperty STICKY = BooleanProperty.of("sticky");
    public static final BooleanProperty MATCHING = BooleanProperty.of("matching");
    public static final BooleanProperty WATERLOGGED = BooleanProperty.of("waterlogged");
    public static final BooleanProperty VERTICAL_PLACEMENT = BooleanProperty.of("vertical_placement");
    public static final BooleanProperty HORIZONTAL_PLACEMENT = BooleanProperty.of("horizontal_placement");

    // Items
    public static final Item SUPERGLUE = new Item(new Item.Settings().group(ItemGroup.TOOLS));
    public static final Item ADVANCED_LOGISTICS_SOCKET_WRENCH = new Item(new Item.Settings().group(ItemGroup.TOOLS).maxCount(1).fireproof());
    public static final Item DEEP_REDSTONE_DUST = new Item(new Item.Settings().group(ItemGroup.REDSTONE));

    // Blocks
    public static final Block TURN_TABLE = new TurnTableBlock(FabricBlockSettings.of(Material.METAL).strength(2.0f).sounds(BlockSoundGroup.METAL));
    public static final Block STICKY_TURN_TABLE = new StickyTurnTableBlock(FabricBlockSettings.of(Material.METAL).strength(2.0f).sounds(BlockSoundGroup.METAL));
    public static final Block MECHANICAL_SLIDER = new MechanicalSliderBlock(FabricBlockSettings.of(Material.METAL).strength(3.0f).sounds(BlockSoundGroup.METAL));
    public static final Block REDSTONE_BLOCK_READER = new RedstoneBlockReaderBlock(FabricBlockSettings.of(Material.METAL).strength(3.0f).sounds(BlockSoundGroup.METAL).nonOpaque());
    public static final Block MAP_DISPLAY = new MapDisplayBlock(FabricBlockSettings.of(Material.WOOD).strength(1.0f).sounds(BlockSoundGroup.WOOD).nonOpaque());

    @Override
    public void onInitialize() {
        // Register items
        Registry.register(Registry.ITEM, new Identifier(MOD_ID, "superglue"), SUPERGLUE);
        Registry.register(Registry.ITEM, new Identifier(MOD_ID, "advanced_logistics_socket_wrench"), ADVANCED_LOGISTICS_SOCKET_WRENCH);
        Registry.register(Registry.ITEM, new Identifier(MOD_ID, "deep_redstone_dust"), DEEP_REDSTONE_DUST);

        // Register turn table blocks
        Registry.register(Registry.BLOCK, new Identifier(MOD_ID, "turn_table"), TURN_TABLE);
        Registry.register(Registry.ITEM, new Identifier(MOD_ID, "turn_table"), new BlockItem(TURN_TABLE, new Item.Settings().group(ItemGroup.REDSTONE)));
        
        Registry.register(Registry.BLOCK, new Identifier(MOD_ID, "sticky_turn_table"), STICKY_TURN_TABLE);
        Registry.register(Registry.ITEM, new Identifier(MOD_ID, "sticky_turn_table"), new BlockItem(STICKY_TURN_TABLE, new Item.Settings().group(ItemGroup.REDSTONE)));

        // Register mechanical slider block
        Registry.register(Registry.BLOCK, new Identifier(MOD_ID, "mechanical_slider"), MECHANICAL_SLIDER);
        Registry.register(Registry.ITEM, new Identifier(MOD_ID, "mechanical_slider"), new BlockItem(MECHANICAL_SLIDER, new Item.Settings().group(ItemGroup.REDSTONE)));

        // Register redstone block reader block
        Registry.register(Registry.BLOCK, new Identifier(MOD_ID, "redstone_block_reader"), REDSTONE_BLOCK_READER);
        Registry.register(Registry.ITEM, new Identifier(MOD_ID, "redstone_block_reader"), new BlockItem(REDSTONE_BLOCK_READER, new Item.Settings().group(ItemGroup.REDSTONE)));

        // Register map display block
        Registry.register(Registry.BLOCK, new Identifier(MOD_ID, "map_display"), MAP_DISPLAY);
        Registry.register(Registry.ITEM, new Identifier(MOD_ID, "map_display"), new BlockItem(MAP_DISPLAY, new Item.Settings().group(ItemGroup.DECORATIONS)));
    }

    // Fabric DataGen Classes
    public static void registerDataProviders(FabricDataGenerator dataGenerator) {
        dataGenerator.addProvider(new BlockStateGenerator(dataGenerator));
        dataGenerator.addProvider(new BlockModelGenerator(dataGenerator));
        dataGenerator.addProvider(new ItemModelGenerator(dataGenerator));
        dataGenerator.addProvider(new RecipeGenerator(dataGenerator));
        dataGenerator.addProvider(new LootTableGenerator(dataGenerator));
    }

    public static class BlockStateGenerator extends FabricBlockStateProvider {
        public BlockStateGenerator(FabricDataGenerator dataGenerator) {
            super(dataGenerator);
        }

        @Override
        protected void generateBlockState(Block block) {
            if (block == TURN_TABLE || block == STICKY_TURN_TABLE || block == MECHANICAL_SLIDER || block == REDSTONE_BLOCK_READER || block == MAP_DISPLAY) {
                getVariantBuilder(block).forAllStates(state -> ConfiguredModel.builder().modelFile(cubeAll(block)).build());
            }
        }
    }

    public static class BlockModelGenerator extends FabricBlockModelProvider {
        public BlockModelGenerator(FabricDataGenerator dataGenerator) {
            super(dataGenerator);
        }

        @Override
        protected void generateBlockModels() {
            cubeAll(TURN_TABLE);
            cubeAll(STICKY_TURN_TABLE);
            cubeAll(MECHANICAL_SLIDER);
            cubeAll(REDSTONE_BLOCK_READER);
            cubeAll(MAP_DISPLAY);
        }
    }

    public static class ItemModelGenerator extends FabricItemModelProvider {
        public ItemModelGenerator(FabricDataGenerator dataGenerator) {
            super(dataGenerator);
        }

        @Override
        protected void generateItemModels() {
            generatedItem(SUPERGLUE);
            generatedItem(ADVANCED_LOGISTICS_SOCKET_WRENCH);
            generatedItem(DEEP_REDSTONE_DUST);
            blockItemModel(TURN_TABLE);
            blockItemModel(STICKY_TURN_TABLE);
            blockItemModel(MECHANICAL_SLIDER);
            blockItemModel(REDSTONE_BLOCK_READER);
            blockItemModel(MAP_DISPLAY);
        }
    }

    public static class RecipeGenerator extends FabricRecipeProvider {
        public RecipeGenerator(FabricDataGenerator dataGenerator) {
            super(dataGenerator);
        }

        @Override
        protected void generateRecipes() {
            // Recipes for all items and blocks
            ShapedRecipeJsonFactory.create(TURN_TABLE)
                .pattern("###")
                .pattern("#C#")
                .pattern("###")
                .input('#', Items.COBBLESTONE)
                .input('C', Items.COPPER_INGOT)
                .criterion("has_cobblestone", conditionsFromItem(Items.COBBLESTONE))
                .offerTo(this::offerRecipe);
            ShapedRecipeJsonFactory.create(STICKY_TURN_TABLE)
                .pattern("###")
                .pattern("#S#")
                .pattern("###")
                .input('#', Items.COBBLESTONE)
                .input('S', SUPERGLUE)
                .criterion("has_superglue", conditionsFromItem(SUPERGLUE))
                .offerTo(this::offerRecipe);
        }
    }

    public static class LootTableGenerator extends FabricBlockLootTableProvider {
        public LootTableGenerator(FabricDataGenerator dataGenerator) {
            super(dataGenerator);
        }

        @Override
        protected void generateBlockLootTables() {
            addDrop(TURN_TABLE);
            addDrop(STICKY_TURN_TABLE);
            addDrop(MECHANICAL_SLIDER);
            addDrop(REDSTONE_BLOCK_READER);
            addDrop(MAP_DISPLAY);
        }
    }

    // Other classes like SuperGlueItem, TurnTableBlock, etc., remain unchanged
    public static class SuperGlueItem extends Item {
        public SuperGlueItem(Settings settings) {
            super(settings);
        }

        @Override
        public ActionResult useOnBlock(ItemUsageContext context) {
            World world = context.getWorld();
            BlockPos pos = context.getBlockPos();
            PlayerEntity player = context.getPlayer();
            BlockState state = world.getBlockState(pos);

            if (state.getBlock() instanceof PlanksBlock || state.getBlock() instanceof WoolBlock || state.getBlock() instanceof ConcreteBlock) {
                world.setBlockState(pos, state.with(STICKY, true));
                if (!player.isCreative()) {
                    context.getStack().decrement(1);
                }
                return ActionResult.SUCCESS;
            }

            return ActionResult.PASS;
        }
    }

    // The rest of the original classes like TurnTableBlock, StickyTurnTableBlock, MechanicalSliderBlock, etc. are unchanged.
    
    public static class MapDisplayBlockEntity extends BlockEntity {
        private MapState mapState;

        public MapDisplayBlockEntity(BlockPos pos, BlockState state) {
            super(ModBlockEntities.MAP_DISPLAY_BLOCK_ENTITY, pos, state);
        }

        public void setMapState(MapState mapState) {
            this.mapState = mapState;
            markDirty();
        }

        public MapState getMapState() {
            return mapState;
        }
    }
}
