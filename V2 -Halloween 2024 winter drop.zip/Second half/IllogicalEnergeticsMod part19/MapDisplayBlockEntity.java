package net.alex.illogical_energetics;

import net.minecraft.block.BlockEntityProvider;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.item.map.MapState;

public class MapDisplayBlockEntity extends BlockEntity {
    private MapState mapState;

    public MapDisplayBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.MAP_DISPLAY_BLOCK_ENTITY, pos, state);
    }

    public void setMapState(MapState mapState) {
        this.mapState = mapState;
        markDirty();
    }

    public MapState getMapState() {
        return mapState;
    }
}
