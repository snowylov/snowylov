package net.alex.illogical_energetics;

import net.fabricmc.fabric.api.datagen.v1.FabricDataGenerator;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricBlockLootTableProvider;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricBlockModelProvider;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricBlockStateProvider;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricItemModelProvider;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.data.client.model.BlockStateModelGenerator;
import net.minecraft.data.server.recipe.RecipeJsonProvider;
import net.minecraft.util.Identifier;

import java.util.function.Consumer;

public class IllogicalEnergeticsDataGen {
    public static void registerDataProviders(FabricDataGenerator dataGenerator) {
        dataGenerator.addProvider(new BlockStateGenerator(dataGenerator));
        dataGenerator.addProvider(new BlockModelGenerator(dataGenerator));
        dataGenerator.addProvider(new ItemModelGenerator(dataGenerator));
        dataGenerator.addProvider(new RecipeGenerator(dataGenerator));
        dataGenerator.addProvider(new LootTableGenerator(dataGenerator));
    }

    public static class BlockStateGenerator extends FabricBlockStateProvider {
        public BlockStateGenerator(FabricDataGenerator dataGenerator) {
            super(dataGenerator);
        }

        @Override
        protected void generateBlockStateModels(BlockStateModelGenerator generator) {
            generator.registerCubeAllModelTexturePool(ModBlocksItems.TURN_TABLE);
            generator.registerCubeAllModelTexturePool(ModBlocksItems.STICKY_TURN_TABLE);
            generator.registerCubeAllModelTexturePool(ModBlocksItems.MECHANICAL_SLIDER);
            generator.registerCubeAllModelTexturePool(ModBlocksItems.REDSTONE_BLOCK_READER);
            generator.registerCubeAllModelTexturePool(ModBlocksItems.MAP_DISPLAY);
        }
    }

    public static class BlockModelGenerator extends FabricBlockModelProvider {
        public BlockModelGenerator(FabricDataGenerator dataGenerator) {
            super(dataGenerator);
        }

        @Override
        protected void generateBlockModels() {
            registerSimpleCube(ModBlocksItems.TURN_TABLE);
            registerSimpleCube(ModBlocksItems.STICKY_TURN_TABLE);
            registerSimpleCube(ModBlocksItems.MECHANICAL_SLIDER);
            registerSimpleCube(ModBlocksItems.REDSTONE_BLOCK_READER);
            registerSimpleCube(ModBlocksItems.MAP_DISPLAY);
        }
    }

    public static class ItemModelGenerator extends FabricItemModelProvider {
        public ItemModelGenerator(FabricDataGenerator dataGenerator) {
            super(dataGenerator);
        }

        @Override
        protected void generateItemModels() {
            generatedItem(ModBlocksItems.SUPERGLUE);
            generatedItem(ModBlocksItems.ADVANCED_LOGISTICS_SOCKET_WRENCH);
            generatedItem(ModBlocksItems.DEEP_REDSTONE_DUST);
            blockItemModel(ModBlocksItems.TURN_TABLE);
            blockItemModel(ModBlocksItems.STICKY_TURN_TABLE);
            blockItemModel(ModBlocksItems.MECHANICAL_SLIDER);
            blockItemModel(ModBlocksItems.REDSTONE_BLOCK_READER);
            blockItemModel(ModBlocksItems.MAP_DISPLAY);
        }
    }

    public static class RecipeGenerator extends FabricRecipeProvider {
        public RecipeGenerator(FabricDataGenerator dataGenerator) {
            super(dataGenerator);
        }

        @Override
        protected void generateRecipes(Consumer<RecipeJsonProvider> consumer) {
            // Recipes for all items and blocks
            ShapedRecipeJsonFactory.create(ModBlocksItems.TURN_TABLE)
                .pattern("###")
                .pattern("#C#")
                .pattern("###")
                .input('#', Items.COBBLESTONE)
                .input('C', Items.COPPER_INGOT)
                .criterion("has_cobblestone", conditionsFromItem(Items.COBBLESTONE))
                .offerTo(consumer);
            ShapedRecipeJsonFactory.create(ModBlocksItems.STICKY_TURN_TABLE)
                .pattern("###")
                .pattern("#S#")
                .pattern("###")
                .input('#', Items.COBBLESTONE)
                .input('S', ModBlocksItems.SUPERGLUE)
                .criterion("has_superglue", conditionsFromItem(ModBlocksItems.SUPERGLUE))
                .offerTo(consumer);
        }
    }

    public static class LootTableGenerator extends FabricBlockLootTableProvider {
        public LootTableGenerator(FabricDataGenerator dataGenerator) {
            super(dataGenerator);
        }

        @Override
        protected void generateBlockLootTables() {
            addDrop(ModBlocksItems.TURN_TABLE);
            addDrop(ModBlocksItems.STICKY_TURN_TABLE);
            addDrop(ModBlocksItems.MECHANICAL_SLIDER);
            addDrop(ModBlocksItems.REDSTONE_BLOCK_READER);
            addDrop(ModBlocksItems.MAP_DISPLAY);
        }
    }
}
