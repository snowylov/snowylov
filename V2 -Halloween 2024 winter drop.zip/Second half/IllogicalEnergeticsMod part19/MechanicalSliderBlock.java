package net.alex.illogical_energetics;

import net.minecraft.block.BlockWithEntity;
import net.minecraft.block.BlockState;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import java.util.HashSet;
import java.util.Set;

public class MechanicalSliderBlock extends BlockWithEntity implements Waterloggable {
    public MechanicalSliderBlock(Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, Hand hand, BlockHitResult hit) {
        if (!world.isClient) {
            if (world.isReceivingRedstonePower(pos)) {
                startSliding(world, pos, Direction.FORWARD);
            } else {
                startSliding(world, pos, Direction.BACKWARD);
            }
        }
        return ActionResult.SUCCESS;
    }

    private void startSliding(World world, BlockPos pos, Direction direction) {
        Set<BlockPos> toSlide = collectConnectedBlocks(world, pos.up(), new HashSet<>());
        slideBlocks(world, toSlide, direction);
    }

    private Set<BlockPos> collectConnectedBlocks(World world, BlockPos startPos, Set<BlockPos> visited) {
        if (!visited.contains(startPos) && !world.getBlockState(startPos).isAir()) {
            visited.add(startPos);
            BlockPos[] directions = { startPos.north(), startPos.south(), startPos.east(), startPos.west(), startPos.up(), startPos.down() };
            for (BlockPos direction : directions) {
                if (world.getBlockState(direction).getBlock() instanceof TurnTableBlock ||
                        world.getBlockState(direction).getBlock() instanceof StickyTurnTableBlock ||
                        world.getBlockState(direction).getBlock() instanceof MechanicalSliderBlock) {
                    continue; // Do not add other turntables or sliders
                }
                if (world.getBlockState(direction).get(Properties.STICKY)) {
                    collectConnectedBlocks(world, direction, visited);
                }
            }
        }
        return visited;
    }

    private void slideBlocks(World world, Set<BlockPos> toSlide, Direction direction) {
        for (BlockPos pos : toSlide) {
            BlockPos newPos = pos.offset(direction);
            BlockState blockState = world.getBlockState(pos);
            world.setBlockState(newPos, blockState);
            world.removeBlock(pos, false);
        }
    }

    private enum Direction {
        FORWARD,
        BACKWARD
    }
}
