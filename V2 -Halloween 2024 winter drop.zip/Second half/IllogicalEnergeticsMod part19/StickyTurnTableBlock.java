package net.alex.illogical_energetics;

import net.minecraft.block.BlockState;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import java.util.Random;

public class StickyTurnTableBlock extends TurnTableBlock {
    public StickyTurnTableBlock(Settings settings) {
        super(settings);
    }

    @Override
    public void neighborUpdate(BlockState state, World world, BlockPos pos, Block block, BlockPos fromPos, boolean notify) {
        super.neighborUpdate(state, world, pos, block, fromPos, notify);
        if (world.isReceivingRedstonePower(pos) || isRedstoneBlockAbove(world, pos)) {
            Direction rotationDirection = getRotationDirection(world, pos);
            startSmoothRotation(world, pos, rotationDirection);
        }
    }

    @Override
    public void scheduledTick(BlockState state, ServerWorld world, BlockPos pos, Random random) {
        if (world.isReceivingRedstonePower(pos) || isRedstoneBlockAbove(world, pos)) {
            Direction rotationDirection = getRotationDirection(world, pos);
            startSmoothRotation(world, pos, rotationDirection);
        }
    }
}
