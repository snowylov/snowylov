package net.alex.illogical_energetics;

import net.minecraft.block.BlockWithEntity;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.state.property.Properties;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;

public class RedstoneBlockReaderBlock extends BlockWithEntity {
    public RedstoneBlockReaderBlock(Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, Hand hand, BlockHitResult hit) {
        return ActionResult.SUCCESS;  // No specific interaction for now, but this could be expanded.
    }

    @Override
    public void neighborUpdate(BlockState state, World world, BlockPos pos, Block block, BlockPos fromPos, boolean notify) {
        Direction facing = state.get(Properties.HORIZONTAL_FACING);
        BlockPos leftPos = pos.offset(facing.rotateYCounterclockwise());
        BlockPos rightPos = pos.offset(facing.rotateYClockwise());
        BlockState leftState = world.getBlockState(leftPos);
        BlockState rightState = world.getBlockState(rightPos);

        boolean matching = leftState.equals(rightState);
        if (matching) {
            world.setBlockState(pos, state.with(Properties.POWERED, true));
            world.updateNeighborsAlways(pos, this);
        } else {
            world.setBlockState(pos, state.with(Properties.POWERED, false));
            world.updateNeighborsAlways(pos, this);
        }
    }
}
