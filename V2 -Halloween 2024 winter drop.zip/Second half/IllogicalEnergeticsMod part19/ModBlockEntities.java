package net.alex.illogical_energetics;

import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

public class ModBlockEntities {
    public static BlockEntityType<MapDisplayBlockEntity> MAP_DISPLAY_BLOCK_ENTITY;

    public static void registerBlockEntities() {
        MAP_DISPLAY_BLOCK_ENTITY = Registry.register(
            Registry.BLOCK_ENTITY_TYPE,
            new Identifier(IllogicalEnergeticsMod.MOD_ID, "map_display_block_entity"),
            FabricBlockEntityTypeBuilder.create(MapDisplayBlockEntity::new, IllogicalEnergeticsMod.MAP_DISPLAY).build(null)
        );
    }
}
