package net.alex.illogical_energetics;

import net.fabricmc.api.ModInitializer;

public class IllogicalEnergeticsMod implements ModInitializer {
    public static final String MOD_ID = "illogical_energetics";

    @Override
    public void onInitialize() {
        // Register blocks, items, and entities in their respective classes
        ModBlocksItems.registerAll();
        ModBlockEntities.registerBlockEntities();
    }
}
