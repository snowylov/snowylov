package net.alex.illogical_energetics;

import net.minecraft.block.Block;
import net.minecraft.block.BlockWithEntity;
import net.minecraft.block.BlockState;
import net.minecraft.block.Waterloggable;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.state.property.Properties;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;

import java.util.HashSet;
import java.util.Set;

public class TurnTableBlock extends BlockWithEntity implements Waterloggable {
    public TurnTableBlock(Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, Hand hand, BlockHitResult hit) {
        if (!world.isClient) {
            if (world.isReceivingRedstonePower(pos) || isRedstoneBlockAbove(world, pos)) {
                Direction rotationDirection = getRotationDirection(world, pos);
                startSmoothRotation(world, pos, rotationDirection);
            }
        }
        return ActionResult.SUCCESS;
    }

    private void startSmoothRotation(World world, BlockPos pos, Direction rotationDirection) {
        Set<BlockPos> toRotate = collectConnectedBlocks(world, pos.up(), new HashSet<>());
        scheduleSmoothRotation(world, toRotate, 0, rotationDirection);
    }

    private Set<BlockPos> collectConnectedBlocks(World world, BlockPos startPos, Set<BlockPos> visited) {
        if (!visited.contains(startPos) && !world.getBlockState(startPos).isAir()) {
            visited.add(startPos);
            BlockPos[] directions = { startPos.north(), startPos.south(), startPos.east(), startPos.west(), startPos.up(), startPos.down() };
            for (BlockPos direction : directions) {
                if (world.getBlockState(direction).getBlock() instanceof TurnTableBlock ||
                        world.getBlockState(direction).getBlock() instanceof StickyTurnTableBlock ||
                        world.getBlockState(direction).getBlock() instanceof MechanicalSliderBlock) {
                    continue; // Do not add other turntables or sliders
                }
                if (world.getBlockState(direction).get(Properties.STICKY)) {
                    collectConnectedBlocks(world, direction, visited);
                }
            }
        }
        return visited;
    }

    private void scheduleSmoothRotation(World world, Set<BlockPos> toRotate, int step, Direction rotationDirection) {
        if (step >= 8) { // Stop after full 360-degree rotation (8 steps of 45 degrees each)
            return;
        }
        for (BlockPos pos : toRotate) {
            BlockState blockState = world.getBlockState(pos);
            BlockState rotatedState = blockState.rotate(world, pos, rotationDirection);
            world.setBlockState(pos, rotatedState);
        }
        world.getBlockTickScheduler().schedule(pos, world.getBlockState(toRotate.iterator().next()).getBlock(), 5); // Schedule smooth animation step every 5 ticks
        scheduleSmoothRotation(world, toRotate, step + 1, rotationDirection);
    }

    private boolean isRedstoneBlockAbove(World world, BlockPos pos) {
        BlockState aboveState = world.getBlockState(pos.up());
        return aboveState.isOf(Blocks.REDSTONE_BLOCK);
    }

    private Direction getRotationDirection(World world, BlockPos pos) {
        BlockState belowState = world.getBlockState(pos.down());
        if (belowState.getBlock() instanceof LeverBlock && belowState.get(Properties.POWERED)) {
            return Direction.COUNTERCLOCKWISE_45;
        }
        return Direction.CLOCKWISE_45;
    }
}
