package net.alex.illogical_energetics;

import net.minecraft.block.BlockWithEntity;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.map.MapItem;
import net.minecraft.item.map.MapState;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.HashSet;
import java.util.Set;

public class MapDisplayBlock extends BlockWithEntity {
    public MapDisplayBlock(Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, Hand hand, BlockHitResult hit) {
        if (!world.isClient) {
            ItemStack itemStack = player.getStackInHand(hand);
            if (itemStack.getItem() instanceof MapItem) {
                NbtCompound nbt = itemStack.getOrCreateNbt();
                if (nbt != null) {
                    int mapId = nbt.getInt("map");
                    MapState mapState = MapItem.getOrCreateMapState(mapId, world);
                    if (mapState != null) {
                        // Combine with existing map display blocks to extend map size
                        extendMap(world, pos, mapState);
                        return ActionResult.SUCCESS;
                    }
                }
            }
        }
        return ActionResult.PASS;
    }

    private void extendMap(World world, BlockPos pos, MapState mapState) {
        Set<BlockPos> visited = new HashSet<>();
        collectConnectedMapBlocks(world, pos, visited);
        for (BlockPos blockPos : visited) {
            BlockEntity blockEntity = world.getBlockEntity(blockPos);
            if (blockEntity instanceof MapDisplayBlockEntity) {
                ((MapDisplayBlockEntity) blockEntity).setMapState(mapState);
            }
        }
    }

    private void collectConnectedMapBlocks(World world, BlockPos startPos, Set<BlockPos> visited) {
        if (!visited.contains(startPos) && world.getBlockState(startPos).getBlock() instanceof MapDisplayBlock) {
            visited.add(startPos);
            BlockPos[] directions = { startPos.north(), startPos.south(), startPos.east(), startPos.west() };
            for (BlockPos direction : directions) {
                collectConnectedMapBlocks(world, direction, visited);
            }
        }
    }

    @Override
    public BlockEntity createBlockEntity(BlockPos pos, BlockState state) {
        return new MapDisplayBlockEntity(pos, state);
    }
}
