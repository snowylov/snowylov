
package com.example.armormod;

import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ArmorMaterial;
import net.minecraft.item.Items;
import net.minecraft.recipe.Ingredient;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

public class CrimsonCultArcherArmorMaterial implements ArmorMaterial {

    private static final int[] BASE_DURABILITY = new int[]{37, 40, 36, 33}; // Based on Netherite
    private static final int[] PROTECTION_VALUES = new int[]{3, 8, 6, 3};  // Based on Netherite

    @Override
    public int getDurability(EquipmentSlot slot) {
        return BASE_DURABILITY[slot.getEntitySlotId()];
    }

    @Override
    public int getProtectionAmount(EquipmentSlot slot) {
        return PROTECTION_VALUES[slot.getEntitySlotId()];
    }

    @Override
    public int getEnchantability() {
        return 15; // Netherite enchantability
    }

    @Override
    public SoundEvent getEquipSound() {
        return SoundEvents.ITEM_ARMOR_EQUIP_NETHERITE;
    }

    @Override
    public Ingredient getRepairIngredient() {
        return Ingredient.ofItems(Items.NETHERITE_INGOT);
    }

    @Override
    public String getName() {
        return "crimson_cult_archer_armor_archer_armor_archer";
    }

    @Override
    public float getToughness() {
        return 3.0F; // Netherite toughness
    }

    @Override
    public float getKnockbackResistance() {
        return 0.1F; // Netherite knockback resistance
    }
}
