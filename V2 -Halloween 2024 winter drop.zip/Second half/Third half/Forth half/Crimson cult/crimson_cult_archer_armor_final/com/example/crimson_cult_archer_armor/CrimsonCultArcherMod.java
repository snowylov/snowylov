
package com.example.armormod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ArmorMaterial;
import net.minecraft.item.ItemGroup;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

public class CrimsonCultArcherMod implements ModInitializer {

    public static final String MODID = "crimson_cult_archer_armor";
    
    // Define the Crimson Cult Archer armor material
    public static final ArmorMaterial CRIMSON_CULT_ARCHER_MATERIAL = new CrimsonCultArcherArmorMaterial();

    // Define the armor items
    public static final ArmorItem CRIMSON_CULT_ARCHER_HELMET = new ArmorItem(CRIMSON_CULT_ARCHER_MATERIAL, ArmorItem.HEAD_SLOT, new FabricItemSettings().group(ItemGroup.COMBAT));
    public static final ArmorItem CRIMSON_CULT_ARCHER_CHESTPLATE_1 = new ArmorItem(CRIMSON_CULT_ARCHER_MATERIAL, ArmorItem.CHEST_SLOT, new FabricItemSettings().group(ItemGroup.COMBAT));
    public static final ArmorItem CRIMSON_CULT_ARCHER_CHESTPLATE_2 = new ArmorItem(CRIMSON_CULT_ARCHER_MATERIAL, ArmorItem.CHEST_SLOT, new FabricItemSettings().group(ItemGroup.COMBAT));
    public static final ArmorItem CRIMSON_CULT_ARCHER_LEGGINGS = new ArmorItem(CRIMSON_CULT_ARCHER_MATERIAL, ArmorItem.LEGS_SLOT, new FabricItemSettings().group(ItemGroup.COMBAT));
    public static final ArmorItem CRIMSON_CULT_ARCHER_BOOTS = new ArmorItem(CRIMSON_CULT_ARCHER_MATERIAL, ArmorItem.FEET_SLOT, new FabricItemSettings().group(ItemGroup.COMBAT));

    @Override
    public void onInitialize() {
        // Register the armor items
        Registry.register(Registry.ITEM, new Identifier(MODID, "crimson_cult_archer_armor_archer_armor_archer_helmet"), CRIMSON_CULT_ARCHER_HELMET);
        Registry.register(Registry.ITEM, new Identifier(MODID, "crimson_cult_archer_armor_archer_armor_archer_chestplate_1"), CRIMSON_CULT_ARCHER_CHESTPLATE_1);
        Registry.register(Registry.ITEM, new Identifier(MODID, "crimson_cult_archer_armor_archer_armor_archer_chestplate_2"), CRIMSON_CULT_ARCHER_CHESTPLATE_2);
        Registry.register(Registry.ITEM, new Identifier(MODID, "crimson_cult_archer_armor_archer_armor_archer_leggings"), CRIMSON_CULT_ARCHER_LEGGINGS);
        Registry.register(Registry.ITEM, new Identifier(MODID, "crimson_cult_archer_armor_archer_armor_archer_boots"), CRIMSON_CULT_ARCHER_BOOTS);

        // Setup Fabric Data Generation (Item models, language files, etc.)
        setupDataGeneration();
    }

    private void setupDataGeneration() {
        // Data generation setup can be expanded here if needed
    }
}
