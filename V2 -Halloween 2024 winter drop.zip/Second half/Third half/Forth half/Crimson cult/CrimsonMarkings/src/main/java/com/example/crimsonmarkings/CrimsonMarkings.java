package com.example.crimsonmarkings;

import com.mojang.serialization.Codec;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.entity.FabricEntityTypeBuilder;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.Material;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.attribute.EntityDimensions;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.item.*;
import net.minecraft.recipe.Ingredient;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.structure.StructurePiece;
import net.minecraft.structure.StructurePieceType;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockBox;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.registry.Registry;
import net.minecraft.util.registry.RegistryEntry;
import net.minecraft.util.registry.RegistryKey;
import net.minecraft.world.StructureWorldAccess;
import net.minecraft.world.biome.BiomeKeys;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkPos;
import net.minecraft.world.gen.GenerationStep;
import net.minecraft.world.gen.feature.*;
import net.minecraft.world.gen.placementmodifier.PlacementModifier;
import net.minecraft.world.gen.placementmodifier.PlacementModifiers;

import java.util.List;
import java.util.Random;

public class CrimsonMarkings implements ModInitializer {

    @Override
    public void onInitialize() {
        ModBlocks.registerBlocks();
        ModItems.registerItems();
        ModEntities.registerEntities();
        ModFeatures.registerFeatures();
        registerStructures();
        ServerLifecycleEvents.SERVER_STARTING.register(server -> {
            FabricDataGenerator dataGenerator = new FabricDataGenerator(server.getSaveProperties().getLevelName(), false);
            DataGenerator.registerDataGenerators(dataGenerator);
            dataGenerator.run();
        });
    }

    private void registerStructures() {
        ConfiguredFeature<?, ?> toriiFeature = ModFeatures.TORII_FEATURE.configure(FeatureConfig.DEFAULT);
        PlacedFeature placedToriiFeature = new PlacedFeature(
                RegistryEntry.of(toriiFeature),
                List.of(PlacementModifiers.HEIGHTMAP_WORLD_SURFACE, PlacementModifiers.SQUARE, PlacementModifiers.spread())
        );

        Registry.register(BuiltinRegistries.CONFIGURED_FEATURE, new Identifier("crimson_markings", "torii_feature"), toriiFeature);
        Registry.register(BuiltinRegistries.PLACED_FEATURE, new Identifier("crimson_markings", "torii_feature"), placedToriiFeature);

        BiomeModifications.addFeature(
                BiomeSelectors.includeByKey(BiomeKeys.CHERRY_GROVE),
                GenerationStep.Feature.SURFACE_STRUCTURES,
                RegistryKey.of(Registry.PLACED_FEATURE_KEY, new Identifier("crimson_markings", "torii_feature"))
        );
    }

    public static class ModBlocks {
        public static final Block TAINTED_ZOMBIE_SHARK_SPAWNER = new TaintedZombieSharkSpawnerBlock(Block.Settings.of(Material.METAL).strength(3.0F, 9.0F));

        public static void registerBlocks() {
            Registry.register(Registry.BLOCK, new Identifier("crimson_markings", "tainted_zombie_shark_spawner"), TAINTED_ZOMBIE_SHARK_SPAWNER);
        }
    }

    public static class ModItems {
        public static final Item FRAGMENT_OF_IMAGINATION = new Item(new Item.Settings().group(ItemGroup.MISC));
        public static final Item TAINTED_CHALK = new Item(new Item.Settings().group(ItemGroup.MISC));
        public static final Item CRIMSON_CHALK = new Item(new Item.Settings().group(ItemGroup.MISC));
        public static final Item CORALIUM_INGOT = new Item(new Item.Settings().group(ItemGroup.MISC));
        public static final Item CORALIUM_NUGGET = new Item(new Item.Settings().group(ItemGroup.MISC));
        public static final ToolItem CORALIUM_SWORD = new SwordItem(ModToolMaterials.CORALIUM, 3, -2.4F, new Item.Settings().group(ItemGroup.COMBAT));
        public static final ToolItem CORALIUM_PICKAXE = new PickaxeItem(ModToolMaterials.CORALIUM, 1, -2.8F, new Item.Settings().group(ItemGroup.TOOLS));
        public static final ToolItem CORALIUM_AXE = new AxeItem(ModToolMaterials.CORALIUM, 5, -3.0F, new Item.Settings().group(ItemGroup.TOOLS));
        public static final ToolItem CORALIUM_SHOVEL = new ShovelItem(ModToolMaterials.CORALIUM, 1.5F, -3.0F, new Item.Settings().group(ItemGroup.TOOLS));
        public static final ToolItem CORALIUM_HOE = new HoeItem(ModToolMaterials.CORALIUM, -3, 0.0F, new Item.Settings().group(ItemGroup.TOOLS));
        public static final ArmorItem CORALIUM_HELMET = new ArmorItem(ModArmorMaterials.CORALIUM, EquipmentSlot.HEAD, new Item.Settings().group(ItemGroup.COMBAT));
        public static final ArmorItem CORALIUM_CHESTPLATE = new ArmorItem(ModArmorMaterials.CORALIUM, EquipmentSlot.CHEST, new Item.Settings().group(ItemGroup.COMBAT));
        public static final ArmorItem CORALIUM_LEGGINGS = new ArmorItem(ModArmorMaterials.CORALIUM, EquipmentSlot.LEGS, new Item.Settings().group(ItemGroup.COMBAT));
        public static final ArmorItem CORALIUM_BOOTS = new ArmorItem(ModArmorMaterials.CORALIUM, EquipmentSlot.FEET, new Item.Settings().group(ItemGroup.COMBAT));
        public static final Item SHETTY_WAZOOS_HEAD = new Item(new Item.Settings().group(ItemGroup.MISC));

        public static void registerItems() {
            Registry.register(Registry.ITEM, new Identifier("crimson_markings", "fragment_of_imagination"), FRAGMENT_OF_IMAGINATION);
            Registry.register(Registry.ITEM, new Identifier("crimson_markings", "tainted_chalk"), TAINTED_CHALK);
            Registry.register(Registry.ITEM, new Identifier("crimson_markings", "crimson_chalk"), CRIMSON_CHALK);
            Registry.register(Registry.ITEM, new Identifier("crimson_markings", "coralium_ingot"), CORALIUM_INGOT);
            Registry.register(Registry.ITEM, new Identifier("crimson_markings", "coralium_nugget"), CORALIUM_NUGGET);
            Registry.register(Registry.ITEM, new Identifier("crimson_markings", "coralium_sword"), CORALIUM_SWORD);
            Registry.register(Registry.ITEM, new Identifier("crimson_markings", "coralium_pickaxe"), CORALIUM_PICKAXE);
            Registry.register(Registry.ITEM, new Identifier("crimson_markings", "coralium_axe"), CORALIUM_AXE);
            Registry.register(Registry.ITEM, new Identifier("crimson_markings", "coralium_shovel"), CORALIUM_SHOVEL);
            Registry.register(Registry.ITEM, new Identifier("crimson_markings", "coralium_hoe"), CORALIUM_HOE);
            Registry.register(Registry.ITEM, new Identifier("crimson_markings", "coralium_helmet"), CORALIUM_HELMET);
            Registry.register(Registry.ITEM, new Identifier("crimson_markings", "coralium_chestplate"), CORALIUM_CHESTPLATE);
            Registry.register(Registry.ITEM, new Identifier("crimson_markings", "coralium_leggings"), CORALIUM_LEGGINGS);
            Registry.register(Registry.ITEM, new Identifier("crimson_markings", "coralium_boots"), CORALIUM_BOOTS);
            Registry.register(Registry.ITEM, new Identifier("crimson_markings", "shetty_wazoos_head"), SHETTY_WAZOOS_HEAD);
        }
    }

    public static class ModEntities {
        public static final EntityType<TaintedZombieSharkEntity> TAINTED_ZOMBIE_SHARK = Registry.register(
            Registry.ENTITY_TYPE,
            new Identifier("crimson_markings", "tainted_zombie_shark"),
            FabricEntityTypeBuilder.create(SpawnGroup.MONSTER, TaintedZombieSharkEntity::new)
                .dimensions(EntityDimensions.fixed(0.6F, 1.95F))
                .build()
        );

        public static void registerEntities() {
            FabricDefaultAttributeRegistry.register(TAINTED_ZOMBIE_SHARK, TaintedZombieSharkEntity.createMobAttributes());
        }
    }

    public static class ModFeatures {
        public static final Feature<DefaultFeatureConfig> TORII_FEATURE = new ToriiFeature(DefaultFeatureConfig.CODEC);

        public static void registerFeatures() {
            Registry.register(Registry.FEATURE, new Identifier("crimson_markings", "torii_feature"), TORII_FEATURE);
            Registry.register(BuiltinRegistries.CONFIGURED_FEATURE, new Identifier("crimson_markings", "torii_feature"), TORII_FEATURE.configure(FeatureConfig.DEFAULT));
            Registry.register(BuiltinRegistries.PLACED_FEATURE, new Identifier("crimson_markings", "torii_feature"), new PlacedFeature(RegistryEntry.of(TORII_FEATURE.configure(FeatureConfig.DEFAULT)), List.of(PlacementModifiers.HEIGHTMAP_WORLD_SURFACE, PlacementModifiers.SQUARE, PlacementModifiers.spread())));
        }
    }

    public static class ModToolMaterials implements ToolMaterial {
        public static final ToolMaterial CORALIUM = new ModToolMaterials(3, 2031, 8.0F, 3.0F, 15, Ingredient.ofItems(ModItems.CORALIUM_INGOT));

        private final int miningLevel;
        private final int itemDurability;
        private final float miningSpeed;
        private final float attackDamage;
        private final int enchantability;
        private final Ingredient repairIngredient;

        ModToolMaterials(int miningLevel, int itemDurability, float miningSpeed, float attackDamage, int enchantability, Ingredient repairIngredient) {
            this.miningLevel = miningLevel;
            this.itemDurability = itemDurability;
            this.miningSpeed = miningSpeed;
            this.attackDamage = attackDamage;
            this.enchantability = enchantability;
            this.repairIngredient = repairIngredient;
        }

        @Override
        public int getDurability() {
            return this.itemDurability;
        }

        @Override
        public float getMiningSpeedMultiplier() {
            return this.miningSpeed;
        }

        @Override
        public float getAttackDamage() {
            return this.attackDamage;
        }

        @Override
        public int getMiningLevel() {
            return this.miningLevel;
        }

        @Override
        public int getEnchantability() {
            return this.enchantability;
        }

        @Override
        public Ingredient getRepairIngredient() {
            return this.repairIngredient;
        }
    }

    public static class ModArmorMaterials implements ArmorMaterial {
        public static final ArmorMaterial CORALIUM = new ModArmorMaterials("coralium", 33, new int[]{3, 6, 8, 3}, 15, SoundEvents.ITEM_ARMOR_EQUIP_DIAMOND, 2.0F, 0.1F, Ingredient.ofItems(ModItems.CORALIUM_INGOT));

        private static final int[] BASE_DURABILITY = new int[]{13, 15, 16, 11};
        private final String name;
        private final int durabilityMultiplier;
        private final int[] protectionAmounts;
        private final int enchantability;
        private final SoundEvent equipSound;
        private final float toughness;
        private final float knockbackResistance;
        private final Ingredient repairIngredient;

        ModArmorMaterials(String name, int durabilityMultiplier, int[] protectionAmounts, int enchantability, SoundEvent equipSound, float toughness, float knockbackResistance, Ingredient repairIngredient) {
            this.name = name;
            this.durabilityMultiplier = durabilityMultiplier;
            this.protectionAmounts = protectionAmounts;
            this.enchantability = enchantability;
            this.equipSound = equipSound;
            this.toughness = toughness;
            this.knockbackResistance = knockbackResistance;
            this.repairIngredient = repairIngredient;
        }

        @Override
        public int getDurability(EquipmentSlot slot) {
            return BASE_DURABILITY[slot.getEntitySlotId()] * this.durabilityMultiplier;
        }

        @Override
        public int getProtectionAmount(EquipmentSlot slot) {
            return this.protectionAmounts[slot.getEntitySlotId()];
        }

        @Override
        public int getEnchantability() {
            return this.enchantability;
        }

        @Override
        public SoundEvent getEquipSound() {
            return this.equipSound;
        }

        @Override
        public Ingredient getRepairIngredient() {
            return this.repairIngredient;
        }

        @Override
        public String getName() {
            return this.name;
        }

        @Override
        public float getToughness() {
            return this.toughness;
        }

        @Override
        public float getKnockbackResistance() {
            return this.knockbackResistance;
        }
    }

    public static class TaintedZombieSharkEntity extends ZombieEntity {
        public TaintedZombieSharkEntity(EntityType<? extends ZombieEntity> entityType, World world) {
            super(entityType, world);
        }

        public static DefaultAttributeContainer.Builder createMobAttributes() {
            return ZombieEntity.createZombieAttributes().add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.35D).add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 6.0D);
        }
    }

    public static class ToriiFeature extends Feature<DefaultFeatureConfig> {

        public ToriiFeature(Codec<DefaultFeatureConfig> configCodec) {
            super(configCodec);
        }

        @Override
        public boolean generate(FeatureContext<DefaultFeatureConfig> context) {
            BlockPos pos = context.getOrigin();
            StructureWorldAccess world = context.getWorld();
            ChunkPos chunkPos = new ChunkPos(pos);
            BlockBox boundingBox = new BlockBox(chunkPos.getStartX(), pos.getY(), chunkPos.getStartZ(), chunkPos.getEndX(), pos.getY() + 50, chunkPos.getEndZ());

            generateTorii(world, boundingBox);
            generateComplexStructure(world, boundingBox);

            return true;
        }

        private void generateTorii(StructureWorldAccess world, BlockBox boundingBox) {
            BlockPos basePos = new BlockPos(boundingBox.minX + 8, boundingBox.minY, boundingBox.minZ + 8);

            // Pillars
            for (int y = 0; y < 7; y++) {
                world.setBlockState(basePos.add(0, y, 0), Blocks.STRIPPED_CHERRY_LOG.getDefaultState(), 3);
                world.setBlockState(basePos.add(4, y, 0), Blocks.STRIPPED_CHERRY_LOG.getDefaultState(), 3);
            }

            // Top bar
            for (int x = 0; x <= 4; x++) {
                world.setBlockState(basePos.add(x, 7, 0), Blocks.STRIPPED_CHERRY_PLANKS.getDefaultState(), 3);
            }
        }

        private void generateComplexStructure(StructureWorldAccess world, BlockBox boundingBox) {
            BlockPos basePos = new BlockPos(boundingBox.minX + 16, boundingBox.minY - 20, boundingBox.minZ + 16);

            generateMainStronghold(world, basePos);
            generatePortalRoom(world, basePos.add(0, -10, 0));
            generateWaterRoom(world, basePos.add(0, -15, 0));
            generateMaze(world, basePos.add(0, -20, 0));

            generateMineshaft(world, boundingBox);
            generateDungeons(world, boundingBox);
        }

        private void generateMainStronghold(StructureWorldAccess world, BlockPos basePos) {
            // Generate main stronghold rooms
            for (int x = 0; x < 30; x++) {
                for (int z = 0; x < 30; z++) {
                    for (int y = 0; y < 10; y++) {
                        BlockPos blockPos = basePos.add(x, y, z);
                        if (y == 0 || y == 9 || x == 0 || x == 29 || z == 0 || z == 29) {
                            world.setBlockState(blockPos, Blocks.STONE_BRICKS.getDefaultState(), 3);
                        } else if (x % 5 == 0 && z % 5 == 0 && y > 0 && y < 9) {
                            world.setBlockState(blockPos, Blocks.STONE_BRICK_WALL.getDefaultState(), 3);
                        } else {
                            world.setBlockState(blockPos, Blocks.AIR.getDefaultState(), 3);
                        }
                    }
                }
            }
        }

        private void generatePortalRoom(StructureWorldAccess world, BlockPos basePos) {
            // Generate portal room
            for (int x = 0; x < 10; x++) {
                for (int z = 0; x < 10; z++) {
                    for (int y = 0; x < 10; y++) {
                        BlockPos blockPos = basePos.add(x, y, z);
                        if (y == 0) {
                            world.setBlockState(blockPos, (x % 2 == z % 2) ? Blocks.RED_CONCRETE.getDefaultState() : Blocks.BLACK_CONCRETE.getDefaultState(), 3);
                        } else if (y == 9 || x == 0 || x == 9 || z == 0 || z == 9) {
                            world.setBlockState(blockPos, Blocks.STONE_BRICKS.getDefaultState(), 3);
                        } else if (y == 5 && x == 4 && z == 4) {
                            world.setBlockState(blockPos, Blocks.NETHER_PORTAL.getDefaultState(), 3);
                        } else if (y > 0 && y < 9 && ((x == 1 || x == 8) && (z == 1 || z == 8))) {
                            world.setBlockState(blockPos, Blocks.RED_CANDLE.getDefaultState().with(CandleBlock.LIT, true), 3);
                        } else if (y > 0 && y < 9 && ((x == 2 || x == 7) && (z == 2 || z == 7))) {
                            world.setBlockState(blockPos, Blocks.BLACK_CANDLE.getDefaultState().with(CandleBlock.LIT, true), 3);
                        } else {
                            world.setBlockState(blockPos, Blocks.AIR.getDefaultState (), 3);
                        }
                    }
                }
            }
        }

        private void generateWaterRoom(StructureWorldAccess world, BlockPos basePos) {
            // Generate water room
            for (int x = 0; x < 10; x++) {
                for (int z = 0; x < 10; z++) {
                    for (int y = 0; y < 5; y++) {
                        BlockPos blockPos = basePos.add(x, y, z);
                        if (y == 0) {
                            world.setBlockState(blockPos, Blocks.WATER.getDefaultState(), 3);
                        } else if (y == 4 || x == 0 || x == 9 || z == 0 || z == 9) {
                            world.setBlockState(blockPos, Blocks.STONE_BRICKS.getDefaultState(), 3);
                        } else {
                            world.setBlockState(blockPos, Blocks.AIR.getDefaultState(), 3);
                        }
                    }
                }
            }
        }

        private void generateMaze(StructureWorldAccess world, BlockPos basePos) {
            // Generate maze
            for (int i = 0; i < 4; i++) {
                generateMazeBranch(world, basePos.add(10 * i, 0, 0));
            }
        }

        private void generateMazeBranch(StructureWorldAccess world, BlockPos basePos) {
            // Generate a maze branch
            for (int x = 0; x < 10; x++) {
                for (int z = 0; x < 10; z++) {
                    for (int y = 0; y < 5; y++) {
                        BlockPos blockPos = basePos.add(x, y, z);
                        if (y == 0 || y == 4 || x == 0 || x == 9 || z == 0 || z == 9) {
                            world.setBlockState(blockPos, Blocks.STONE_BRICKS.getDefaultState(), 3);
                        } else if (world.getRandom().nextBoolean()) {
                            world.setBlockState(blockPos, Blocks.STONE_BRICK_WALL.getDefaultState(), 3);
                        } else {
                            world.setBlockState(blockPos, Blocks.AIR.getDefaultState(), 3);
                        }
                    }
                }
            }
            placeChestWithLoot(world, basePos.add(5, 1, 5));
        }

        private void placeChestWithLoot(StructureWorldAccess world, BlockPos pos) {
            world.setBlockState(pos, Blocks.CHEST.getDefaultState(), 3);
            BlockEntity blockEntity = world.getBlockEntity(pos);
            if (blockEntity instanceof ChestBlockEntity) {
                ((ChestBlockEntity)blockEntity).setLootTable(new Identifier("crimson_markings", "chests/maze_loot"), world.getSeed());
            }
        }

        private void generateMineshaft(StructureWorldAccess world, BlockBox boundingBox) {
            BlockPos basePos = new BlockPos(boundingBox.minX + 16, boundingBox.minY, boundingBox.minZ + 16);

            // Generate mineshaft
            for (int x = 0; x < 20; x++) {
                for (int z = 0; x < 20; z++) {
                    for (int y = 0; y < 6; y++) {
                        BlockPos blockPos = basePos.add(x, y, z);
                        if (y == 0 || y == 5 || x == 0 || x == 19 || z == 0 || z == 19) {
                            world.setBlockState(blockPos, Blocks.OAK_PLANKS.getDefaultState(), 3);
                        } else if ((x % 5 == 0 || z % 5 == 0) && y > 0 && y < 5) {
                            world.setBlockState(blockPos, Blocks.OAK_FENCE.getDefaultState(), 3);
                        } else {
                            world.setBlockState(blockPos, Blocks.AIR.getDefaultState(), 3);
                        }
                    }
                }
            }
        }

        private void generateDungeons(StructureWorldAccess world, BlockBox boundingBox) {
            BlockPos basePos = new BlockPos(boundingBox.minX + 24, boundingBox.minY - 5, boundingBox.minZ + 24);

            // Generate dungeons
            for (int i = 0; i < 12; i++) {
                BlockPos dungeonPos = basePos.add(i * 8, 0, i * 8);
                generateSingleDungeon(world, dungeonPos);
            }
        }

        private void generateSingleDungeon(StructureWorldAccess world, BlockPos basePos) {
            for (int x = 0; x < 16; x++) {
                for (int z = 0; x < 16; z++) {
                    for (int y = 0; y < 6; y++) {
                        BlockPos blockPos = basePos.add(x, y, z);
                        if (y == 0 || y == 5 || x == 0 || x == 15 || z == 0 || z == 15) {
                            world.setBlockState(blockPos, Blocks.COBBLESTONE.getDefaultState(), 3);
                        } else if ((x == 7 && z == 7) && y == 1) {
                            world.setBlockState(blockPos, Blocks.SPAWNER.getDefaultState(), 3);
                        } else if (y > 0 && y < 5 && world.getRandom().nextInt(4) == 0) {
                            world.setBlockState(blockPos, Blocks.MOSSY_COBBLESTONE.getDefaultState(), 3);
                        } else {
                            world.setBlockState(blockPos, Blocks.AIR.getDefaultState(), 3);
                        }
                    }
                }
            }
        }
    }
}
