
package com.example.priestessmod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ArmorMaterial;
import net.minecraft.item.ItemGroup;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

public class CrimsonCultPriestessMod implements ModInitializer {

    public static final String MODID = "crimson_cult_priestess_armor";
    
    // Define the Crimson Cult Priestess armor material
    public static final ArmorMaterial CRIMSON_CULT_PRIESTESS_MATERIAL = new ArmorMaterial.DIAMOND;

    // Define the armor items
    public static final ArmorItem CRIMSON_CULT_PRIESTESS_HOOD = new ArmorItem(CRIMSON_CULT_PRIESTESS_MATERIAL, ArmorItem.HEAD_SLOT, new FabricItemSettings().group(ItemGroup.COMBAT));
    public static final ArmorItem CRIMSON_CULT_PRIESTESS_HOOD_2 = new ArmorItem(CRIMSON_CULT_PRIESTESS_MATERIAL, ArmorItem.HEAD_SLOT, new FabricItemSettings().group(ItemGroup.COMBAT));
    public static final ArmorItem CRIMSON_CULT_PRIESTESS_CHESTPLATE = new ArmorItem(CRIMSON_CULT_PRIESTESS_MATERIAL, ArmorItem.CHEST_SLOT, new FabricItemSettings().group(ItemGroup.COMBAT));
    public static final ArmorItem CRIMSON_CULT_PRIESTESS_LEGGINGS = new ArmorItem(CRIMSON_CULT_PRIESTESS_MATERIAL, ArmorItem.LEGS_SLOT, new FabricItemSettings().group(ItemGroup.COMBAT));
    public static final ArmorItem CRIMSON_CULT_PRIESTESS_BOOTS = new ArmorItem(CRIMSON_CULT_PRIESTESS_MATERIAL, ArmorItem.FEET_SLOT, new FabricItemSettings().group(ItemGroup.COMBAT));

    @Override
    public void onInitialize() {
        // Register the armor items
        Registry.register(Registry.ITEM, new Identifier(MODID, "crimson_cult_priestess_hood"), CRIMSON_CULT_PRIESTESS_HOOD);
        Registry.register(Registry.ITEM, new Identifier(MODID, "crimson_cult_priestess_hood_2"), CRIMSON_CULT_PRIESTESS_HOOD_2);
        Registry.register(Registry.ITEM, new Identifier(MODID, "crimson_cult_priestess_chestplate"), CRIMSON_CULT_PRIESTESS_CHESTPLATE);
        Registry.register(Registry.ITEM, new Identifier(MODID, "crimson_cult_priestess_leggings"), CRIMSON_CULT_PRIESTESS_LEGGINGS);
        Registry.register(Registry.ITEM, new Identifier(MODID, "crimson_cult_priestess_boots"), CRIMSON_CULT_PRIESTESS_BOOTS);

        // Setup Fabric Data Generation (Item models, language files, etc.)
        setupDataGeneration();
    }

    private void setupDataGeneration() {
        // Data generation setup can be expanded here if needed
    }
}
