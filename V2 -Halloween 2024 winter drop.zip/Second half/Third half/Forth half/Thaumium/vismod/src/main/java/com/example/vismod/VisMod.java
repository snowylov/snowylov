
package com.example.vismod;

import com.google.gson.JsonObject;
import com.mojang.serialization.Codec;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.command.v1.CommandRegistrationCallback;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.screenhandler.v1.ScreenHandlerRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.command.argument.StringArgumentType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.*;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.packet.s2c.play.OpenScreenS2CPacket;
import net.minecraft.recipe.*;
import net.minecraft.screen.*;
import net.minecraft.screen.slot.Slot;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.structure.StructurePieceType;
import net.minecraft.text.LiteralText;
import net.minecraft.util.Identifier;
import net.minecraft.util.JsonHelper;
import net.minecraft.util.registry.Registry;
import net.minecraft.world.World;
import net.minecraft.world.gen.feature.DefaultFeatureConfig;
import net.minecraft.world.gen.feature.Feature;
import net.minecraft.world.gen.feature.FeatureContext;
import net.minecraft.world.gen.structure.StructurePiece;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.Random;

public class VisMod implements ModInitializer {

    public static final ArmorMaterial TERRA_STEEL_MATERIAL = new ArmorMaterial() {
    };

    public static final Item TERRA_STEEL_HELMET = new ArmorItem(TERRA_STEEL_MATERIAL, EquipmentSlot.HEAD, new Item.Settings().group(ItemGroup.COMBAT));
    public static final Item TERRA_STEEL_CHESTPLATE = new ArmorItem(TERRA_STEEL_MATERIAL, EquipmentSlot.CHEST, new Item.Settings().group(ItemGroup.COMBAT));
    public static final Item TERRA_STEEL_LEGGINGS = new ArmorItem(TERRA_STEEL_MATERIAL, EquipmentSlot.LEGS, new Item.Settings().group(ItemGroup.COMBAT));
    public static final Item TERRA_STEEL_BOOTS = new ArmorItem(TERRA_STEEL_MATERIAL, EquipmentSlot.FEET, new Item.Settings().group(ItemGroup.COMBAT));

    public static final Item LUX_VIS_SHARD = new Item(new Item.Settings().group(ItemGroup.MISC));
    public static final Item PURITY_VIS_SHARD = new Item(new Item.Settings().group(ItemGroup.MISC));
    public static final Item AQUA_VIS_SHARD = new Item(new Item.Settings().group(ItemGroup.MISC));
    public static final Item TERRA_VIS_SHARD = new Item(new Item.Settings().group(ItemGroup.MISC));
    public static final Item GELATIN_VIS_SHARD = new Item(new Item.Settings().group(ItemGroup.MISC));
    public static final Item SEXUS_VIS_SHARD = new Item(new Item.Settings().group(ItemGroup.MISC));
    public static final Item CRIMSON_VIS_SHARD = new Item(new Item.Settings().group(ItemGroup.MISC));
    public static final Item TAINTED_VIS_SHARD = new Item(new Item.Settings().group(ItemGroup.MISC));
    public static final Item LUNAR_VIS_SHARD = new Item(new Item.Settings().group(ItemGroup.MISC));
    public static final Item TERRA_STEEL_VIS_SHARD = new Item(new Item.Settings().group(ItemGroup.MISC));
    public static final Item CORRODIUM_VIS_SHARD = new Item(new Item.Settings().group(ItemGroup.MISC));
    public static final Item AER_VIS_SHARD = new Item(new Item.Settings().group(ItemGroup.MISC));
    public static final Item BOGGED_VIS_SHARD = new Item(new Item.Settings().group(ItemGroup.MISC));
    public static final Item ROOT_RIOT_VIS_SHARD = new Item(new Item.Settings().group(ItemGroup.MISC));
    public static final Item ENDER_VIS_SHARD = new Item(new Item.Settings().group(ItemGroup.MISC));
    public static final Item AUTUMNA_VIS_SHARD = new Item(new Item.Settings().group(ItemGroup.MISC));
    public static final Item UMBRA_VIS_SHARD = new Item(new Item.Settings().group(ItemGroup.MISC));
    public static final Item PYRO_VIS_SHARD = new Item(new Item.Settings().group(ItemGroup.MISC));
    public static final Item VIS_MIXER_TABLET = new VisMixerTablet(new Item.Settings().group(ItemGroup.MISC));
    public static final Item TERRA_STEEL_INGOT = new Item(new Item.Settings().group(ItemGroup.MISC));
    public static final Item TERRA_STEEL_NUGGET = new Item(new Item.Settings().group(ItemGroup.MISC));
    public static final Item VIS_SHARD_MIXER = new Item(new Item.Settings().group(ItemGroup.MISC));

    public static final EntityType<PechEntity> PECH_ENTITY_TYPE = Registry.register(
            Registry.ENTITY_TYPE,
            new Identifier("vismod", "pech"),
            EntityType.Builder.create(PechEntity::new, SpawnGroup.MONSTER)
                    .setDimensions(0.6F, 1.95F)
                    .build("pech")
    );

    public static final EntityType<ThaumaturgePechEntity> THAUMATURGE_PECH_ENTITY_TYPE = Registry.register(
            Registry.ENTITY_TYPE,
            new Identifier("vismod", "thaumaturge_pech"),
            EntityType.Builder.create(ThaumaturgePechEntity::new, SpawnGroup.MONSTER)
                    .setDimensions(0.6F, 1.95F)
                    .build("thaumaturge_pech")
    );

    public static final EntityType<ToolForagerPechEntity> TOOL_FORAGER_PECH_ENTITY_TYPE = Registry.register(
            Registry.ENTITY_TYPE,
            new Identifier("vismod", "tool_forager_pech"),
            EntityType.Builder.create(ToolForagerPechEntity::new, SpawnGroup.MONSTER)
                    .setDimensions(0.6F, 1.95F)
                    .build("tool_forager_pech")
    );

    public static final Feature<DefaultFeatureConfig> BEDROCK_CAVE_FEATURE = Registry.register(
            Registry.FEATURE,
            new Identifier("vismod", "bedrock_cave"),
            new BedrockCaveFeature(DefaultFeatureConfig.CODEC)
    );

    public static final ScreenHandlerType<VisMixerScreenHandler> VIS_MIXER_SCREEN_HANDLER = ScreenHandlerRegistry.registerSimple(
            new Identifier("vismod", "vis_mixer"), VisMixerScreenHandler::new);

    public static final ScreenHandlerType<ArmorUpgradeScreenHandler> ARMOR_UPGRADE_SCREEN_HANDLER = ScreenHandlerRegistry.registerSimple(
            new Identifier("vismod", "armor_upgrade"), ArmorUpgradeScreenHandler::new);

    @Override
    public void onInitialize() {
        registerItems();
        registerCommands();
        registerRecipes();
        registerArmorUpgradeGui();
    }

    private void registerItems() {
        Registry.register(Registry.ITEM, new Identifier("vismod", "lux_vis_shard"), LUX_VIS_SHARD);
        Registry.register(Registry.ITEM, new Identifier("vismod", "purity_vis_shard"), PURITY_VIS_SHARD);
        Registry.register(Registry.ITEM, new Identifier("vismod", "aqua_vis_shard"), AQUA_VIS_SHARD);
        Registry.register(Registry.ITEM, new Identifier("vismod", "terra_vis_shard"), TERRA_VIS_SHARD);
        Registry.register(Registry.ITEM, new Identifier("vismod", "gelatin_vis_shard"), GELATIN_VIS_SHARD);
        Registry.register(Registry.ITEM, new Identifier("vismod", "sexus_vis_shard"), SEXUS_VIS_SHARD);
        Registry.register(Registry.ITEM, new Identifier("vismod", "crimson_vis_shard"), CRIMSON_VIS_SHARD);
        Registry.register(Registry.ITEM, new Identifier("vismod", "tainted_vis_shard"), TAINTED_VIS_SHARD);
        Registry.register(Registry.ITEM, new Identifier("vismod", "lunar_vis_shard"), LUNAR_VIS_SHARD);
        Registry.register(Registry.ITEM, new Identifier("vismod", "terra_steel_vis_shard"), TERRA_STEEL_VIS_SHARD);
        Registry.register(Registry.ITEM, new Identifier("vismod", "corrodium_vis_shard"), CORRODIUM_VIS_SHARD);
        Registry.register(Registry .ITEM, new Identifier("vismod", "aer_vis_shard"), AER_VIS_SHARD);
        Registry.register(Registry.ITEM, new Identifier("vismod", "bogged_vis_shard"), BOGGED_VIS_SHARD);
        Registry.register(Registry.ITEM, new Identifier("vismod", "root_riot_vis_shard"), ROOT_RIOT_VIS_SHARD);
        Registry.register(Registry.ITEM, new Identifier("vismod", "ender_vis_shard"), ENDER_VIS_SHARD);
        Registry.register(Registry.ITEM, new Identifier("vismod", "autumna_vis_shard"), AUTUMNA_VIS_SHARD);
        Registry.register(Registry.ITEM, new Identifier("vismod", "umbra_vis_shard"), UMBRA_VIS_SHARD);
        Registry.register(Registry.ITEM, new Identifier("vismod", "pyro_vis_shard"), PYRO_VIS_SHARD);
        Registry.register(Registry.ITEM, new Identifier("vismod", "vis_mixer_tablet"), VIS_MIXER_TABLET);
        Registry.register(Registry.ITEM, new Identifier("vismod", "terra_steel_ingot"), TERRA_STEEL_INGOT);
        Registry.register(Registry.ITEM, new Identifier("vismod", "terra_steel_nugget"), TERRA_STEEL_NUGGET);
        Registry.register(Registry.ITEM, new Identifier("vismod", "vis_shard_mixer"), VIS_SHARD_MIXER);
        Registry.register(Registry.ITEM, new Identifier("vismod", "terra_steel_helmet"), TERRA_STEEL_HELMET);
        Registry.register(Registry.ITEM, new Identifier("vismod", "terra_steel_chestplate"), TERRA_STEEL_CHESTPLATE);
        Registry.register(Registry.ITEM, new Identifier("vismod", "terra_steel_leggings"), TERRA_STEEL_LEGGINGS);
        Registry.register(Registry.ITEM, new Identifier("vismod", "terra_steel_boots"), TERRA_STEEL_BOOTS);
    }

    private void registerCommands() {
        CommandRegistrationCallback.EVENT.register((dispatcher, dedicated) -> {
            dispatcher.register(CommandManager.literal("GiveVisShard")
                .requires(source -> source.hasPermissionLevel(2))
                .then(CommandManager.argument("player", EntityArgumentType.player())
                .then(CommandManager.argument("shard", StringArgumentType.string())
                .suggests((context, builder) -> CommandSource.suggestMatching(getShardNames(), builder))
                .executes(context -> {
                    return giveVisShard(context.getSource(), EntityArgumentType.getPlayer(context, "player"), StringArgumentType.getString(context, "shard"));
                }))));
        });
    }

    private void registerRecipes() {
        Registry.register(Registry.RECIPE_SERIALIZER, new Identifier("vismod", "vis_mixer"), VisMixerRecipeSerializer.INSTANCE);
        Registry.register(Registry.RECIPE_TYPE, new Identifier("vismod", "vis_mixer"), VisMixerRecipe.Type.INSTANCE);
    }

    private void registerArmorUpgradeGui() {
        ServerPlayNetworking.registerGlobalReceiver(new Identifier("vismod", "open_upgrade_gui"), (server, player, handler, buf, responseSender) -> {
            server.execute(() -> {
                player.openHandledScreen(new SimpleNamedScreenHandlerFactory((syncId, inventory, playerEntity) -> {
                    return new ArmorUpgradeScreenHandler(syncId, inventory);
                }, new LiteralText("Armor Upgrade")));
            });
        });
    }

    private static int giveVisShard(ServerCommandSource source, ServerPlayerEntity player, String shardName) {
        ItemStack shard = getShardItem(shardName);
        if (shard != null) {
            player.getInventory().insertStack(shard);
            source.sendFeedback(new LiteralText("Gave " + shardName + " to " + player.getName().asString()), false);
            return 1;
        } else {
            source.sendError(new LiteralText("Invalid shard name."));
            return 0;
        }
    }

    private static List<String> getShardNames() {
        return Arrays.asList("lux_vis_shard", "purity_vis_shard", "aqua_vis_shard", "terra_vis_shard", 
                             "gelatin_vis_shard", "sexus_vis_shard", "crimson_vis_shard", "tainted_vis_shard",
                             "lunar_vis_shard", "terra_steel_vis_shard", "corrodium_vis_shard", "aer_vis_shard",
                             "bogged_vis_shard", "root_riot_vis_shard", "ender_vis_shard", "autumna_vis_shard",
                             "umbra_vis_shard", "pyro_vis_shard");
    }

    private static ItemStack getShardItem(String shardName) {
        switch (shardName.toLowerCase()) {
            case "lux_vis_shard": return new ItemStack(LUX_VIS_SHARD);
            case "purity_vis_shard": return new ItemStack(PURITY_VIS_SHARD);
            case "aqua_vis_shard": return new ItemStack(AQUA_VIS_SHARD);
            case "terra_vis_shard": return new ItemStack(TERRA_VIS_SHARD);
            case "gelatin_vis_shard": return new ItemStack(GELATIN_VIS_SHARD);
            case "sexus_vis_shard": return new ItemStack(SEXUS_VIS_SHARD);
            case "crimson_vis_shard": return new ItemStack(CRIMSON_VIS_SHARD);
            case "tainted_vis_shard": return new ItemStack(TAINTED_VIS_SHARD);
            case "lunar_vis_shard": return new ItemStack(LUNAR_VIS_SHARD);
            case "terra_steel_vis_shard": return new ItemStack(TERRA_STEEL_VIS_SHARD);
            case "corrodium_vis_shard": return new ItemStack(CORRODIUM_VIS_SHARD);
            case "aer_vis_shard": return new ItemStack(AER_VIS_SHARD);
            case "bogged_vis_shard": return new ItemStack(BOGGED_VIS_SHARD);
            case "root_riot_vis_shard": return new ItemStack(ROOT_RIOT_VIS_SHARD);
            case "ender_vis_shard": return new ItemStack(ENDER_VIS_SHARD);
            case "autumna_vis_shard": return new ItemStack(AUTUMNA_VIS_SHARD);
            case "umbra_vis_shard": return new ItemStack(UMBRA_VIS_SHARD);
            case "pyro_vis_shard": return new ItemStack(PYRO_VIS_SHARD);
            default: return null;
        }
    }

    static class ArmorUpgradeScreenHandler extends ScreenHandler {
        private final Inventory inventory = new SimpleInventory(2);

        public ArmorUpgradeScreenHandler(int syncId, PlayerInventory playerInventory) {
            super(ARMOR_UPGRADE_SCREEN_HANDLER, syncId);

            this.addSlot(new Slot(inventory, 0, 56, 17));
            this.addSlot(new Slot(inventory, 1, 116, 35) {
                @Override
                public boolean canInsert(ItemStack stack) {
                    return false;
                }
            });

            for (int i = 0; i < 3; ++i) {
                for (int j = 0; ++j) {
                    this.addSlot(new Slot(playerInventory, j + i * 9 + 9, 8 + j * 18, 84 + i * 18));
                }
            }

            for (int k = 0; k < 9; ++k) {
                this.addSlot(new Slot(playerInventory, k, 8 + k * 18, 142));
            }
        }

        @Override
        public boolean canUse(PlayerEntity player) {
            return true;
        }

        @Override
        public void onContentChanged(Inventory inventory) {
            super.onContentChanged(inventory);
        }

        @Override
        public ItemStack transferSlot(PlayerEntity player, int index) {
            ItemStack itemStack = ItemStack.EMPTY;
            Slot slot = this.slots.get(index);
            if (slot != null && slot.hasStack()) {
                ItemStack itemStack2 = slot.getStack();
                itemStack = itemStack2.copy();
                if (index < 2) {
                    if (!this.insertItem(itemStack2, 2, 38, true)) {
                        return ItemStack.EMPTY;
                    }
                } else if (!this.insertItem(itemStack2, 0, 2, false)) {
                    return ItemStack.EMPTY;
                }

                if (itemStack2.isEmpty()) {
                    slot.setStack(ItemStack.EMPTY);
                } else {
                    slot.markDirty();
                }
            }
            return itemStack;
        }
    }
}
