
package com.vismod;

import com.google.gson.JsonObject;
import com.mojang.serialization.Codec;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v1.CommandRegistrationCallback;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.screenhandler.v1.ScreenHandlerRegistry;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.command.argument.StringArgumentType;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.*;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.recipe.*;
import net.minecraft.screen.*;
import net.minecraft.screen.slot.Slot;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.structure.StructurePieceType;
import net.minecraft.text.LiteralText;
import net.minecraft.util.Identifier;
import net.minecraft.util.JsonHelper;
import net.minecraft.util.registry.Registry;
import net.minecraft.world.World;
import net.minecraft.world.gen.feature.DefaultFeatureConfig;
import net.minecraft.world.gen.feature.Feature;
import net.minecraft.world.gen.feature.FeatureContext;
import net.minecraft.world.gen.structure.StructurePiece;
import net.minecraft.world.gen.structure.StructurePieceType;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.Random;

public class VisMod implements ModInitializer {

    public static final Item LUX_VIS_SHARD = new Item(new Item.Settings().group(ItemGroup.MISC));
    public static final Item PURITY_VIS_SHARD = new Item(new Item.Settings().group(ItemGroup.MISC));
    public static final Item AQUA_VIS_SHARD = new Item(new Item.Settings().group(ItemGroup.MISC));
    public static final Item TERRA_VIS_SHARD = new Item(new Item.Settings().group(ItemGroup.MISC));
    public static final Item GELATIN_VIS_SHARD = new Item(new Item.Settings().group(ItemGroup.MISC));
    public static final Item SEXUS_VIS_SHARD = new Item(new Item.Settings().group(ItemGroup.MISC));
    public static final Item CRIMSON_VIS_SHARD = new Item(new Item.Settings().group(ItemGroup.MISC));
    public static final Item TAINTED_VIS_SHARD = new Item(new Item.Settings().group(ItemGroup.MISC));
    public static final Item LUNAR_VIS_SHARD = new Item(new Item.Settings().group(ItemGroup.MISC));
    public static final Item TERRA_STEEL_VIS_SHARD = new Item(new Item.Settings().group(ItemGroup.MISC));
    public static final Item CORRODIUM_VIS_SHARD = new Item(new Item.Settings().group(ItemGroup.MISC));
    public static final Item AER_VIS_SHARD = new Item(new Item.Settings().group(ItemGroup.MISC));
    public static final Item BOGGED_VIS_SHARD = new Item(new Item.Settings().group(ItemGroup.MISC));
    public static final Item ROOT_RIOT_VIS_SHARD = new Item(new Item.Settings().group(ItemGroup.MISC));
    public static final Item ENDER_VIS_SHARD = new Item(new Item.Settings().group(ItemGroup.MISC));
    public static final Item AUTUMNA_VIS_SHARD = new Item(new Item.Settings().group(ItemGroup.MISC));
    public static final Item UMBRA_VIS_SHARD = new Item(new Item.Settings().group(ItemGroup.MISC));
    public static final Item PYRO_VIS_SHARD = new Item(new Item.Settings().group(ItemGroup.MISC));
    public static final Item VIS_MIXER_TABLET = new VisMixerTablet(new Item.Settings().group(ItemGroup.MISC));
    public static final Item TERRA_STEEL_INGOT = new Item(new Item.Settings().group(ItemGroup.MISC));
    public static final Item TERRA_STEEL_NUGGET = new Item(new Item.Settings().group(ItemGroup.MISC));
    public static final Item VIS_SHARD_MIXER = new Item(new FabricItemSettings().group(ItemGroup.MISC));

    public static final EntityType<PechEntity> PECH_ENTITY_TYPE = Registry.register(
            Registry.ENTITY_TYPE,
            new Identifier("vismod", "pech"),
            EntityType.Builder.create(PechEntity::new, SpawnGroup.MONSTER)
                    .setDimensions(0.6F, 1.95F)
                    .build("pech")
    );

    public static final EntityType<ThaumaturgePechEntity> THAUMATURGE_PECH_ENTITY_TYPE = Registry.register(
            Registry.ENTITY_TYPE,
            new Identifier("vismod", "thaumaturge_pech"),
            EntityType.Builder.create(ThaumaturgePechEntity::new, SpawnGroup.MONSTER)
                    .setDimensions(0.6F, 1.95F)
                    .build("thaumaturge_pech")
    );

    public static final EntityType<ToolForagerPechEntity> TOOL_FORAGER_PECH_ENTITY_TYPE = Registry.register(
            Registry.ENTITY_TYPE,
            new Identifier("vismod", "tool_forager_pech"),
            EntityType.Builder.create(ToolForagerPechEntity::new, SpawnGroup.MONSTER)
                    .setDimensions(0.6F, 1.95F)
                    .build("tool_forager_pech")
    );

    public static final Feature<DefaultFeatureConfig> BEDROCK_CAVE_FEATURE = Registry.register(
            Registry.FEATURE,
            new Identifier("vismod", "bedrock_cave"),
            new BedrockCaveFeature(DefaultFeatureConfig.CODEC)
    );

    public static final ScreenHandlerType<VisMixerScreenHandler> VIS_MIXER_SCREEN_HANDLER = ScreenHandlerRegistry.registerSimple(
            new Identifier("vismod", "vis_mixer"), VisMixerScreenHandler::new);

    @Override
    public void onInitialize() {
        registerItems();
        registerCommands();
        registerRecipes();
    }

    private void registerItems() {
        Registry.register(Registry.ITEM, new Identifier("vismod", "lux_vis_shard"), LUX_VIS_SHARD);
        Registry.register(Registry.ITEM, new Identifier("vismod", "purity_vis_shard"), PURITY_VIS_SHARD);
        Registry.register(Registry.ITEM, new Identifier("vismod", "aqua_vis_shard"), AQUA_VIS_SHARD);
        Registry.register(Registry.ITEM, new Identifier("vismod", "terra_vis_shard"), TERRA_VIS_SHARD);
        Registry.register(Registry.ITEM, new Identifier("vismod", "gelatin_vis_shard"), GELATIN_VIS_SHARD);
        Registry.register(Registry.ITEM, new Identifier("vismod", "sexus_vis_shard"), SEXUS_VIS_SHARD);
        Registry.register(Registry.ITEM, new Identifier("vismod", "crimson_vis_shard"), CRIMSON_VIS_SHARD);
        Registry.register(Registry.ITEM, new Identifier("vismod", "tainted_vis_shard"), TAINTED_VIS_SHARD);
        Registry.register(Registry.ITEM, new Identifier("vismod", "lunar_vis_shard"), LUNAR_VIS_SHARD);
        Registry.register(Registry.ITEM, new Identifier("vismod", "terra_steel_vis_shard"), TERRA_STEEL_VIS_SHARD);
        Registry.register(Registry.ITEM, new Identifier("vismod", "corrodium_vis_shard"), CORRODIUM_VIS_SHARD);
        Registry.register(Registry.ITEM, new Identifier("vismod", "aer_vis_shard"), AER_VIS_SHARD);
        Registry.register(Registry.ITEM, new Identifier("vismod", "bogged_vis_shard"), BOGGED_VIS_SHARD);
        Registry.register(Registry.ITEM, new Identifier("vismod", "root_riot_vis_shard"), ROOT_RIOT_VIS_SHARD);
        Registry.register(Registry.ITEM, new Identifier("vismod", "ender_vis_shard"), ENDER_VIS_SHARD);
        Registry.register(Registry.ITEM, new Identifier("vismod", "autumna_vis_shard"), AUTUMNA_VIS_SHARD);
        Registry.register(Registry.ITEM, new Identifier("vismod", "umbra_vis_shard"), UMBRA_VIS_SHARD);
        Registry.register(Registry.ITEM, new Identifier("vismod", "pyro_vis_shard"), PYRO_VIS_SHARD);
        Registry.register(Registry.ITEM, new Identifier("vismod", "vis_mixer_tablet"), VIS_MIXER_TABLET);
        Registry.register(Registry.ITEM, new Identifier("vismod", "terra_steel_ingot"), TERRA_STEEL_INGOT);
        Registry.register(Registry.ITEM, new Identifier("vismod", "terra_steel_nugget"), TERRA_STEEL_NUGGET);
        Registry.register(Registry.ITEM, new Identifier("vismod", "vis_shard_mixer"), VIS_SHARD_MIXER);
    }

    private void registerCommands() {
        CommandRegistrationCallback.EVENT.register((dispatcher, dedicated) -> {
            dispatcher.register(CommandManager.literal("GiveVisShard")
                .requires(source -> source.hasPermissionLevel(2)) // Admin-only check
                .then(CommandManager.argument("player", EntityArgumentType.player())
                .then(CommandManager.argument("shard", StringArgumentType.string())
                .suggests((context, builder) -> CommandSource.suggestMatching(getShardNames(), builder))
                .executes(context -> {
                    return giveVisShard(context.getSource(), EntityArgumentType.getPlayer(context, "player"), StringArgumentType.getString(context, "shard"));
                }))));
        });
    }

    private void registerRecipes() {
        Registry.register(Registry.RECIPE_SERIALIZER, new Identifier("vismod", "vis_mixer"), VisMixer this.addSlot(new Slot(inventory, 0, 56, 17));
            this.addSlot(new Slot(inventory, 1, 56, 53));
            this.addSlot(new Slot(inventory, 2, 116, 35) {
                @Override
                public boolean canInsert(ItemStack stack) {
                    return false;
                }
            });

            for (int i = 0; i < 3; ++i) {
                for (int j = 0; j < 9; ++j) {
                    this.addSlot(new Slot(playerInventory, j + i * 9 + 9, 8 + j * 18, 84 + i * 18));
                }
            }

            for (int k = 0; k < 9; ++k) {
                this.addSlot(new Slot(playerInventory, k, 8 + k * 18, 142));
            }
        }

        @Override
        public boolean canUse(PlayerEntity player) {
            return true;
        }

        @Override
        public void onContentChanged(Inventory inventory) {
            super.onContentChanged(inventory);
            if (!this.inventory.getStack(0).isEmpty() && !this.inventory.getStack(1).isEmpty()) {
                ItemStack result = getCraftingResult(this.inventory.getStack(0), this.inventory.getStack(1));
                this.inventory.setStack(2, result);
            }
        }

        private ItemStack getCraftingResult(ItemStack input1, ItemStack input2) {
            Optional<VisMixerRecipe> recipe = this.world.getRecipeManager().getFirstMatch(VisMixerRecipe.Type.INSTANCE, this.inventory, this.world);
            return recipe.map(visMixerRecipe -> visMixerRecipe.craft(this.inventory)).orElse(ItemStack.EMPTY);
        }

        @Override
        public ItemStack transferSlot(PlayerEntity player, int index) {
            ItemStack itemStack = ItemStack.EMPTY;
            Slot slot = this.slots.get(index);
            if (slot != null && slot.hasStack()) {
                ItemStack itemStack2 = slot.getStack();
                itemStack = itemStack2.copy();
                if (index < 3) {
                    if (!this.insertItem(itemStack2, 3, 39, true)) {
                        return ItemStack.EMPTY;
                    }
                } else if (!this.insertItem(itemStack2, 0, 3, false)) {
                    return ItemStack.EMPTY;
                }

                if (itemStack2.isEmpty()) {
                    slot.setStack(ItemStack.EMPTY);
                } else {
                    slot.markDirty();
                }
            }
            return itemStack;
        }
    }

    public static class VisMixerRecipe implements Recipe<SimpleInventory> {
        private final Identifier id;
        private final ItemStack output;
        private final DefaultedList<Ingredient> recipeItems;

        public VisMixerRecipe(Identifier id, ItemStack output, DefaultedList<Ingredient> recipeItems) {
            this.id = id;
            this.output = output;
            this.recipeItems = recipeItems;
        }

        @Override
        public boolean matches(SimpleInventory inventory, World world) {
            return recipeItems.get(0).test(inventory.getStack(0)) && recipeItems.get(1).test(inventory.getStack(1));
        }

        @Override
        public ItemStack craft(SimpleInventory inventory) {
            return output.copy();
        }

        @Override
        public boolean fits(int width, int height) {
            return true;
        }

        @Override
        public ItemStack getOutput() {
            return output;
        }

        @Override
        public Identifier getId() {
            return id;
        }

        @Override
        public RecipeSerializer<?> getSerializer() {
            return VisMixerRecipeSerializer.INSTANCE;
        }

        @Override
        public RecipeType<?> getType() {
            return Type.INSTANCE;
        }

        public static class Type implements RecipeType<VisMixerRecipe> {
            public static final Type INSTANCE = new Type();
            public static final String ID = "vis_mixer";
        }

        public static class Serializer implements RecipeSerializer<VisMixerRecipe> {
            public static final Serializer INSTANCE = new Serializer();
            public static final Identifier ID = new Identifier("vismod", "vis_mixer");

            @Override
            public VisMixerRecipe read(Identifier id, JsonObject json) {
                ItemStack output = ShapedRecipe.outputFromJson(JsonHelper.getObject(json, "result"));
                DefaultedList<Ingredient> ingredients = DefaultedList.ofSize(2, Ingredient.EMPTY);
                JsonHelper.getArray(json, "ingredients").forEach(element -> ingredients.set(ingredients.size() - 1, Ingredient.fromJson(element)));
                return new VisMixerRecipe(id, output, ingredients);
            }

            @Override
            public VisMixerRecipe read(Identifier id, PacketByteBuf buf) {
                DefaultedList<Ingredient> ingredients = DefaultedList.ofSize(buf.readInt(), Ingredient.EMPTY);
                ingredients.replaceAll(ignored -> Ingredient.fromPacket(buf));
                ItemStack output = buf.readItemStack();
                return new VisMixerRecipe(id, output, ingredients);
            }

            @Override
            public void write(PacketByteBuf buf, VisMixerRecipe recipe) {
                buf.writeInt(recipe.recipeItems.size());
                recipe.recipeItems.forEach(ingredient -> ingredient.write(buf));
                buf.writeItemStack(recipe.output);
            }
        }
    }

    private static Item getRandomVisShard() {
        List<Item> shards = Arrays.asList(
            LUX_VIS_SHARD, PURITY_VIS_SHARD, AQUA_VIS_SHARD, TERRA_VIS_SHARD, GELATIN_VIS_SHARD,
            SEXUS_VIS_SHARD, CRIMSON_VIS_SHARD, TAINTED_VIS_SHARD, LUNAR_VIS_SHARD, TERRA_STEEL_VIS_SHARD,
            CORRODIUM_VIS_SHARD, AER_VIS_SHARD, BOGGED_VIS_SHARD, ROOT_RIOT_VIS_SHARD, ENDER_VIS_SHARD,
            AUTUMNA_VIS_SHARD, UMBRA_VIS_SHARD, PYRO_VIS_SHARD
        );
        Random random = new Random();
        return shards.get(random.nextInt(shards.size()));
    }
}
