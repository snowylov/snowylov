
package glisteninthelight;

import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

public class ModBlocks {
    public static final Block INNER_LIGHT_DOOR = new Block(Block.Settings.copy(Blocks.OAK_DOOR));
    public static final Block INNERDARKNESS_DOOR = new Block(Block.Settings.copy(Blocks.OAK_DOOR));

    public static void registerBlocks() {
        Registry.register(Registry.BLOCK, GlistenInTheLightMod.id("inner_light_door"), INNER_LIGHT_DOOR);
        Registry.register(Registry.BLOCK, GlistenInTheLightMod.id("innerdarkness_door"), INNERDARKNESS_DOOR);
    }
}
