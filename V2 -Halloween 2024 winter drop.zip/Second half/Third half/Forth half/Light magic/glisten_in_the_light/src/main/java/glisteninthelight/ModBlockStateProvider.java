
package glisteninthelight;

import net.fabricmc.fabric.api.datagen.v1.provider.FabricBlockStateProvider;
import net.minecraft.data.client.model.BlockStateModelGenerator;
import net.minecraft.util.Identifier;

public class ModBlockStateProvider extends FabricBlockStateProvider {
    public ModBlockStateProvider(FabricDataGenerator generator) {
        super(generator);
    }

    @Override
    protected void generateBlockStates() {
        getBlockStateModelGenerator().registerSimpleCubeAll(ModBlocks.INNER_LIGHT_DOOR);
        getBlockStateModelGenerator().registerSimpleCubeAll(ModBlocks.INNERDARKNESS_DOOR);
    }
}
