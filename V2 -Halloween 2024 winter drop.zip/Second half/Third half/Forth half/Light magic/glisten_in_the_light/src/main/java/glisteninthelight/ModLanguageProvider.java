
package glisteninthelight;

import net.fabricmc.fabric.api.datagen.v1.provider.FabricLanguageProvider;

public class ModLanguageProvider extends FabricLanguageProvider {
    public ModLanguageProvider(FabricDataGenerator generator) {
        super(generator, "en_us");
    }

    @Override
    protected void generateTranslations() {
        addTranslation("block.glisteninthelight.inner_light_door", "Inner Light Door");
        addTranslation("block.glisteninthelight.innerdarkness_door", "Inner Darkness Door");
        addTranslation("item.glisteninthelight.key_of_light", "Key of Light");
        addTranslation("item.glisteninthelight.key_of_darkness", "Key of Darkness");
    }
}
