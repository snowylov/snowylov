
package glisteninthelight;

import net.fabricmc.fabric.api.datagen.v1.provider.FabricItemModelProvider;
import net.minecraft.data.client.model.ItemModelGenerator;
import net.minecraft.util.Identifier;

public class ModItemModelProvider extends FabricItemModelProvider {
    public ModItemModelProvider(FabricDataGenerator generator) {
        super(generator);
    }

    @Override
    protected void generateItemModels() {
        getItemModelGenerator().register(ModItems.KEY_OF_LIGHT, new Identifier("item/handheld"));
        getItemModelGenerator().register(ModItems.KEY_OF_DARKNESS, new Identifier("item/handheld"));
    }
}
