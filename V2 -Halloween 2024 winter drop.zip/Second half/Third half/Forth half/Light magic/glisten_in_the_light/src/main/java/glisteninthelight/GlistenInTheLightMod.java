
package glisteninthelight;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.client.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;
import org.quiltmc.qsl.item.setting.api.QuiltItemSettings;

public class GlistenInTheLightMod implements ModInitializer {
    public static final String MODID = "glisteninthelight";

    @Override
    public void onInitialize() {
        // Register items and blocks
        ModItems.registerItems();
        ModBlocks.registerBlocks();
        
        // Register data generators
        DataGeneratorInitializer.init();
    }

    public static Identifier id(String path) {
        return new Identifier(MODID, path);
    }
}
