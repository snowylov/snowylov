
package glisteninthelight;

import net.minecraft.item.Item;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;
import org.quiltmc.qsl.item.setting.api.QuiltItemSettings;

public class ModItems {
    public static final Item KEY_OF_LIGHT = new Item(new QuiltItemSettings().group(ItemGroup.MISC));
    public static final Item KEY_OF_DARKNESS = new Item(new QuiltItemSettings().group(ItemGroup.MISC));

    public static void registerItems() {
        Registry.register(Registry.ITEM, GlistenInTheLightMod.id("key_of_light"), KEY_OF_LIGHT);
        Registry.register(Registry.ITEM, GlistenInTheLightMod.id("key_of_darkness"), KEY_OF_DARKNESS);
    }
}
