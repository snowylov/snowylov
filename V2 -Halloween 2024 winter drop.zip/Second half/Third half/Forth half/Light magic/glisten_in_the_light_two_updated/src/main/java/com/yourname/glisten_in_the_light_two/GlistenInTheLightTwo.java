package com.yourname.glisten_in_the_light_two;

import com.yourname.glisten_in_the_light_two.registry.BlockRegistry;
import com.yourname.glisten_in_the_light_two.registry.ItemRegistry;
import com.yourname.glisten_in_the_light_two.datagen.ModLanguageProvider;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.datagen.v1.FabricDataGenerator;
import net.fabricmc.fabric.api.datagen.v1.FabricDataGenerator.EntryPoint;

public class GlistenInTheLightTwo implements ModInitializer, EntryPoint {
    public static final String MOD_ID = "glisten_in_the_light_two";

    @Override
    public void onInitialize() {
        BlockRegistry.registerBlocks();
        ItemRegistry.registerItems();
    }

    @Override
    public void onInitializeDataGenerator(FabricDataGenerator dataGenerator) {
        dataGenerator.addProvider(ModLanguageProvider::new);
    }
}
