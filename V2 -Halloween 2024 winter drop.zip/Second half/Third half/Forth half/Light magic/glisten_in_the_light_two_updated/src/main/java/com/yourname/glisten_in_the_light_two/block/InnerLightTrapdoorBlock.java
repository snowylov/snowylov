package com.yourname.glisten_in_the_light_two.block;

import net.minecraft.block.TrapdoorBlock;
import net.minecraft.block.BlockState;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.world.World;
import com.yourname.glisten_in_the_light_two.registry.ItemRegistry;

public class InnerLightTrapdoorBlock extends TrapdoorBlock {
    public InnerLightTrapdoorBlock(Settings settings) {
        super(settings);
    }

    @Override
    public void onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, Hand hand, BlockHitResult hit) {
        ItemStack heldItem = player.getStackInHand(hand);
        if (heldItem.getItem() == ItemRegistry.INNER_LIGHT_HATCH_KEY) {
            // Custom logic to open or close the trapdoor
        }
    }
}
