package com.yourname.glisten_in_the_light_two.registry;

import com.yourname.glisten_in_the_light_two.GlistenInTheLightTwo;
import com.yourname.glisten_in_the_light_two.block.InnerLightTrapdoorBlock;
import com.yourname.glisten_in_the_light_two.block.InnerDarknessTrapdoorBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

public class BlockRegistry {
    public static final Block INNER_LIGHT_TRAPDOOR = new InnerLightTrapdoorBlock(Block.Settings.copy(Blocks.OAK_TRAPDOOR));
    public static final Block INNER_DARKNESS_TRAPDOOR = new InnerDarknessTrapdoorBlock(Block.Settings.copy(Blocks.OAK_TRAPDOOR));

    public static void registerBlocks() {
        Registry.register(Registry.BLOCK, new Identifier(GlistenInTheLightTwo.MOD_ID, "inner_light_trapdoor"), INNER_LIGHT_TRAPDOOR);
        Registry.register(Registry.BLOCK, new Identifier(GlistenInTheLightTwo.MOD_ID, "inner_darkness_trapdoor"), INNER_DARKNESS_TRAPDOOR);
    }
}
