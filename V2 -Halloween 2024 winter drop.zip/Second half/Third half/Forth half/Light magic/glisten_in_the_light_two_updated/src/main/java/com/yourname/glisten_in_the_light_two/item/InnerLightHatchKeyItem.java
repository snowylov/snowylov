package com.yourname.glisten_in_the_light_two.item;

import net.minecraft.item.Item;

public class InnerLightHatchKeyItem extends Item {
    public InnerLightHatchKeyItem(Settings settings) {
        super(settings);
    }
}
