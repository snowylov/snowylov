package com.yourname.glisten_in_the_light_two.registry;

import com.yourname.glisten_in_the_light_two.GlistenInTheLightTwo;
import com.yourname.glisten_in_the_light_two.item.InnerLightHatchKeyItem;
import com.yourname.glisten_in_the_light_two.item.InnerDarknessHatchKeyItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

public class ItemRegistry {
    public static final Item INNER_LIGHT_HATCH_KEY = new InnerLightHatchKeyItem(new Item.Settings().group(ItemGroup.MISC));
    public static final Item INNER_DARKNESS_HATCH_KEY = new InnerDarknessHatchKeyItem(new Item.Settings().group(ItemGroup.MISC));

    public static void registerItems() {
        Registry.register(Registry.ITEM, new Identifier(GlistenInTheLightTwo.MOD_ID, "inner_light_hatch_key"), INNER_LIGHT_HATCH_KEY);
        Registry.register(Registry.ITEM, new Identifier(GlistenInTheLightTwo.MOD_ID, "inner_darkness_hatch_key"), INNER_DARKNESS_HATCH_KEY);
    }
}
