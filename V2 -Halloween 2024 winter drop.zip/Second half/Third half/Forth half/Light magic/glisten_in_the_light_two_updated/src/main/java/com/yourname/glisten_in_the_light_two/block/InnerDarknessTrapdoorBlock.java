package com.yourname.glisten_in_the_light_two.block;

import net.minecraft.block.TrapdoorBlock;

public class InnerDarknessTrapdoorBlock extends TrapdoorBlock {
    public InnerDarknessTrapdoorBlock(Settings settings) {
        super(settings);
    }

    // Custom interaction logic
}
