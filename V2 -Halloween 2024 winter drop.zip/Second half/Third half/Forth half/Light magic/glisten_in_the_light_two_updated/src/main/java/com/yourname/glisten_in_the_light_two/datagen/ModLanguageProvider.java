package com.yourname.glisten_in_the_light_two.datagen;

import net.fabricmc.fabric.api.datagen.v1.FabricDataGenerator;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricLanguageProvider;
import java.util.function.BiConsumer;

public class ModLanguageProvider extends FabricLanguageProvider {

    public ModLanguageProvider(FabricDataGenerator dataGenerator) {
        super(dataGenerator);
    }

    @Override
    public void generateTranslations(BiConsumer<String, String> translationConsumer) {
        // Blocks
        translationConsumer.accept("block.glisten_in_the_light_two.inner_light_trapdoor", "Inner Light Trapdoor");
        translationConsumer.accept("block.glisten_in_the_light_two.inner_darkness_trapdoor", "Inner Darkness Trapdoor");

        // Items
        translationConsumer.accept("item.glisten_in_the_light_two.inner_light_hatch_key", "Inner Light Hatch Key");
        translationConsumer.accept("item.glisten_in_the_light_two.inner_darkness_hatch_key", "Inner Darkness Hatch Key");
    }
}
