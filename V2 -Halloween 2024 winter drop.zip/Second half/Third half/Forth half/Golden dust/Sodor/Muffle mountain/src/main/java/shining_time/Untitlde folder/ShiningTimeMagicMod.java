package shining_time;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.datagen.v1.FabricDataGenerator;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricBlockLootTableProvider;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricModelProvider;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.fabricmc.fabric.api.object.builder.v1.world.feature.FabricDefaultFeatureConfig;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.FallingBlock;
import net.minecraft.block.Material;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.loot.context.LootContext;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;
import net.minecraft.util.registry.BuiltinRegistries;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.gen.GenerationStep;
import net.minecraft.world.gen.YOffset;
import net.minecraft.world.gen.feature.ConfiguredFeature;
import net.minecraft.world.gen.feature.Feature;
import net.minecraft.world.gen.feature.OreFeatureConfig;
import net.minecraft.world.gen.feature.PlacedFeature;
import net.minecraft.world.gen.placementmodifier.CountPlacementModifier;
import net.minecraft.world.gen.placementmodifier.HeightRangePlacementModifier;
import net.minecraft.world.gen.placementmodifier.PlacementModifier;
import net.minecraft.world.gen.placementmodifier.SquarePlacementModifier;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.function.Consumer;

public class ShiningTimeMagicMod implements ModInitializer {

    public static final Block M_SAND_BLOCK = new MSandBlock();
    public static final Block M_STONE_BLOCK = new MStoneBlock();
    public static final Block ROUGH_M_STONE_BLOCK = new RoughMStoneBlock();
    public static final Block M_STONE_COAL_ORE_BLOCK = new MStoneCoalOreBlock();
    public static final Item M_COAL_ITEM = new MCoalItem();
    public static final Biome M_STONE_MOUNTAINS_BIOME = new MStoneMountainsBiome();

    public static ConfiguredFeature<?, ?> M_SAND_FEATURE;
    public static ConfiguredFeature<?, ?> ROUGH_M_STONE_FEATURE;
    public static ConfiguredFeature<?, ?> M_STONE_FEATURE;
    public static ConfiguredFeature<?, ?> M_STONE_COAL_ORE_FEATURE;

    @Override
    public void onInitialize() {
        Registry.register(Registry.BLOCK, new Identifier("shining_time_magic", "m_sand"), M_SAND_BLOCK);
        Registry.register(Registry.BLOCK, new Identifier("shining_time_magic", "m_stone"), M_STONE_BLOCK);
        Registry.register(Registry.BLOCK, new Identifier("shining_time_magic", "rough_m_stone"), ROUGH_M_STONE_BLOCK);
        Registry.register(Registry.BLOCK, new Identifier("shining_time_magic", "m_stone_coal_ore"), M_STONE_COAL_ORE_BLOCK);

        Registry.register(Registry.ITEM, new Identifier("shining_time_magic", "m_sand"), new BlockItem(M_SAND_BLOCK, new Item.Settings().group(ItemGroup.BUILDING_BLOCKS)));
        Registry.register(Registry.ITEM, new Identifier("shining_time_magic", "m_stone"), new BlockItem(M_STONE_BLOCK, new Item.Settings().group(ItemGroup.BUILDING_BLOCKS)));
        Registry.register(Registry.ITEM, new Identifier("shining_time_magic", "rough_m_stone"), new BlockItem(ROUGH_M_STONE_BLOCK, new Item.Settings().group(ItemGroup.BUILDING_BLOCKS)));
        Registry.register(Registry.ITEM, new Identifier("shining_time_magic", "m_stone_coal_ore"), new BlockItem(M_STONE_COAL_ORE_BLOCK, new Item.Settings().group(ItemGroup.BUILDING_BLOCKS)));

        Registry.register(Registry.ITEM, new Identifier("shining_time_magic", "m_coal"), M_COAL_ITEM);
        Registry.register(BuiltinRegistries.BIOME, new Identifier("shining_time_magic", "m_stone_mountains"), M_STONE_MOUNTAINS_BIOME);
        
        M_SAND_FEATURE = registerFeature("m_sand_replace", M_SAND_BLOCK, Blocks.DIRT);
        ROUGH_M_STONE_FEATURE = registerFeature("rough_m_stone_replace", ROUGH_M_STONE_BLOCK, Blocks.GRASS_BLOCK);
        M_STONE_FEATURE = registerFeature("m_stone_replace", M_STONE_BLOCK, Blocks.DIRT);
        M_STONE_COAL_ORE_FEATURE = registerFeature("m_stone_coal_ore_replace", M_STONE_COAL_ORE_BLOCK, Blocks.STONE);

        FabricDefaultBiomeFeatures.addDefaultFeatures(M_STONE_MOUNTAINS_BIOME);
    }

    private static ConfiguredFeature<?, ?> registerFeature(String name, Block targetBlock, Block replaceBlock) {
        ConfiguredFeature<?, ?> feature = Feature.ORE.configure(new OreFeatureConfig(
                OreFeatureConfig.Rules.BASE_STONE_OVERWORLD,
                targetBlock.getDefaultState(),
                9 // vein size
        ));
        Registry.register(BuiltinRegistries.CONFIGURED_FEATURE, new Identifier("shining_time_magic", name), feature);
        return feature;
    }

ShaderTriggerHandler.initialize();

    public static class MSandBlock extends FallingBlock {
        public MSandBlock() {
            super(Settings.of(Material.AGGREGATE).strength(0.5F).sounds(BlockSoundGroup.SAND));
        }
    }

    public static class MStoneBlock extends Block {
        public MStoneBlock() {
            super(Settings.of(Material.STONE).strength(1.5F * 1.3F, 6.0F * 1.3F).sounds(BlockSoundGroup.STONE));
        }

        @Override
        public List<ItemStack> getDroppedStacks(BlockState state, LootContext.Builder builder) {
            return Collections.singletonList(new ItemStack(ShiningTimeMagicMod.ROUGH_M_STONE_BLOCK));
        }
    }

    public static class RoughMStoneBlock extends Block {
        public RoughMStoneBlock() {
            super(Settings.of(Material.STONE).strength(1.5F * 1.3F, 6.0F * 1.3F).sounds(BlockSoundGroup.STONE));
        }
    }

    public static class MStoneCoalOreBlock extends Block {
        public MStoneCoalOreBlock() {
            super(Settings.of(Material.STONE).strength(1.5F * 1.3F, 6.0F * 1.3F).sounds(BlockSoundGroup.STONE));
        }

        @Override
        public List<ItemStack> getDroppedStacks(BlockState state, LootContext.Builder builder) {
            return Collections.singletonList(new ItemStack(ShiningTimeMagicMod.M_COAL_ITEM, 8));
        }
    }

    public static class MCoalItem extends Item {
        public MCoalItem() {
            super(new Item.Settings().group(ItemGroup.MISC));
        }
    }

    public static class MStoneMountainsBiome extends Biome {
        public MStoneMountainsBiome() {
            super(new Biome.Settings()
                    .precipitation(Precipitation.NONE)
                    .category(Category.EXTREME_HILLS)
                    .depth(1.5F)
                    .scale(0.5F)
                    .temperature(0.7F)
                    .downfall(0.8F)
                    .effects(new BiomeEffects.Builder()
                            .waterColor(0x3f76e4)
                            .waterFogColor(0x50533)
                            .fogColor(0xc0d8ff)
                            .skyColor(0x77adff)
                            .build())
                    .surfaceBuilder(SurfaceBuilder.DEFAULT, new TernarySurfaceConfig(
                            ShiningTimeMagicMod.M_SAND_BLOCK.getDefaultState(),
                            ShiningTimeMagicMod.M_STONE_BLOCK.getDefaultState(),
                            ShiningTimeMagicMod.ROUGH_M_STONE_BLOCK.getDefaultState()
                    )));

            GenerationSettings.Builder builder = new GenerationSettings.Builder()
                    .surfaceBuilder(ConfiguredSurfaceBuilders.DEFAULT);

            DefaultBiomeFeatures.addLandCarvers(this);
            DefaultBiomeFeatures.addDefaultUndergroundStructures(this);
            DefaultBiomeFeatures.addDungeons(this);
            DefaultBiomeFeatures.addMineables(this);
            DefaultBiomeFeatures.addDefaultOres(this);
            DefaultBiomeFeatures.addDefaultDisks(this);
            DefaultBiomeFeatures.addSprings(this);

            builder.feature(GenerationStep.Feature.UNDERGROUND_ORES, ShiningTimeMagicMod.M_STONE_COAL_ORE_FEATURE);
            
            this.addFeature(GenerationStep.Feature.UNDERGROUND_ORES, ShiningTimeMagicMod.M_STONE_COAL_ORE_FEATURE);
        }
    }

    public static class ModConfiguredFeatures {
        public static final ConfiguredFeature<?, ?> M_STONE_COAL_ORE = Feature.ORE
                .configure(new OreFeatureConfig(
                        OreFeatureConfig.Rules.BASE_STONE_OVERWORLD,
                        ShiningTimeMagicMod.M_STONE_COAL_ORE_BLOCK.getDefaultState(),
                        9)) // vein size
                .decorate(Arrays.asList(
                        CountPlacementModifier.of(20), // number of veins per chunk
                        SquarePlacementModifier.of(), // spread horizontally
                        HeightRangePlacementModifier.uniform(YOffset.getBottom(), YOffset.fixed(60)))); // height range
    }

    public static class ModDataGenerator implements FabricDataGenerator.FabricDataGeneratorEntrypoint {
        @Override
        public void onInitializeDataGenerator(FabricDataGenerator data Generator) {
            dataGenerator.addProvider(ModBlockLootTableProvider::new);
            dataGenerator.addProvider(ModModelProvider::new);
            dataGenerator.addProvider(ModRecipeProvider::new);
        }
    }

    public static class ModBlockLootTableProvider extends FabricBlockLootTableProvider {
        public ModBlockLootTableProvider(FabricDataGenerator dataGenerator) {
            super(dataGenerator);
        }

        @Override
        protected void generateBlockLootTables() {
            addDrop(ShiningTimeMagicMod.M_SAND_BLOCK);
            addDrop(ShiningTimeMagicMod.M_STONE_BLOCK);
            addDrop(ShiningTimeMagicMod.ROUGH_M_STONE_BLOCK);
            addDrop(ShiningTimeMagicMod.M_STONE_COAL_ORE_BLOCK);
        }
    }

    public static class ModModelProvider extends FabricModelProvider {
        public ModModelProvider(FabricDataGenerator dataGenerator) {
            super(dataGenerator);
        }

        @Override
        public void generateBlockStateModels(BlockStateModelGenerator generator) {
            generator.registerSimpleCubeAll(ShiningTimeMagicMod.M_SAND_BLOCK);
            generator.registerSimpleCubeAll(ShiningTimeMagicMod.M_STONE_BLOCK);
            generator.registerSimpleCubeAll(ShiningTimeMagicMod.ROUGH_M_STONE_BLOCK);
            generator.registerSimpleCubeAll(ShiningTimeMagicMod.M_STONE_COAL_ORE_BLOCK);
        }

        @Override
        public void generateItemModels(ItemModelGenerator generator) {
            generator.register(ShiningTimeMagicMod.M_COAL_ITEM, Models.GENERATED);
        }
    }

    public static class ModRecipeProvider extends FabricRecipeProvider {
        public ModRecipeProvider(FabricDataGenerator dataGenerator) {
            super(dataGenerator);
        }

        @Override
        protected void generateRecipes(Consumer<RecipeJsonProvider> exporter) {
            SmeltingRecipeJsonBuilder.create(RecipeCategory.MISC, ShiningTimeMagicMod.M_COAL_ITEM, Ingredient.ofItems(ShiningTimeMagicMod.M_STONE_COAL_ORE_BLOCK))
                .cookingTime(200)
                .experience(0.7f)
                .offerTo(exporter, new Identifier("shining_time_magic", "m_stone_coal_ore_smelting"));

            // Add more recipes as needed
        }
    }
}
