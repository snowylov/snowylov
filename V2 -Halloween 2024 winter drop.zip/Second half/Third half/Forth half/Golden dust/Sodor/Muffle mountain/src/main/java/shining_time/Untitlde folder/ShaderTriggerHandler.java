package com.example.mod;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerWorldEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderEffect;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.biome.BiomeKeys;

import java.io.IOException;

public class ShaderTriggerHandler {
    private static ShaderEffect shaderEffect;

    public static void initialize() {
        ServerWorldEvents.LOAD.register((server, world) -> {
            // Register a tick event or player movement event to check for biome changes
            server.getPlayerManager().getPlayerList().forEach(player -> {
                player.tick();
                Biome currentBiome = world.getBiome(player.getBlockPos()).value();
                if (isInMuffleMountainBiome(currentBiome)) {
                    applyShader();
                } else {
                    removeShader();
                }
            });
        });
    }

    private static boolean isInMuffleMountainBiome(Biome biome) {
        // Replace with the actual identifier of your custom biome
        return Registry.BIOME.getId(biome).equals(BiomeKeys.MOUNTAIN);
    }

    private static void applyShader() {
        if (shaderEffect == null) {
            try {
                shaderEffect = new ShaderEffect(MinecraftClient.getInstance().getTextureManager(), 
                        MinecraftClient.getInstance().getResourceManager(), 
                        MinecraftClient.getInstance().getFramebuffer(), 
                        new Identifier("shining_time_magic", "shaders/post/muffle_mountain_biome.json"));
                shaderEffect.setupDimensions(MinecraftClient.getInstance().getWindow().getFramebufferWidth(),
                        MinecraftClient.getInstance().getWindow().getFramebufferHeight());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        if (!shaderEffect.isActive()) {
            shaderEffect.apply();
        }
    }

    private static void removeShader() {
        if (shaderEffect != null && shaderEffect.isActive()) {
            shaderEffect.close();
        }
    }
}