{
  "parent": "item/handheld",
  "textures": {
    "layer0": "kopaka_shields_mata_nui_edition:item/ice_sword"
  }
}