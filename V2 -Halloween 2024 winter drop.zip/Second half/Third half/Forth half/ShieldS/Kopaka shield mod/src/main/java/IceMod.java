import net.fabricmc.fabric.api.datagen.v1.FabricDataGenerator;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricLanguageProvider;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.minecraft.item.*;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.registry.Registry;
import net.minecraft.world.World;

public class IceMod implements ServerLifecycleEvents.ServerStarting {
    public static final Item ICE_SHIELD = createShieldItem("ice_shield", 0.8F, 0.1F);
    public static final Item ICE_SHIELD_NUVA = createShieldItem("ice_shield_nuva", 0.8F, 0.1F);
    public static final Item ICE_SWORD = new IceSwordItem(new Item.Settings().group(ItemGroup.COMBAT));

    public static void registerItems() {
        Registry.register(Registry.ITEM, new Identifier("kopaka_shields_mata_nui_edition", "ice_shield"), ICE_SHIELD);
        Registry.register(Registry.ITEM, new Identifier("kopaka_shields_mata_nui_edition", "ice_shield_nuva"), ICE_SHIELD_NUVA);
        Registry.register(Registry.ITEM, new Identifier("kopaka_shields_mata_nui_edition", "ice_sword"), ICE_SWORD);
    }

    private static Item createShieldItem(String id, float damageReduction, float blastProtection) {
        return new ShieldItem(new Item.Settings().maxDamage(-1).group(ItemGroup.COMBAT)) {
            @Override
            public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
                if (!world.isClient) {
                    SnowballEntity snowball = new SnowballEntity(world, user);
                    snowball.setItem(user.getStackInHand(hand));
                    snowball.setVelocity(user, user.getPitch(), user.getYaw(), 0.0F, 1.5F, 1.0F);
                    world.spawnEntity(snowball);
                }
                return TypedActionResult.success(user.getStackInHand(hand), world.isClient());
            }

            @Override
            public float getDamageReduction() {
                return damageReduction;
            }

            @Override
            public float getBlastProtection() {
                return blastProtection;
            }
        };
    }

    private static class IceSwordItem extends SwordItem {
        public IceSwordItem(Item.Settings settings) {
            super(ToolMaterials.IRON, 6, -2.4F, settings);
        }

        @Override
        public boolean postHit(ItemStack stack, LivingEntity target, LivingEntity attacker) {
            if (target instanceof LivingEntity) {
                ((LivingEntity) target).addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 100, 1));
            }
            return super.postHit(stack, target, attacker);
        }
    }

    public static class LanguageGenerator extends FabricLanguageProvider {
        public LanguageGenerator(FabricDataGenerator dataGenerator) {
            super(dataGenerator);
        }

        @Override
        public void generateTranslations(TranslationBuilder translationBuilder) {
            translationBuilder.add(ICE_SHIELD, "Ice Shield");
            translationBuilder.add(ICE_SHIELD_NUVA, "Ice Shield Nuva");
            translationBuilder.add(ICE_SWORD, "Ice Sword");
        }
    }

    @Override
    public void onServerStarting(MinecraftServer server) {
        FabricDataGenerator dataGenerator = new FabricDataGenerator(server.getRunDirectory().toPath(), "kopaka_shields_mata_nui_edition");
        dataGenerator.addProvider(LanguageGenerator::new);
        dataGenerator.run();
    }
}