package com.example.ludacris_shields;

import net.fabricmc.api.ModInitializer;
import net.minecraft.item.Item;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

import java.nio.file.Files;
import java.nio.file.Path;
import java.io.IOException;
import java.util.Map;

public class LudacrisShieldsMod implements ModInitializer {

    // Define the shield items using the provided API
    public static final Item OBSIDIAN_SHIELD = registerShield("obsidian_shield", 1213, 90, 100);
    public static final Item IRON_WOOD_SHIELD = registerShield("iron_wood_shield", 200, 60, 35);

    @Override
    public void onInitialize() {
        // Register the shield items
        registerItems();

        // Register recipes
        registerRecipes();

        // Register language entries
        registerLanguage();
    }

    private void registerItems() {
        Registry.register(Registry.ITEM, new Identifier("ludacris_shields", "obsidian_shield"), OBSIDIAN_SHIELD);
        Registry.register(Registry.ITEM, new Identifier("ludacris_shields", "iron_wood_shield"), IRON_WOOD_SHIELD);
    }

    private void registerRecipes() {
        // Recipe for Iron and Wood Shield
        ShapedRecipeJsonBuilder.create(IRON_WOOD_SHIELD)
            .pattern(" w ")
            .pattern("wiw")
            .pattern(" w ")
            .input('w', Items.OAK_PLANKS)
            .input('i', Items.IRON_INGOT)
            .criterion("has_iron", conditionsFromItem(Items.IRON_INGOT))
            .offerTo(RecipeProvider::create);

        // Recipe for Obsidian Shield
        ShapedRecipeJsonBuilder.create(OBSIDIAN_SHIELD)
            .pattern(" w ")
            .pattern("www")
            .pattern(" w ")
            .input('w', Items.OBSIDIAN)
            .criterion("has_obsidian", conditionsFromItem(Items.OBSIDIAN))
            .offerTo(RecipeProvider::create);
    }

    private static void conditionsFromItem(Item item) {
        // Define condition for crafting recipes based on item presence
        // Placeholder for actual implementation
    }

    private void registerLanguage() {
        // Map of item names to localized names
        Map<String, String> languageEntries = Map.of(
            "item.ludacris_shields.obsidian_shield", "Obsidian Shield",
            "item.ludacris_shields.iron_wood_shield", "Iron and Wood Shield"
        );

        // Logic to output these language entries into a JSON file
        generateLanguageFile(languageEntries);
    }

    private void generateLanguageFile(Map<String, String> entries) {
        // Path to the output language file (e.g., "assets/ludacris_shields/lang/en_us.json")
        Path outputPath = Path.of("assets/ludacris_shields/lang/en_us.json");

        // Write the entries to the file
        try {
            Files.write(outputPath, new Gson().toJson(entries).getBytes());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Method to register shields using the API
    private static Item registerShield(String name, int durability, int protection, int blastProtection) {
        // Replace this method body with actual registration logic from the provided API
        // This is a placeholder to show where the API call would go
        return new Item(new Item.Settings().maxDamage(durability));
    }
}