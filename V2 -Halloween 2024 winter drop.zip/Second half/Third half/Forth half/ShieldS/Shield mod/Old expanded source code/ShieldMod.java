package shieldmod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.resource.conditions.v1.DefaultResourceConditions;
import net.fabricmc.fabric.api.resource.conditions.v1.ResourceConditions;
import net.fabricmc.fabric.api.tag.TagFactory;
import net.fabricmc.fabric.api.tag.TagRegistry;
import net.fabricmc.fabric.impl.datagen.DataGeneratorRegistryImpl;
import net.minecraft.data.server.recipe.ShapedRecipeJsonBuilder;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

public class ShieldMod implements ModInitializer {
    public static final String MOD_ID = "shieldmod";

    @Override
    public void onInitialize() {
        ShieldItems.registerItems();
        ShieldRecipes.registerRecipes();
        ShieldTranslations.registerTranslations();
    }

    public static class ShieldItems {
        public static final Item WOODEN_SHIELD = registerShield("wooden_shield", 53, 45, 50);
        public static final Item LEATHER_SHIELD = registerShield("leather_shield", 230, 50, 50);
        public static final Item IRON_SHIELD = registerShield("iron_shield", 343, 75, 50);
        public static final Item DIAMOND_SHIELD = registerShield("diamond_shield", 800, 80, 80);
        public static final Item OBSIDIAN_SHIELD = registerShield("obsidian_shield", 1213, 90, 100);
        public static final Item COPPER_SHIELD = registerShield("copper_shield", 298, 70, 50);
        public static final Item CRYSTAL_SHIELD = registerShield("crystal_shield", 773, 98, 95);
        public static final Item GOLDEN_SHIELD = registerShield("golden_shield", 43, 60, 50);
        public static final Item DARK_IRON_SHIELD = registerShield("dark_iron_shield", 259, 85, 90);
        public static final Item AMETHYST_SHIELD = registerShield("amethyst_shield", 265, 60, 55);
        public static final Item EMERALD_SHIELD = registerShield("emerald_shield", 285, 65, 60);
        public static final Item QUARTZ_SHIELD = registerShield("quartz_shield", 350, 72, 60);
        public static final Item LAPIS_SHIELD = registerShield("lapis_shield", 320, 68, 58);
        public static final Item REDSTONE_SHIELD = registerShield("redstone_shield", 310, 66, 57);

        private static Item registerShield(String name, int durability, int protection, int blastResistance) {
            Item shield = new CustomShieldItem(new FabricItemSettings().maxDamage(durability), protection, blastResistance);
            Registry.register(Registry.ITEM, new Identifier(MOD_ID, name), shield);
            return shield;
        }

        public static void registerItems() {
            // This method ensures all items are registered during the mod's initialization.
        }
    }

    public static class ShieldRecipes {
        public static void registerRecipes() {
            offerShapedRecipe("wooden_shield", Items.SHIELD, Items.OAK_PLANKS);
            offerShapedRecipe("leather_shield", Items.SHIELD, Items.LEATHER);
            offerShapedRecipe("iron_shield", Items.SHIELD, Items.IRON_INGOT);
            offerShapedRecipe("diamond_shield", Items.SHIELD, Items.DIAMOND);
            offerShapedRecipe("obsidian_shield", Items.SHIELD, Items.OBSIDIAN);
            offerShapedRecipe("copper_shield", Items.SHIELD, Items.COPPER_INGOT);
            offerShapedRecipe("crystal_shield", Items.SHIELD, Items.AMETHYST_SHARD);
            offerShapedRecipe("golden_shield", Items.SHIELD, Items.GOLD_INGOT);
            offerShapedRecipe("dark_iron_shield", Items.SHIELD, Items.IRON_INGOT); // Adjust if different material
            offerShapedRecipe("amethyst_shield", Items.SHIELD, Items.AMETHYST_SHARD);
            offerShapedRecipe("emerald_shield", Items.SHIELD, Items.EMERALD);
            offerShapedRecipe("quartz_shield", Items.SHIELD, Items.QUARTZ);
            offerShapedRecipe("lapis_shield", Items.SHIELD, Items.LAPIS_LAZULI);
            offerShapedRecipe("redstone_shield", Items.SHIELD, Items.REDSTONE);
        }

        private static void offerShapedRecipe(String shieldName, Item shield, Item material) {
            ShapedRecipeJsonBuilder.create(shield)
                .pattern(" X ")
                .pattern("XSX")
                .pattern(" X ")
                .input('X', material)
                .input('S', Items.SHIELD)
                .criterion("has_shield", conditionsFromItem(Items.SHIELD))
                .offerTo(DataGeneratorRegistryImpl.createRecipeJsonProvider(new Identifier(MOD_ID, shieldName)));
        }
    }

    public static class ShieldTranslations {
        public static void registerTranslations() {
            addTranslation("wooden_shield", "Wooden Shield");
            addTranslation("leather_shield", "Leather Shield");
            addTranslation("iron_shield", "Iron Shield");
            addTranslation("diamond_shield", "Diamond Shield");
            addTranslation("obsidian_shield", "Obsidian Shield");
            addTranslation("copper_shield", "Copper Shield");
            addTranslation("crystal_shield", "Crystal Shield");
            addTranslation("golden_shield", "Golden Shield");
            addTranslation("dark_iron_shield", "Dark Iron Shield");
            addTranslation("amethyst_shield", "Amethyst Shield");
            addTranslation("emerald_shield", "Emerald Shield");
            addTranslation("quartz_shield", "Quartz Shield");
            addTranslation("lapis_shield", "Lapis Shield");
            addTranslation("redstone_shield", "Redstone Shield");
        }

        private static void addTranslation(String key, String translation) {
            TranslationBuilder.add("item.shieldmod." + key, translation);
        }
    }
}