package com.example.shieldmod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.minecraft.data.server.recipe.ShapedRecipeJsonBuilder;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

public class ShieldMod implements ModInitializer {
    public static final String MOD_ID = "shieldmod";

    @Override
    public void onInitialize() {
        ShieldItems.registerItems();
        ShieldRecipes.registerRecipes();
        ShieldTranslations.registerTranslations();
    }

    public static class ShieldItems {
        public static final Item WOODEN_SHIELD = registerShield("wooden_shield", 53, 45, 50);
        public static final Item WOODEN_LEATHER_SHIELD = registerShield("wooden_leather_shield", 230, 50, 50);
        public static final Item IRON_SHIELD = registerShield("iron_shield", 343, 75, 50);
        public static final Item DIAMOND_SHIELD = registerShield("diamond_shield", 800, 80, 80);
        public static final Item NETHERITE_SHIELD = registerShield("netherite_shield", 4024, 97, 100);
        public static final Item COPPER_SHIELD = registerShield("copper_shield", 298, 70, 50);
        public static final Item GOLDEN_SHIELD = registerShield("golden_shield", 43, 60, 50);

        private static Item registerShield(String name, int durability, int protection, int blastResistance) {
            Item shield = new CustomShieldItem(new FabricItemSettings().maxDamage(durability), protection, blastResistance);
            Registry.register(Registry.ITEM, new Identifier(MOD_ID, name), shield);
            return shield;
        }

        public static void registerItems() {
            // Ensure all items are registered during the mod's initialization.
        }
    }

    public static class ShieldRecipes {
        public static void registerRecipes() {
            offerShapedRecipe("wooden_shield", Items.SHIELD, Items.OAK_PLANKS);
            offerShapedRecipe("wooden_leather_shield", Items.LEATHER, Items.OAK_PLANKS);
            offerShapedRecipe("iron_shield", Items.SHIELD, Items.IRON_INGOT);
            offerShapedRecipe("diamond_shield", Items.SHIELD, Items.DIAMOND);
            offerShapedRecipe("netherite_shield", Items.SHIELD, Items.NETHERITE_INGOT);
            offerShapedRecipe("copper_shield", Items.SHIELD, Items.COPPER_INGOT);
            offerShapedRecipe("golden_shield", Items.SHIELD, Items.GOLD_INGOT);
        }

        private static void offerShapedRecipe(String shieldName, Item material, Item centerMaterial) {
            ShapedRecipeJsonBuilder.create(Registry.ITEM.get(new Identifier(MOD_ID, shieldName)))
                .pattern(" L ")
                .pattern("LSL")
                .pattern(" L ")
                .input('L', material)
                .input('S', centerMaterial)
                .criterion("has_shield", conditionsFromItem(Items.SHIELD))
                .offerTo(DataGeneratorRegistryImpl.createRecipeJsonProvider(new Identifier(MOD_ID, shieldName)));
        }
    }

    public static class ShieldTranslations {
        public static void registerTranslations() {
            addTranslation("wooden_shield", "Wooden Shield");
            addTranslation("wooden-leather_shield", "Wooden Leather Shield");
            addTranslation("iron_shield", "Iron Shield");
            addTranslation("diamond_shield", "Diamond Shield");
            addTranslation("netherite_shield", "Netherite Shield");
            addTranslation("copper_shield", "Copper Shield");
            addTranslation("golden_shield", "Golden Shield");
        }

        private static void addTranslation(String key, String translation) {
            TranslationBuilder.add("item.shieldmod." + key, translation);
        }
    }
}