package com.snowielove1.lucrativebundles;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.client.screenhandler.v1.ScreenRegistry;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.screen.NamedScreenHandlerFactory;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.screen.slot.Slot;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.registry.Registry;
import net.minecraft.util.Rarity;

import java.util.List;

public class LucrativeBundles implements ModInitializer, ClientModInitializer {
    public static final String MODID = "lucrative_bundles";

    public static final Item CUSTOM_DYABLE_BUNDLE = new CustomDyableBundleItem(new Item.Settings().maxCount(1).group(ItemGroup.MISC));
    public static final ScreenHandlerType<CustomInventoryScreenHandler> CUSTOM_INVENTORY_SCREEN_HANDLER;

    static {
        CUSTOM_INVENTORY_SCREEN_HANDLER = Registry.register(
            Registry.SCREEN_HANDLER,
            new Identifier(MODID, "custom_inventory"),
            new ScreenHandlerType<>(CustomInventoryScreenHandler::new)
        );
    }

    @Override
    public void onInitialize() {
        Registry.register(Registry.ITEM, new Identifier(MODID, "custom_dyable_bundle"), CUSTOM_DYABLE_BUNDLE);
    }

    @Override
    public void onInitializeClient() {
        ScreenRegistry.register(CUSTOM_INVENTORY_SCREEN_HANDLER, CustomInventoryScreen::new);
    }

    public static class CustomDyableBundleItem extends Item {
        private static final Text TITLE = Text.translatable("container.custom_inventory");

        public CustomDyableBundleItem(Item.Settings settings) {
            super(settings);
        }

        @Override
        public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
            player.openHandledScreen(createScreenHandlerFactory(player.getStackInHand(hand)));
            return TypedActionResult.success(player.getStackInHand(hand));
        }

        private NamedScreenHandlerFactory createScreenHandlerFactory(ItemStack stack) {
            return new SimpleNamedScreenHandlerFactory((syncId, inventory, player) -> {
                return new CustomInventoryScreenHandler(syncId, inventory, stack);
            }, TITLE);
        }

        public static NbtCompound getOrCreateInventoryTag(ItemStack stack) {
            return stack.getOrCreateNbt();
        }

        @Override
        public Text getName(ItemStack stack) {
            return getColoredName(stack, super.getName(stack));
        }

        private Text getColoredName(ItemStack stack, Text originalName) {
            int color = getColor(stack);
            if (color == -1) {
                return originalName;
            }
            return originalName.copy().formatted(Formatting.byColorIndex(color));
        }

        public static int getColor(ItemStack stack) {
            NbtCompound nbt = stack.getNbt();
            return nbt != null && nbt.contains("CustomColor", 99) ? nbt.getInt("CustomColor") : -1;
        }

        public static void setColor(ItemStack stack, int color) {
            NbtCompound nbt = stack.getOrCreateNbt();
            nbt.putInt("CustomColor", color);
        }

        @Override
        public void appendTooltip(ItemStack stack, World world, List<Text> tooltip, TooltipContext context) {
            int color = getColor(stack);
            if (color != -1) {
                tooltip.add(Text.literal("Color: #" + Integer.toHexString(color)).formatted(Formatting.GRAY));
            }
            super.appendTooltip(stack, world, tooltip, context);
        }
    }

    public static class CustomInventoryScreenHandler extends ScreenHandler {
        private final Inventory inventory;

        public CustomInventoryScreenHandler(int syncId, PlayerInventory playerInventory, ItemStack stack) {
            super(CUSTOM_INVENTORY_SCREEN_HANDLER, syncId);
            this.inventory = new Inventory(9) {
                @Override
                public boolean canPlayerUse(PlayerEntity player) {
                    return true;
                }
            };

            // Load items from NBT
            loadItemsFromNbt(stack);

            // Custom Inventory Slots (3x3)
            for (int i = 0; i < 3; ++i) {
                for (int j = 0; j < 3; ++j) {
                    this.addSlot(new CustomSlot(this.inventory, j + i * 3, 62 + j * 18, 17 + i * 18));
                }
            }

            // Player Inventory Slots
            for (int y = 0; y < 3; ++y) {
                for (int x = 0; x < 9; ++x) {
                    this.addSlot(new Slot(playerInventory, x + y * 9 + 9, 8 + x * 18, 84 + y * 18));
                }
            }

            // Player Hotbar Slots
            for (int x = 0; x < 9; ++x) {
                this.addSlot(new Slot(playerInventory, x, 8 + x * 18, 142));
            }
        }

        @Override
        public boolean canUse(PlayerEntity player) {
            return this.inventory.canPlayerUse(player);
        }

        @Override
        public void onClose(PlayerEntity player) {
            super.onClose(player);
            saveItemsToNbt(player.getMainHandStack());
        }

        private void loadItemsFromNbt(ItemStack stack) {
            NbtCompound nbt = CustomDyableBundleItem.getOrCreateInventoryTag(stack);
            for (int i = 0; i < this.inventory.size(); ++i) {
                ItemStack itemStack = ItemStack.fromNbt(nbt.getCompound("Slot" + i));
                this.inventory.setStack(i, itemStack);
            }
        }

        private void saveItemsToNbt(ItemStack stack) {
            NbtCompound nbt = CustomDyableBundleItem.getOrCreateInventoryTag(stack);
            for (int i = 0; i < this.inventory.size(); ++i) {
                ItemStack itemStack = this.inventory.getStack(i);
                nbt.put("Slot" + i, itemStack.writeNbt(new NbtCompound()));
            }
        }
    }

    public static class CustomSlot extends Slot {

        public CustomSlot(Inventory inventory, int index, int x, int y) {
            super(inventory, index, x, y);
        }

        @Override
        public int getMaxItemCount() {
            return 16; // Limit stack size to 16
        }

        @Override
        public boolean canInsert(ItemStack stack) {
            // Only allow items that are RARE or EPIC to be inserted
            Rarity rarity = stack.getRarity();
            return rarity == Rarity.RARE || rarity == Rarity.EPIC;
        }
    }

    public static class CustomInventoryScreen extends HandledScreen<CustomInventoryScreenHandler> {

        private static final Identifier TEXTURE = new Identifier("textures/gui/container/dispenser.png");

        public CustomInventoryScreen(CustomInventoryScreenHandler handler, PlayerInventory inventory, Text title) {
            super(handler, inventory, title);
            this.backgroundWidth = 176;
            this.backgroundHeight = 166;
        }

        @Override
        protected void drawBackground(MatrixStack matrices, float delta, int mouseX, int mouseY) {
            this.client.getTextureManager().bindTexture(TEXTURE);
            this.drawTexture(matrices, this.x, this.y, 0, 0, this.backgroundWidth, this.backgroundHeight);
        }

        @Override
        public void render(MatrixStack matrices, int mouseX, int mouseY, float delta) {
            this.renderBackground(matrices);
            super.render(matrices, mouseX, mouseY, delta);
            this.drawMouseoverTooltip(matrices, mouseX, mouseY);
        }
    }
}