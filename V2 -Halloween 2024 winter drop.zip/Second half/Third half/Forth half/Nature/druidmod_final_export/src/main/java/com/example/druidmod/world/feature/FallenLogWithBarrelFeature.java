
package com.example.druidmod.world.feature;

import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.Identifier;
import net.minecraft.world.StructureWorldAccess;
import net.minecraft.world.gen.feature.DefaultFeatureConfig;
import net.minecraft.world.gen.feature.Feature;
import net.minecraft.world.gen.feature.util.FeatureContext;

import java.util.Random;

public class FallenLogWithBarrelFeature extends Feature<DefaultFeatureConfig> {
    public FallenLogWithBarrelFeature() {
        super(DefaultFeatureConfig.CODEC);
    }

    @Override
    public boolean generate(FeatureContext<DefaultFeatureConfig> context) {
        StructureWorldAccess world = context.getWorld();
        BlockPos pos = context.getOrigin();
        Random random = context.getRandom();

        // Create the fallen log
        for (int i = 0; i < 5; i++) {
            BlockPos logPos = pos.add(i, 0, 0);
            world.setBlockState(logPos, Blocks.OAK_LOG.getDefaultState(), 3);
        }

        // Place the moss carpet on top
        world.setBlockState(pos.up(), Blocks.MOSS_CARPET.getDefaultState(), 3);

        // Place the barrel underneath with custom loot
        BlockPos barrelPos = pos.down();
        world.setBlockState(barrelPos, Blocks.BARREL.getDefaultState(), 3);

        // Link the barrel to our custom loot table
        world.getBlockEntity(barrelPos).setLootTable(new Identifier("druidmod", "chests/druid_barrel"), random.nextLong());

        return true;
    }
}
