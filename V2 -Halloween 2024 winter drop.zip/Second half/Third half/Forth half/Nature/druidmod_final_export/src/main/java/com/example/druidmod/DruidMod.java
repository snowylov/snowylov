
package com.example.druidmod.items;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ArmorMaterial;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ToolMaterials;
import net.minecraft.recipe.Ingredient;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;
import net.minecraft.world.World;
import org.lwjgl.glfw.GLFW;

import java.util.List;
import java.util.UUID;

public class DruidMod implements ModInitializer {

    public static final Item DRUID_CHESTPLATE_MALE = new DruidChestplate(new DruidArmorMaterial(), EquipmentSlot.CHEST, new FabricItemSettings().group(ItemGroup.COMBAT), "Male");
    public static final Item DRUID_CHESTPLATE_FEMALE = new DruidChestplate(new DruidArmorMaterial(), EquipmentSlot.CHEST, new FabricItemSettings().group(ItemGroup.COMBAT), "Female");
    public static final Item DRUID_HOOD = new DruidHood(new DruidArmorMaterial(), EquipmentSlot.HEAD, new FabricItemSettings().group(ItemGroup.COMBAT));

    public static final Item GLASS_DAGGER_TYPE_1 = new GlassDagger(ToolMaterials.DIAMOND, 5, 0f, new FabricItemSettings().group(ItemGroup.COMBAT).maxDamage(700), "Type 1");
    public static final Item GLASS_DAGGER_TYPE_2 = new GlassDagger(ToolMaterials.DIAMOND, 5, 0f, new FabricItemSettings().group(ItemGroup.COMBAT).maxDamage(700), "Type 2");
    public static final Item GLASS_DAGGER_TYPE_3 = new GlassDagger(ToolMaterials.DIAMOND, 5, 0f, new FabricItemSettings().group(ItemGroup.COMBAT).maxDamage(700), "Type 3");
    public static final Item GLASS_DAGGER_TYPE_4 = new GlassDagger(ToolMaterials.DIAMOND, 5, 0f, new FabricItemSettings().group(ItemGroup.COMBAT).maxDamage(700), "Type 4");
    public static final Item GLASS_DAGGER_TYPE_5 = new GlassDagger(ToolMaterials.DIAMOND, 5, 0f, new FabricItemSettings().group(ItemGroup.COMBAT).maxDamage(700), "Type 5");
    public static final Item GLASS_DAGGER_TYPE_6 = new GlassDagger(ToolMaterials.DIAMOND, 5, 0f, new FabricItemSettings().group(ItemGroup.COMBAT).maxDamage(700), "Type 6");
    public static final Item GLASS_DAGGER_TYPE_7 = new GlassDagger(ToolMaterials.DIAMOND, 5, 0f, new FabricItemSettings().group(ItemGroup.COMBAT).maxDamage(700), "Type 7");
    public static final Item GLASS_DAGGER_TYPE_8 = new GlassDagger(ToolMaterials.DIAMOND, 5, 0f, new FabricItemSettings().group(ItemGroup.COMBAT).maxDamage(700), "Type 8");
    public static final Item GLASS_DAGGER_TYPE_9 = new GlassDagger(ToolMaterials.DIAMOND, 5, 0f, new FabricItemSettings().group(ItemGroup.COMBAT).maxDamage(700), "Type 9");
    public static final Item GLASS_DAGGER_TYPE_10 = new GlassDagger(ToolMaterials.DIAMOND, 5, 0f, new FabricItemSettings().group(ItemGroup.COMBAT).maxDamage(700), "Type 10");

    @Override
    public void onInitialize() {
        // Register Armor
        Registry.register(Registry.ITEM, new Identifier("druidmod", "druid_chestplate_male"), DRUID_CHESTPLATE_MALE);
        Registry.register(Registry.ITEM, new Identifier("druidmod", "druid_chestplate_female"), DRUID_CHESTPLATE_FEMALE);
        Registry.register(Registry.ITEM, new Identifier("druidmod", "druid_hood"), DRUID_HOOD);

        // Register Glass Daggers
        Registry.register(Registry.ITEM, new Identifier("druidmod", "glass_dagger_type_1"), GLASS_DAGGER_TYPE_1);
        Registry.register(Registry.ITEM, new Identifier("druidmod", "glass_dagger_type_2"), GLASS_DAGGER_TYPE_2);
        Registry.register(Registry.ITEM, new Identifier("druidmod", "glass_dagger_type_3"), GLASS_DAGGER_TYPE_3);
        Registry.register(Registry.ITEM, new Identifier("druidmod", "glass_dagger_type_4"), GLASS_DAGGER_TYPE_4);
        Registry.register(Registry.ITEM, new Identifier("druidmod", "glass_dagger_type_5"), GLASS_DAGGER_TYPE_5);
        Registry.register(Registry.ITEM, new Identifier("druidmod", "glass_dagger_type_6"), GLASS_DAGGER_TYPE_6);
        Registry.register(Registry.ITEM, new Identifier("druidmod", "glass_dagger_type_7"), GLASS_DAGGER_TYPE_7);
        Registry.register(Registry.ITEM, new Identifier("druidmod", "glass_dagger_type_8"), GLASS_DAGGER_TYPE_8);
        Registry.register(Registry.ITEM, new Identifier("druidmod", "glass_dagger_type_9"), GLASS_DAGGER_TYPE_9);
        Registry.register(Registry.ITEM, new Identifier("druidmod", "glass_dagger_type_10"), GLASS_DAGGER_TYPE_10);
    }

    // Armor Classes
    public static class DruidArmorMaterial implements ArmorMaterial {

        @Override
        public int getDurability(EquipmentSlot slot) {
            return 700; // Durability for armor
        }

        @Override
        public int getProtectionAmount(EquipmentSlot slot) {
            return slot == EquipmentSlot.CHEST ? 8 : (slot == EquipmentSlot.HEAD ? 2 : 0); // Protection values
        }

        @Override
        public int getEnchantability() {
            return 30;
        }

        @Override
        public SoundEvent getEquipSound() {
            return SoundEvents.ITEM_ARMOR_EQUIP_DIAMOND;
        }

        @Override
        public Ingredient getRepairIngredient() {
            return Ingredient.ofItems(/* Specify repair item here */);
        }

        @Override
        public String getName() {
            return "druid";
        }

        @Override
        public float getToughness() {
            return 3.0F;
        }

        @Override
        public float getKnockbackResistance() {
            return 0.1F;
        }
    }

    public static class DruidChestplate extends ArmorItem {

        private final String gender;

        public DruidChestplate(ArmorMaterial material, EquipmentSlot slot, Settings settings, String gender) {
            super(material, slot, settings);
            this.gender = gender;
        }

        @Override
        public void onArmorTick(World world, net.minecraft.entity.player.PlayerEntity player, ItemStack stack) {
            if (player.hasStatusEffect(StatusEffects.POISON)) {
                player.removeStatusEffect(StatusEffects.POISON);
            }
        }

        @Override
        public void appendTooltip(ItemStack stack, World world, List<Text> tooltip, TooltipContext context) {
            if (InputUtil.isKeyPressed(MinecraftClient.getInstance().getWindow().getHandle(), GLFW.GLFW_KEY_LEFT_SHIFT)) {
                tooltip.add(Text.literal("Gender: " + gender));
                tooltip.add(Text.literal("Provides 89% damage reduction"));
                tooltip.add(Text.literal("100% immunity to thorn and poison damage"));
            } else {
                tooltip.add(Text.literal("Hold Shift for more info"));
            }
            super.appendTooltip(stack, world, tooltip, context);
        }
    }

    public static class DruidHood extends ArmorItem {

        private static final UUID SPEED_BOOST_ID = UUID.randomUUID();

        public DruidHood(ArmorMaterial material, EquipmentSlot slot, Settings settings) {
            super(material, slot, settings);
        }

        @Override
        public void onArmorTick(World world, net.minecraft.entity.player.PlayerEntity player, ItemStack stack) {
            player.getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED).addTemporaryModifier(
                new EntityAttributeModifier(SPEED_BOOST_ID, "Druid Hood Speed Boost", 0.3, EntityAttributeModifier.Operation.MULTIPLY_TOTAL)
            );
        }

        @Override
        public void appendTooltip(ItemStack stack, World world, List<Text> tooltip, TooltipContext context) {
            if (InputUtil.isKeyPressed(MinecraftClient.getInstance().getWindow().getHandle(), GLFW.GLFW_KEY_LEFT_SHIFT)) {
                tooltip.add(Text.literal("Unisex: Increases speed to sprinting"));
            } else {
                tooltip.add(Text.literal("Hold Shift for more info"));
            }
            super.appendTooltip(stack, world, tooltip, context);
        }
    }
}
