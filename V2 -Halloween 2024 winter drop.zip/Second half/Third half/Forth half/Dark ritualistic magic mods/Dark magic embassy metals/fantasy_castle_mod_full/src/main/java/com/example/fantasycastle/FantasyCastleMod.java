
package com.example.fantasycastle;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.datagen.v1.DataGeneratorEntrypoint;
import net.fabricmc.fabric.api.datagen.v1.FabricDataGenerator;
import net.fabricmc.fabric.api.datagen.v1.provider.*;
import net.fabricmc.fabric.api.loot.v1.event.LootTableLoadingCallback;
import net.minecraft.block.Block;
import net.minecraft.block.Material;
import net.minecraft.data.server.RecipeJsonProvider;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.loot.LootManager;
import net.minecraft.loot.LootTable;
import net.minecraft.loot.entry.ItemEntry;
import net.minecraft.loot.function.SetCountLootFunction;
import net.minecraft.loot.provider.number.ConstantLootNumberProvider;
import net.minecraft.tag.TagKey;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;
import net.minecraft.util.registry.RegistryEntryList;

import java.util.function.BiConsumer;
import java.util.function.Consumer;

public class FantasyCastleMod implements ModInitializer, DataGeneratorEntrypoint {

    public static final String MOD_ID = "fantasycastle";

    // Define the items and blocks
    public static final Item DARK_IRON_DUST = new Item(new Item.Settings().group(ItemGroup.MATERIALS));
    public static final Item DARK_IRON_INGOT = new Item(new Item.Settings().group(ItemGroup.MATERIALS));
    public static final Item DARK_IRON_NUGGET = new Item(new Item.Settings().group(ItemGroup.MATERIALS));
    public static final Block DARK_IRON_BLOCK = new Block(Block.Settings.of(Material.METAL).strength(5.0f, 6.0f));
    public static final BlockItem DARK_IRON_BLOCK_ITEM = new BlockItem(DARK_IRON_BLOCK, new Item.Settings().group(ItemGroup.BUILDING_BLOCKS));

    // Define loot table identifiers for structures
    private static final Identifier[] LOOT_TABLES = {
        new Identifier("minecraft", "chests/shipwreck_treasure"),
        new Identifier("minecraft", "chests/simple_dungeon"),
        new Identifier("minecraft", "chests/abandoned_mineshaft"),
        new Identifier("minecraft", "chests/stronghold_corridor"),
        new Identifier("minecraft", "chests/stronghold_library"),
        new Identifier("minecraft", "chests/stronghold_crossing"),
        new Identifier("minecraft", "chests/nether_bridge"),
        new Identifier("minecraft", "chests/bastion_treasure")
    };

    // Define item tags
    public static final TagKey<Item> DARK_IRON_INGOTS_TAG = TagKey.of(Registry.ITEM_KEY, new Identifier(MOD_ID, "dark_iron_ingots"));
    public static final TagKey<Item> DARK_IRON_DUST_TAG = TagKey.of(Registry.ITEM_KEY, new Identifier(MOD_ID, "dark_iron_dust"));
    public static final TagKey<Item> DARK_IRON_NUGGETS_TAG = TagKey.of(Registry.ITEM_KEY, new Identifier(MOD_ID, "dark_iron_nuggets"));

    @Override
    public void onInitialize() {
        // Register items
        Registry.register(Registry.ITEM, new Identifier(MOD_ID, "dark_iron_dust"), DARK_IRON_DUST);
        Registry.register(Registry.ITEM, new Identifier(MOD_ID, "dark_iron_ingot"), DARK_IRON_INGOT);
        Registry.register(Registry.ITEM, new Identifier(MOD_ID, "dark_iron_nugget"), DARK_IRON_NUGGET);

        // Register blocks
        Registry.register(Registry.BLOCK, new Identifier(MOD_ID, "dark_iron_block"), DARK_IRON_BLOCK);
        Registry.register(Registry.ITEM, new Identifier(MOD_ID, "dark_iron_block"), DARK_IRON_BLOCK_ITEM);

        // Modify loot tables to include dark iron dust
        LootTableLoadingCallback.EVENT.register((resourceManager, lootManager, id, supplier, setter) -> {
            for (Identifier lootTable : LOOT_TABLES) {
                if (lootTable.equals(id)) {
                    supplier.withPool(LootTable.builder()
                            .withEntry(ItemEntry.builder(DARK_IRON_DUST)
                                    .apply(SetCountLootFunction.builder(ConstantLootNumberProvider.create(1))).build())
                            .build());
                }
            }
        });
    }

    @Override
    public void onInitializeDataGenerator(FabricDataGenerator dataGenerator) {
        dataGenerator.addProvider(ModelProvider::new);
        dataGenerator.addProvider(RecipeProvider::new);
        dataGenerator.addProvider(LootTableProvider::new);
        dataGenerator.addProvider(BlockStateProvider::new);
        dataGenerator.addProvider(TagProvider::new);
    }

    public static class ModelProvider extends FabricModelProvider {
        public ModelProvider(FabricDataGenerator dataGenerator) {
            super(dataGenerator);
        }

        @Override
        public void generateBlockStateModels() {
            blockStateModels.simpleBlock(DARK_IRON_BLOCK);
        }

        @Override
        public void generateItemModels() {
            itemModels.handheld(DARK_IRON_DUST);
            itemModels.handheld(DARK_IRON_INGOT);
            itemModels.handheld(DARK_IRON_NUGGET);
            itemModels.handheldItem(DARK_IRON_BLOCK_ITEM);
        }
    }

    public static class RecipeProvider extends FabricRecipeProvider {
        public RecipeProvider(FabricDataGenerator dataGenerator) {
            super(dataGenerator);
        }

        @Override
        protected void generateRecipes(Consumer<RecipeJsonProvider> exporter) {
            offerSmelting(exporter, DARK_IRON_INGOT, DARK_IRON_DUST, 0.7f, 200, "dark_iron_ingot");
            offerReversibleCompactingRecipes(exporter, DARK_IRON_INGOT, DARK_IRON_NUGGET, "dark_iron_ingot_to_nugget");
        }
    }

    public static class LootTableProvider extends FabricLootTableProvider {
        public LootTableProvider(FabricDataGenerator dataGenerator) {
            super(dataGenerator);
        }

        @Override
        public void generateLootTables(BiConsumer<Identifier, LootTable.Builder> consumer) {
            LootManager.registerBlockLootTable(DARK_IRON_BLOCK, consumer);
        }
    }

    public static class BlockStateProvider extends FabricBlockStateProvider {
        public BlockStateProvider(FabricDataGenerator dataGenerator) {
            super(dataGenerator);
        }

        @Override
        protected void generateBlockStates() {
            blockStateModels.simpleBlock(DARK_IRON_BLOCK);
        }
    }

    public static class TagProvider extends FabricTagProvider<Item> {
        public TagProvider(FabricDataGenerator dataGenerator) {
            super(dataGenerator, Registry.ITEM);
        }

        @Override
        protected void generateTags() {
            getOrCreateTagBuilder(DARK_IRON_INGOTS_TAG).add(DARK_IRON_INGOT);
            getOrCreateTagBuilder(DARK_IRON_DUST_TAG).add(DARK_IRON_DUST);
            getOrCreateTagBuilder(DARK_IRON_NUGGETS_TAG).add(DARK_IRON_NUGGET);
        }
    }
}
