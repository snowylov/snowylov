package com.alex.darkmagicembassy;

import com.alex.darkmagicembassy.entity.BeamProjectileEntity;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.datagen.v1.FabricDataGenerator;
import net.fabricmc.fabric.api.datagen.v1.FabricDataGeneratorBuilder;
import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.fabricmc.fabric.api.object.builder.v1.item.FabricItemSettings;
import net.fabricmc.fabric.api.tag.v1.FabricTagProvider;
import net.minecraft.block.Block;
import net.minecraft.block.Material;
import net.minecraft.data.client.BlockStateModelGenerator;
import net.minecraft.data.client.ItemModelGenerator;
import net.minecraft.data.client.ModelIds;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.DefaultParticleType;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.List;

public class DarkMagicEmbassy implements ModInitializer {
    public static final String MODID = "darkmagicembassy";

    // Blocks and Items
    public static final Block HEALING_RUNE_BLOCK_LEVEL_1;
    public static final Block HEALING_RUNE_BLOCK_LEVEL_2;
    public static final Block HEALING_RUNE_BLOCK_LEVEL_3;
    public static final Block HEALING_RUNE_BLOCK_LEVEL_4;
    public static final Item RUNE_STONE;
    public static final Item MAGIC_SACRIFICIAL_DAGGER;
    public static final Item PSYCHIC_SACRIFICIAL_DAGGER;
    public static final Item POWER_SACRIFICIAL_DAGGER;
    public static final Item MOST_XTREME_SACRIFICIAL_DAGGER;

    // All registered potion rune blocks
    public static final List<Block> POTION_RUNE_BLOCKS = new ArrayList<>();

    // Static Initialization
    static {
        // Initialize healing rune blocks
        HEALING_RUNE_BLOCK_LEVEL_1 = new HealingRuneBlock(FabricBlockSettings.of(Material.STONE), 1);
        HEALING_RUNE_BLOCK_LEVEL_2 = new HealingRuneBlock(FabricBlockSettings.of(Material.STONE), 2);
        HEALING_RUNE_BLOCK_LEVEL_3 = new HealingRuneBlock(FabricBlockSettings.of(Material.STONE), 3);
        HEALING_RUNE_BLOCK_LEVEL_4 = new HealingRuneBlock(FabricBlockSettings.of(Material.STONE), 4);

        // Initialize rune stone item
        RUNE_STONE = new Item(new FabricItemSettings().group(ItemGroup.MISC));

        // Initialize sacrificial daggers
        MAGIC_SACRIFICIAL_DAGGER = new SacrificialDagger(new FabricItemSettings().group(ItemGroup.COMBAT), "magic");
        PSYCHIC_SACRIFICIAL_DAGGER = new SacrificialDagger(new FabricItemSettings().group(ItemGroup.COMBAT), "psychic");
        POWER_SACRIFICIAL_DAGGER = new SacrificialDagger(new FabricItemSettings().group(ItemGroup.COMBAT), "power");
        MOST_XTREME_SACRIFICIAL_DAGGER = new SacrificialDagger(new FabricItemSettings().group(ItemGroup.COMBAT), "most_xtreme");

        // Register Potion Rune Blocks for all effects including modded
        for (StatusEffect effect : Registry.STATUS_EFFECT) {
            Block potionRuneBlock = new PotionRuneBlock(FabricBlockSettings.of(Material.STONE), effect);
            POTION_RUNE_BLOCKS.add(potionRuneBlock);
        }
    }

    @Override
    public void onInitialize() {
        // Register healing rune blocks
        Registry.register(Registry.BLOCK, new Identifier(MODID, "healing_rune_block_level_1"), HEALING_RUNE_BLOCK_LEVEL_1);
        Registry.register(Registry.BLOCK, new Identifier(MODID, "healing_rune_block_level_2"), HEALING_RUNE_BLOCK_LEVEL_2);
        Registry.register(Registry.BLOCK, new Identifier(MODID, "healing_rune_block_level_3"), HEALING_RUNE_BLOCK_LEVEL_3);
        Registry.register(Registry.BLOCK, new Identifier(MODID, "healing_rune_block_level_4"), HEALING_RUNE_BLOCK_LEVEL_4);

        // Register rune stone item
        Registry.register(Registry.ITEM, new Identifier(MODID, "rune_stone"), RUNE_STONE);

        // Register sacrificial daggers
        Registry.register(Registry.ITEM, new Identifier(MODID, "magic_sacrificial_dagger"), MAGIC_SACRIFICIAL_DAGGER);
        Registry.register(Registry.ITEM, new Identifier(MODID, "psychic_sacrificial_dagger"), PSYCHIC_SACRIFICIAL_DAGGER);
        Registry.register(Registry.ITEM, new Identifier(MODID, "power_sacrificial_dagger"), POWER_SACRIFICIAL_DAGGER);
        Registry.register(Registry.ITEM, new Identifier(MODID, "most_xtreme_sacrificial_dagger"), MOST_XTREME_SACRIFICIAL_DAGGER);

        // Register all potion rune blocks
        for (Block potionRuneBlock : POTION_RUNE_BLOCKS) {
            Identifier id = new Identifier(MODID, "potion_rune_" + Registry.STATUS_EFFECT.getId(((PotionRuneBlock) potionRuneBlock).getEffect()).getPath());
            Registry.register(Registry.BLOCK, id, potionRuneBlock);
        }

        // Register beam projectile entity
        Registry.register(Registry.ENTITY_TYPE, new Identifier(MODID, "beam_projectile"),
            FabricEntityTypeBuilder.create(SpawnGroup.MISC, BeamProjectileEntity::new)
                .dimensions(EntityDimensions.fixed(0.5f, 0.5f))
                .build()
        );

        // Register other components if needed...
    }

    // Healing Rune Block
    public static class HealingRuneBlock extends Block {
        private final int level;

        public HealingRuneBlock(Settings settings, int level) {
            super(settings);
            this.level = level;
        }

        public void applyHealingEffect(PlayerEntity player) {
            int healingAmount = level * 5 * 2; // 5, 10, 15, 20 hearts (10, 20, 30, 40 health points)
            player.heal(healingAmount);
        }
    }

    // Potion Rune Block
    public static class PotionRuneBlock extends Block {
        private final StatusEffect effect;

        public PotionRuneBlock(Settings settings, StatusEffect effect) {
            super(settings);
            this.effect = effect;
        }

        public StatusEffect getEffect() {
            return effect;
        }

        public void applyPotionEffect(PlayerEntity player) {
            if (effect != null) {
                // Apply the potion effect to the player
                player.addStatusEffect(new StatusEffectInstance(effect, 200, 1)); // Example duration and amplifier
            }
        }

        public Identifier getTexture() {
            if (effect != null) {
                if (effect.isBeneficial()) {
                    return new Identifier(MODID, "textures/block/rune_good.png");
                } else if (effect.isHarmful()) {
                    return new Identifier(MODID, "textures/block/rune_trap.png");
                } else {
                    return new Identifier(MODID, "textures/block/rune_white.png");
                }
            }
            return new Identifier(MODID, "textures/block/rune_unknown.png");
        }
    }

    // Sacrificial Dagger Item
    public static class SacrificialDagger extends Item {
        private final String type;

        public SacrificialDagger(Settings settings, String type) {
            super(settings);
            this.type = type;
        }

        // Implement logic to instantly kill animal mobs near an altar
        @Override
        public boolean postHit(ItemStack stack, LivingEntity target, LivingEntity attacker) {
            if (target instanceof AnimalEntity && attacker.isInRange(target, 16.0)) {
                // Check if near an altar
                for (BlockPos pos : BlockPos.iterate(target.getBlockPos().add(-2, -2, -2), target.getBlockPos().add(2, 2, 2))) {
                    Block block = target.world.getBlockState(pos).getBlock();
                    if (block instanceof AltarBlockEntity) {
                        target.kill(); // Instant kill
                        return true;
                    }
                }
            }
            return super.postHit(stack, target, attacker);
        }
    }

    // Altar Block Entity
    public static class AltarBlockEntity extends BlockEntity {
        private int soulCount;

        public AltarBlockEntity(BlockEntityType<?> type, BlockPos pos, BlockState state) {
            super(type, pos, state);
        }

        public void addSoul() {
            soulCount++;
        }

        @Override
        public void writeNbt(NbtCompound nbt) {
            super.writeNbt(nbt);
           
    @Override
    public void readNbt(NbtCompound nbt) {
        super.readNbt(nbt);
        soulCount = nbt.getInt("SoulCount");
    }
}

// Beam Projectile Entity
public static class BeamProjectileEntity extends PersistentProjectileEntity {
    private static final int BEAM_DURATION_TICKS = 80; // 4 seconds

    public BeamProjectileEntity(EntityType<? extends PersistentProjectileEntity> entityType, World world) {
        super(entityType, world);
    }

    public BeamProjectileEntity(World world, LivingEntity owner) {
        super(ModEntities.BEAM_PROJECTILE, owner, world);
        this.setNoGravity(true);
    }

    @Override
    protected void onCollision(HitResult hitResult) {
        super.onCollision(hitResult);
        if (hitResult instanceof EntityHitResult) {
            EntityHitResult entityHitResult = (EntityHitResult) hitResult;
            entityHitResult.getEntity().damage(DamageSource.magic(this, this.getOwner()), 5.0F);
        }

        if (!this.world.isClient) {
            this.remove(RemovalReason.DISCARDED);
        }
    }

    @Override
    public void tick() {
        super.tick();

        // Calculate the direction and spawn particles along the path
        Vec3d startPos = this.getPos();
        Vec3d direction = this.getVelocity().normalize();
        double distance = this.getVelocity().length();
        double step = 0.1; // Particle spawn step

        for (double d = 0; d <= distance; d += step) {
            Vec3d particlePos = startPos.add(direction.multiply(d));
            this.world.addParticle(ParticleTypes.END_ROD, particlePos.x, particlePos.y, particlePos.z, 0, 0, 0);
        }

        if (this.age >= BEAM_DURATION_TICKS) {
            this.remove(RemovalReason.DISCARDED);
        }
    }

    public void setBeamDirection(Vec3d direction) {
        this.setVelocity(direction);
    }
}

// Curse of Souls Enchantment
public static class CurseOfSoulsEnchantment extends Enchantment {
    public CurseOfSoulsEnchantment() {
        super(Rarity.UNCOMMON, EnchantmentTarget.WEAPON, new EquipmentSlot[]{EquipmentSlot.MAINHAND});
    }

    @Override
    public void onTargetDamaged(LivingEntity user, Entity target, int level) {
        if (target instanceof LivingEntity) {
            // Apply custom damage over time
            ((LivingEntity) target).addScoreboardTag("cursed_souls");
        }
    }

    // Custom method to handle damage over time (called every tick)
    public static void applyCurseDamage(LivingEntity entity) {
        if (entity.getScoreboardTags().contains("cursed_souls")) {
            entity.damage(DamageSource.MAGIC, 1.0F); // Deal 1 damage every tick
            // Remove the tag if needed after applying damage
        }
    }
}

// Data Generation for Tags
public static class DataGeneration {
    public static void registerDataGenerators(FabricDataGenerator dataGenerator) {
        dataGenerator.addProvider(new FabricBlockStateProvider(dataGenerator) {
            @Override
            protected void generateBlockStateModels(BlockStateModelGenerator blockStateModelGenerator) {
                // Register block models and block states
                blockStateModelGenerator.registerSimpleCubeAll(DarkMagicEmbassy.HEALING_RUNE_BLOCK_LEVEL_1);
                blockStateModelGenerator.registerSimpleCubeAll(DarkMagicEmbassy.HEALING_RUNE_BLOCK_LEVEL_2);
                blockStateModelGenerator.registerSimpleCubeAll(DarkMagicEmbassy.HEALING_RUNE_BLOCK_LEVEL_3);
                blockStateModelGenerator.registerSimpleCubeAll(DarkMagicEmbassy.HEALING_RUNE_BLOCK_LEVEL_4);
                for (Block block : DarkMagicEmbassy.POTION_RUNE_BLOCKS) {
                    blockStateModelGenerator.registerSimpleCubeAll(block);
                }
            }
        });

        dataGenerator.addProvider(new FabricModelProvider(dataGenerator) {
            @Override
            public void generateBlockStateModels(BlockStateModelGenerator blockStateModelGenerator) {
                // Same block models as above
            }

            @Override
            public void generateItemModels(ItemModelGenerator itemModelGenerator) {
                // Register item models
                itemModelGenerator.register(DarkMagicEmbassy.RUNE_STONE, ModelIds.getItemModelId(DarkMagicEmbassy.RUNE_STONE));
                itemModelGenerator.register(DarkMagicEmbassy.HEALING_RUNE_BLOCK_LEVEL_1.asItem(), ModelIds.getItemModelId(DarkMagicEmbassy.HEALING_RUNE_BLOCK_LEVEL_1));
                itemModelGenerator.register(DarkMagicEmbassy.HEALING_RUNE_BLOCK_LEVEL_2.asItem(), ModelIds.getItemModelId(DarkMagicEmbassy.HEALING_RUNE_BLOCK_LEVEL_2));
                itemModelGenerator.register(DarkMagicEmbassy.HEALING_RUNE_BLOCK_LEVEL_3.asItem(), ModelIds.getItemModelId(DarkMagicEmbassy.HEALING_RUNE_BLOCK_LEVEL_3));
                itemModelGenerator.register(DarkMagicEmbassy.HEALING_RUNE_BLOCK_LEVEL_4.asItem(), ModelIds.getItemModelId(DarkMagicEmbassy.HEALING_RUNE_BLOCK_LEVEL_4));
                for (Block block : DarkMagicEmbassy.POTION_RUNE_BLOCKS) {
                    itemModelGenerator.register(block.asItem(), ModelIds.getItemModelId(block));
                }
            }
        });

        dataGenerator.addProvider(new FabricRecipeProvider(dataGenerator) {
            @Override
            protected void generateRecipes(RecipeExporter exporter) {
                // Register crafting recipes if needed
            }
        });

        dataGenerator.addProvider(new FabricBlockLootTablesProvider(dataGenerator) {
            @Override
            protected void generateBlockLootTables() {
                // Register loot tables for block drops
                addDrop(DarkMagicEmbassy.HEALING_RUNE_BLOCK_LEVEL_1);
                addDrop(DarkMagicEmbassy.HEALING_RUNE_BLOCK_LEVEL_2);
                addDrop(DarkMagicEmbassy.HEALING_RUNE_BLOCK_LEVEL_3);
                addDrop(DarkMagicEmbassy.HEALING_RUNE_BLOCK_LEVEL_4);
                for (Block block : DarkMagicEmbassy.POTION_RUNE_BLOCKS) {
                    addDrop(block);
                }
            }
        });

        dataGenerator.addProvider(new FabricTagProvider<Block>(dataGenerator, Registry.BLOCK) {
            @Override
            protected void generateTags() {
                getOrCreateTagBuilder(new Identifier(MODID, "rune_blocks")).add(DarkMagicEmbassy.POTION_RUNE_BLOCKS.toArray(new Block[0]));
                getOrCreateTagBuilder(new Identifier(MODID, "healing_runes")).add(
                        DarkMagicEmbassy.HEALING_RUNE_BLOCK_LEVEL_1,
                        DarkMagicEmbassy.HEALING_RUNE_BLOCK_LEVEL_2,
                        DarkMagicEmbassy.HEALING_RUNE_BLOCK_LEVEL_3,
                        DarkMagicEmbassy.HEALING_RUNE_BLOCK_LEVEL_4
                );
                getOrCreateTagBuilder(new Identifier(MODID, "alters")).add(DarkMagicEmbassy.HEALING_RUNE_BLOCK_LEVEL_1, DarkMagicEmbassy.HEALING_RUNE_BLOCK_LEVEL_2);
            }
        });

        dataGenerator.addProvider(new FabricTagProvider<Item>(dataGenerator, Registry.ITEM) {
            @Override
            protected void generateTags() {
                getOrCreateTagBuilder(new Identifier(MODID, "sacrificial_daggers")).add(
                        DarkMagicEmbassy.MAGIC_SACRIFICIAL_DAGGER,
                        DarkMagicEmbassy.PSYCHIC_SACRIFICIAL_DAGGER,
                        DarkMagicEmbassy.POWER_SACRIFICIAL_DAGGER,
                        DarkMagicEmbassy.MOST_XTREME_SACRIFICIAL_DAGGER
                );
            }
        });
    }
}

// Projectile Registration Hooks
public static class ProjectileRegistry {
    public static void registerProjectile(String id, EntityType<? extends PersistentProjectileEntity> entityType) {
        Registry.register(Registry.ENTITY_TYPE, new Identifier(MODID, id), entityType);
    }

    public static void registerBlockProjectile(String id, Block block) {
        EntityType<PersistentProjectileEntity> entityType = FabricEntityTypeBuilder.<PersistentProjectileEntity>create(SpawnGroup.MISC, (entity, world) -> new BlockProjectileEntity(world, block))
                .dimensions(EntityDimensions.fixed(0.5f, 0.5f)).build();
        registerProjectile(id, entityType);
    }

    public static void registerItemProjectile(String id, Item item) {
        EntityType<PersistentProjectileEntity> entityType = FabricEntityTypeBuilder.<PersistentProjectileEntity>create(SpawnGroup.MISC, (entity, world) -> new ItemProjectileEntity(world, item))
                .dimensions(EntityDimensions.fixed(0.5f, 0.5f)).build();
        registerProjectile(id, entityType);
    }

    public static void registerWaveProjectile(String id, DefaultParticleType particleType, boolean useItemTexture) {
        EntityType<PersistentProjectileEntity> entityType = FabricEntityTypeBuilder.<PersistentProjectileEntity>create(SpawnGroup.MISC, (entity, world) -> new WaveProjectileEntity(world, particleType, useItemTexture))
                .dimensions(EntityDimensions.fixed(0.5f, 1.0f)).build();
        registerProjectile(id, entityType);
    }

    public static void registerWaveProjectile(String id, Block block) {
        registerWaveProjectile(id, ParticleTypes.BLOCK, blo);
        }

        private static void registerWaveProjectile(String id, DefaultParticleType particleType, Block block) {
            EntityType<PersistentProjectileEntity> entityType = FabricEntityTypeBuilder.<PersistentProjectileEntity>create(SpawnGroup.MISC, (entity, world) -> new BlockWaveProjectileEntity(world, block, particleType))
                    .dimensions(EntityDimensions.fixed(0.5f, 1.0f)).build();
            registerProjectile(id, entityType);
        }
    }

    // Example Projectiles
    public static class BlockProjectileEntity extends PersistentProjectileEntity {
        private final Block block;

        public BlockProjectileEntity(World world, Block block) {
            super(ModEntities.BLOCK_PROJECTILE, world);
            this.block = block;
        }

        @Override
        public void tick() {
            super.tick();
            this.world.addParticle(new BlockStateParticleEffect(ParticleTypes.BLOCK, block.getDefaultState()), this.getX(), this.getY(), this.getZ(), 0, 0, 0);
        }
    }

    public static class ItemProjectileEntity extends PersistentProjectileEntity {
        private final Item item;

        public ItemProjectileEntity(World world, Item item) {
            super(ModEntities.ITEM_PROJECTILE, world);
            this.item = item;
        }

        @Override
        public void tick() {
            super.tick();
            this.world.addParticle(new ItemStackParticleEffect(ParticleTypes.ITEM, new ItemStack(item)), this.getX(), this.getY(), this.getZ(), 0, 0, 0);
        }
    }

    public static class WaveProjectileEntity extends PersistentProjectileEntity {
        private final DefaultParticleType particleType;
        private final boolean useItemTexture;

        public WaveProjectileEntity(World world, DefaultParticleType particleType, boolean useItemTexture) {
            super(ModEntities.WAVE_PROJECTILE, world);
            this.particleType = particleType;
            this.useItemTexture = useItemTexture;
        }

        @Override
        public void tick() {
            super.tick();
            // Add custom wave-like particle effects
            this.world.addParticle(particleType, this.getX(), this.getY(), this.getZ(), 0, 0, 0);
        }
    }

    public static class BlockWaveProjectileEntity extends PersistentProjectileEntity {
        private final Block block;
        private final DefaultParticleType particleType;

        public BlockWaveProjectileEntity(World world, Block block, DefaultParticleType particleType) {
            super(ModEntities.BLOCK_WAVE_PROJECTILE, world);
            this.block = block;
            this.particleType = particleType;
        }

        @Override
        public void tick() {
            super.tick();
            // Add custom block wave-like particle effects
            this.world.addParticle(new BlockStateParticleEffect(particleType, block.getDefaultState()), this.getX(), this.getY(), this.getZ(), 0, 0, 0);
        }
    }
}
