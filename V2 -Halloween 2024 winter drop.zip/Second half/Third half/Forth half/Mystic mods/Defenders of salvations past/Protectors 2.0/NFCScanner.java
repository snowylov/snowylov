import javax.smartcardio.*;
import java.util.List;

public class NFCScanner {
    private TerminalFactory terminalFactory;
    private CardTerminals terminals;
    private CardTerminal connectedTerminal;

    public NFCScanner() {
        try {
            terminalFactory = TerminalFactory.getDefault();
            terminals = terminalFactory.terminals();
        } catch (CardException e) {
            System.out.println("Error initializing NFCScanner: " + e.getMessage());
        }
    }

    public void scanAndConnect() {
        try {
            List<CardTerminal> terminalList = terminals.list();
            for (CardTerminal terminal : terminalList) {
                try {
                    if (terminal.isCardPresent()) {
                        connectedTerminal = terminal;
                        System.out.println("Connected to NFC reader on port: " + terminal.getName());
                        return;
                    }
                } catch (CardException e) {
                    System.out.println("Error connecting to terminal: " + terminal.getName());
                }
            }
            System.out.println("No NFC reader found.");
        } catch (CardException e) {
            System.out.println("Error scanning for NFC readers: " + e.getMessage());
        }
    }

    public CardTerminal getConnectedTerminal() {
        return connectedTerminal;
    }
}