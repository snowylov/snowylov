package com.example.protectorsmod;

import net.fabricmc.api.ModInitializer;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.IronGolemEntity;
import net.minecraft.entity.passive.CatEntity;
import net.minecraft.entity.passive.SnowGolemEntity;
import net.minecraft.entity.passive.WolfEntity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.LiteralText;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.entity.LivingEntity;

import java.util.HashMap;
import java.util.Map;

public class ProtectorsMod implements ModInitializer {
    private static final String[] NFC_TEXT_GOLEM_SERIES = {
        "problem_solver_3000_2", "problem_solver_3000_3", "problem_solver_3000_4",
        "problem_solver_3000_5", "problem_solver_3000_6", "problem_solver_3000_7",
        "problem_solver_3000_8", "problem_solver_3000_9", "problem_solver_3000_10",
        "problem_solver_3000_lightcore"
    };
    private static final String[] NFC_TEXT_FISH_SERIES = {
        "fishton", "Fishton"
    };
    private static final String[] NFC_TEXT_WOLF_SERIES = {
        "wolfy_2", "wolfy_3", "wolfy_4", "wolfy_5",
        "wolfy_6", "wolfy_7", "wolfy_8", "wolfy_9",
        "wolfy_10", "wolfy_lightcore"
    };
    private static final String[] NFC_TEXT_SNOW_GOLEM_SERIES = {
        "shetywazoo_1", "shetywazoo_2", "shetywazoo_3", "shetywazoo_4",
        "shetywazoo_5", "shetywazoo_6", "shetywazoo_7", "shetywazoo_8",
        "shetywazoo_9", "shetywazoo_10", "shetywazoo_lightcore"
    };
    private static final int COOLDOWN_TICKS = 3600; // 3 minutes in ticks
    private int lastSpawnTick = -COOLDOWN_TICKS;

    private NFCScanner nfcScanner;
    private NFCReader nfcReader;
    private Map<String, LivingEntity> activeEntities = new HashMap<>();

    @Override
    public void onInitialize() {
        // Initialize the NFC scanner and reader
        nfcScanner = new NFCScanner();
        nfcScanner.scanAndConnect();
        nfcReader = new NFCReader(nfcScanner);

        System.out.println("ProtectorsMod initialized!");
    }

    public void checkAndSpawnEntity(World world, MinecraftServer server) {
        int currentTick = server.getTicks();

        // Remove entities if their associated tag is no longer present
        for (String tag : activeEntities.keySet()) {
            if (!isTagPresent(tag)) {
                removeEntity(tag);
            }
        }

        if (currentTick - lastSpawnTick < COOLDOWN_TICKS) {
            System.out.println("Still in cooldown period.");
            return;
        }

        for (String tag : NFC_TEXT_GOLEM_SERIES) {
            if (nfcReader.isTextPresent(tag)) {
                lastSpawnTick = currentTick;
                spawnGolemSeries(world, tag);
                return;
            }
        }
        for (String tag : NFC_TEXT_GOLEM_SERIES) {
            if (nfcReader.isTextPresent(tag)) {
                lastSpawnTick = currentTick;
                spawnGolemSeries(world, tag);
                return;
            }
        }

        for (String tag : NFC_TEXT_FISH_SERIES) {
            if (nfcReader.isTextPresent(tag)) {
                lastSpawnTick = currentTick;
                Stun(world);
                return;
            }
        }

        for (String tag : NFC_TEXT_SNOW_GOLEM_SERIES) {
            if (nfcReader.isTextPresent(tag)) {
                lastSpawnTick = currentTick;
                spawnShetywazooSeries(world, tag);
                return;
            }
        }
    }

    private boolean isTagPresent(String tag) {
        return nfcReader.isTextPresent(tag);
    }

    private void removeEntity(String tag) {
        LivingEntity entity = activeEntities.remove(tag);
        if (entity != null && entity.isAlive()) {
            entity.remove(RemovalReason.DISCARDED);
            System.out.println("Removed entity associated with tag: " + tag);
        }
    }

    private void spawnGolemSeries(World world, String seriesTag) {
        ServerPlayerEntity nearestPlayer = world.getClosestPlayer(0, 0, 0, -1, false);
        if (nearestPlayer == null) {
            System.out.println("No player found to spawn the golem.");
            return;
        }

        int level = getLevelFromTag(seriesTag);
        BlockPos spawnPos = nearestPlayer.getBlockPos().add(1, 0, 1);
        IronGolemEntity golem = new IronGolemEntity(EntityType.IRON_GOLEM, world);
        golem.setCustomName(new LiteralText("Problem Solver " + seriesTag.replace("problem_solver_3000_", "").replace("_", " ")));
        golem.getAttributeInstance(EntityAttributes.GENERIC_ATTACK_DAMAGE).setBaseValue(10 + (level * 10));
        golem.getAttributeInstance(EntityAttributes.GENERIC_ARMOR).setBaseValue(20 + (level * 2)); // Assuming 20 is the base armor value
        golem.getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED).setBaseValue(0.25 + (level * 0.02)); // Assuming 0.25 is the base speed value
        golem.getAttributeInstance(EntityAttributes.GENERIC_RESISTANCE).setBaseValue(Double.MAX_VALUE); // Invincible
        golem.refreshPositionAndAngles(spawnPos, 0, 0);
        world.spawnEntity(golem);
        activeEntities.put(seriesTag, golem);
    }

public static void stun(World world) {
        if (world instanceof ServerWorld) {
            ServerWorld serverWorld = (ServerWorld) world;
            PlayerEntity player = serverWorld.getServer().getPlayerManager().getPlayerList().get(0); // Assuming the first player
            Box area = new Box(player.getX() - 10, player.getY() - 10, player.getZ() - 10, player.getX() + 10, player.getY() + 10, player.getZ() + 10);
            
            serverWorld.getEntitiesByClass(Entity.class, area, entity -> entity instanceof MobEntity || entity instanceof PlayerEntity)
                .forEach(entity -> {
                    if (entity instanceof LivingEntity livingEntity) {
                        livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 200, 4));
                        livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 200, 1));
                    }
                });

            serverWorld.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.BLOCK_NOTE_BLOCK_PLING, SoundCategory.PLAYERS, 1.0f, 1.0f);
        }
    }

    private void spawnWolfySeries(World world, String seriesTag) {
        ServerPlayerEntity nearestPlayer = world.getClosestPlayer(0, 0, 0, -1, false);
        if (nearestPlayer == null) {
            System.out.println("No player found to tame the wolf.");
            return;
        }

        int level = getLevelFromTag(seriesTag);
        BlockPos spawnPos = nearestPlayer.getBlockPos().add(1, 0, 1);
        WolfEntity wolf = new WolfEntity(EntityType.WOLF, world);
        wolf.setCustomName(new LiteralText("Wolfy " + seriesTag.replace("wolfy_", "").replace("_", " ")));
        wolf.getAttributeInstance(EntityAttributes.GENERIC_ATTACK_DAMAGE).setBaseValue(10 + (level * 10));
        wolf.getAttributeInstance(EntityAttributes.GENERIC_ARMOR).setBaseValue(20 + (level * 2)); // Assuming 20 is the base armor value
        wolf.getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED).setBaseValue(0.30 + (level * 0.02)); // Assuming 0.30 is the base speed value
        wolf.getAttributeInstance(EntityAttributes.GENERIC_RESISTANCE).setBaseValue(Double.MAX_VALUE); // Invincible
        wolf.setTamed(true);
        wolf.setOwnerUuid(nearestPlayer.getUuid());
        wolf.refreshPositionAndAngles(spawnPos, 0, 0);
        world.spawnEntity(wolf);
        activeEntities.put(seriesTag, wolf);
    }

    private void spawnShetywazooSeries(World world, String seriesTag) {
        ServerPlayerEntity nearestPlayer = world.getClosestPlayer(0, 0, 0, -1, false);
        if (nearestPlayer == null) {
            System.out.println("No player found to spawn the snow golem.");
            return;
        }

        int level = getLevelFromTag(seriesTag);
        BlockPos spawnPos = nearestPlayer.getBlockPos().add(1, 0, 1);
        SnowGolemEntity snowGolem = new SnowGolemEntity(EntityType.SNOW_GOLEM, world);
        snowGolem.setCustomName(new LiteralText("Shetywazoo " + seriesTag.replace("shetywazoo_", "").replace("_", " ")));
        snowGolem.getAttributeInstance(EntityAttributes.GENERIC_ATTACK_DAMAGE).setBaseValue(10 + (level * 10));
        snowGolem.getAttributeInstance(EntityAttributes.GENERIC_ARMOR).setBaseValue(20 + (level * 2)); // Assuming 20 is the base armor value
        snowGolem.getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED).setBaseValue(0.25 + (level * 0.02)); // Assuming 0.25 is the base speed value
        snowGolem.getAttributeInstance(EntityAttributes.GENERIC_RESISTANCE).setBaseValue(Double.MAX_VALUE); // Invincible
        snowGolem.setHealth(3000.0F);
        snowGolem.refreshPositionAndAngles(spawnPos, 0, 0);
        world.spawnEntity(snowGolem);
        activeEntities.put(seriesTag, snowGolem);
    }

    private int getLevelFromTag(String tag) {
        if (tag.contains("_lightcore")) {
            return 10; // Special case for Lightcore, consider it level 10
        }
        String[] parts = tag.split("_");
        try {
            return Integer.parseInt(parts[parts.length - 1]);
        } catch (NumberFormatException e) {
            return 0; // Default level if parsing fails
        }