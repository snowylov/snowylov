import javax.smartcardio.*;
import java.nio.charset.StandardCharsets;

public class NFCReader {
    private NFCScanner nfcScanner;
    private CardTerminal connectedTerminal;

    public NFCReader(NFCScanner scanner) {
        this.nfcScanner = scanner;
        this.connectedTerminal = scanner.getConnectedTerminal();
    }

    public boolean isTextPresent(String expectedText) {
        try {
            if (connectedTerminal != null && connectedTerminal.isCardPresent()) {
                // Connect to the card
                Card card = connectedTerminal.connect("*");
                CardChannel channel = card.getBasicChannel();

                // Read a certain block from the NTAG215 tag
                byte[] readCommand = new byte[] {
                    (byte)0x00, // CLA (Class of instruction)
                    (byte)0xB0, // INS (Instruction code for read)
                    (byte)0x00, // P1 (Parameter 1, offset high byte)
                    (byte)0x00, // P2 (Parameter 2, offset low byte)
                    (byte)0x10  // LE (Maximum number of bytes expected, here 16 bytes)
                };
                ResponseAPDU response = channel.transmit(new CommandAPDU(readCommand));

                byte[] responseData = response.getData();
                if (responseData != null && responseData.length > 0) {
                    // Convert the data to a string
                    String tagContent = new String(responseData, StandardCharsets.UTF_8).trim();

                    // Check if the expected text is present
                    if (tagContent.contains(expectedText)) {
                        System.out.println("Text found: " + expectedText);
                        return true;
                    } else {
                        System.out.println("Text not found.");
                    }
                }

                // Disconnect the card
                card.disconnect(false);
            } else {
                System.out.println("No card present.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}