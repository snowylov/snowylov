
package com.example.protectorsmod;

import net.fabricmc.api.ModInitializer;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.IronGolemEntity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.text.LiteralText;
import net.minecraft.world.World;
import net.minecraft.util.registry.Registry;

public class ProtectorsMod implements ModInitializer {
    private static final String NFC_TEXT = "problem_solver_3000";
    private static final int COOLDOWN_TICKS = 1800; // 1 minute 30 seconds in ticks
    private int lastSpawnTick = -COOLDOWN_TICKS;

    @Override
    public void onInitialize() {
        // Register mod initialization code here
        System.out.println("ProtectorsMod initialized!");
    }

    public void checkAndSpawnGolem(World world, MinecraftServer server) {
        int currentTick = server.getTicks();

        if (currentTick - lastSpawnTick < COOLDOWN_TICKS) {
            System.out.println("Still in cooldown period.");
            return;
        }

        NFCReader nfcReader = new NFCReader();
        if (nfcReader.isTextPresent(NFC_TEXT)) {
            lastSpawnTick = currentTick;
            spawnGolem(world);
        }
    }

    private void spawnGolem(World world) {
        IronGolemEntity golem = new IronGolemEntity(EntityType.IRON_GOLEM, world);
        golem.setCustomName(new LiteralText("Problem Solver 3000"));
        golem.getAttributeInstance(EntityAttributes.GENERIC_RESISTANCE).setBaseValue(Double.MAX_VALUE); // Invincible
        golem.getWorld().spawnEntity(golem);

        // Schedule golem removal after 30 seconds (600 ticks)
        world.getServer().getScheduler().schedule(() -> {
            if (golem.isAlive()) {
                golem.remove(RemovalReason.DISCARDED);
            }
        }, 600, TimeUnit.SECONDS);
    }
}
