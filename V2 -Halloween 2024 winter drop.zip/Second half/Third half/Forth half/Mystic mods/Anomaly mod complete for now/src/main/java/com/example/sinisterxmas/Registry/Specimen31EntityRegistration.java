package com.example.sinisterxmas.registry;

import com.example.sinisterxmas.entity.Specimen31Entity;
import net.fabricmc.fabric.api.client.rendereregistry.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.entity.FabricDefaultAttributeRegistry;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

public class Specimen31EntityRegistration {

    public static void registerSpecimen31() {
        // Register the entity type
        Registry.register(Registry.ENTITY_TYPE, new Identifier("sinisterxmas", "specimen_31"), Specimen31Entity.SPECIMEN_31_ENTITY);

        // Register the entity attributes
        FabricDefaultAttributeRegistry.register(Specimen31Entity.SPECIMEN_31_ENTITY, Specimen31Entity.createMobAttributes());

        // Register the entity renderer
        EntityRendererRegistry.INSTANCE.register(Specimen31Entity.SPECIMEN_31_ENTITY, (dispatcher, context) -> new Specimen31Entity.Specimen31EntityRenderer(dispatcher));
    }
}