package com.example.sinisterxmas.item;

import net.fabricmc.api.ModInitializer;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;
import net.minecraft.world.World;

public class WeedKiller extends Item {
    public static final WeedKiller WEED_KILLER = new WeedKiller(new Item.Settings().maxCount(16));

    public WeedKiller(Settings settings) {
        super(settings);
        Registry.register(Registry.ITEM, new Identifier("sinisterxmas", "weed_killer"), this);
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext context) {
        World world = context.getWorld();
        PlayerEntity player = context.getPlayer();
        ItemStack itemStack = context.getStack();

        if (!world.isClient && player != null && player.getMainHandStack().getItem() instanceof WeedKiller) {
            boolean hasParasite = world.getEntitiesByClass(TwilightAnomaly.class, player.getBoundingBox().expand(5), anomaly -> true).size() > 0;
            if (hasParasite) {
                itemStack.decrement(1);
                player.getEntityWorld().getEntitiesByClass(TwilightAnomaly.class, player.getBoundingBox().expand(5), anomaly -> true).forEach(anomaly -> anomaly.remove(RemovalReason.KILLED));
                return ActionResult.SUCCESS;
            }
        }
        return ActionResult.FAIL;
    }
}