
package com.example.sinisterxmas.entity.naomi;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.rendereregistry.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.client.render.entity.BipedEntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.math.Vector3f;
import net.minecraft.entity.*;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ArrowEntity;
import net.minecraft.item.*;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.text.LiteralText;
import net.minecraft.text.TranslatableText;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.registry.Registry;
import net.minecraft.world.World;
import net.minecraft.world.biome.Biome;

import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class NaomiEntity extends PathAwareEntity {
    public static final EntityType<NaomiEntity> NAOMI_ENTITY = Registry.register(
            Registry.ENTITY_TYPE,
            new Identifier("sinisterxmas", "naomi"),
            FabricEntityTypeBuilder.create(SpawnGroup.CREATURE, NaomiEntity::new)
                    .dimensions(EntityDimensions.fixed(0.6f, 1.8f))
                    .trackable(128, 3)
                    .build()
    );

public static void register() {
        // Register entity attributes
        FabricDefaultAttributeRegistry.register(NAOMI_ENTITY, NaomiEntity.createMobAttributes());

        // Register entity renderer
        EntityRendererRegistry.register(NAOMI_ENTITY, (EntityRendererFactory.Context dispatcher) -> 
            new NaomiEntityRenderer(dispatcher, new BipedEntityModel<>(dispatcher.getPart(EntityModelLayer.create("naomi", "main"))))
        );
    }
}

    private static Map<String, List<String>> replies;
    private static Map<String, List<String>> zappyReplies;
    private static Map<String, List<String>> meanRepliesToSpecimen31;

    private ItemStack heldBow = ItemStack.EMPTY;
    private ItemStack heldSword = ItemStack.EMPTY;

    private long lastZappyTime = 0;
    private boolean isZappy = false;
    private boolean isInBox = false;
    private int rightClickCount = 0;
    private int sneakCount = 0;
    private long lastInteractionTime = 0;
    private int relationshipStatus = 60;

    public NaomiEntity(EntityType<? extends PathAwareEntity> entityType, World world) {
        super(entityType, world);
        this.experiencePoints = 10;
        if (replies == null || zappyReplies == null || meanRepliesToSpecimen31 == null) {
            loadReplies();
        }
    }

    public static DefaultAttributeContainer.Builder createMobAttributes() {
        return PathAwareEntity.createMobAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 100.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.35)
                .add(EntityAttributes.GENERIC_ARMOR, 10.0)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 7.0)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 40.0);
    }

    private static void loadReplies() {
        Gson gson = new Gson();
        Type type = new TypeToken<Map<String, List<String>>>() {}.getType();
        replies = gson.fromJson(new InputStreamReader(NaomiEntity.class.getResourceAsStream("/assets/sinisterxmas/lang/naomi_replies.json")), type);
        zappyReplies = gson.fromJson(new InputStreamReader(NaomiEntity.class.getResourceAsStream("/assets/sinisterxmas/lang/naomi_zappy_replies.json")), type);
        meanRepliesToSpecimen31 = gson.fromJson(new InputStreamReader(NaomiEntity.class.getResourceAsStream("/assets/sinisterxmas/lang/naomi_mean_replies_to_specimen31.json")), type);
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(1, new FollowPlayerGoal(this, 1.0, 4.0F, 6.0F));
        this.goalSelector.add(2, new OpenDoorGoal(this, true));
        this.goalSelector.add(3, new CloseDoorGoal(this, true));
        this.goalSelector.add(4, new MeleeAttackGoal(this, 1.0, true));
        this.goalSelector.add(5, new WanderAroundFarGoal(this, 1.0));
        this.goalSelector.add(6, new LookAtEntityGoal(this, PlayerEntity.class, 8.0F));
        this.goalSelector.add(7, new LookAroundGoal(this));
        this.goalSelector.add(8, new AttackSpecimen31Goal(this));
        this.goalSelector.add(9, new GetZappyGoal(this));
        this.goalSelector.add(10, new DanceGoal(this));
        this.goalSelector.add(11, new TeacherAIGoal(this));
    }

    @Override
    public boolean interactMob(PlayerEntity player, Hand hand) {
        ItemStack stack = player.getStackInHand(hand);

        if (!stack.isEmpty()) {
            if (stack.getItem() instanceof BowItem) {
                this.heldBow = stack;
                player.sendMessage(Text.literal("Naomi: I can use this bow to protect you."), true);
                return ActionResult.SUCCESS;
            } else if (stack.getItem() instanceof CrossbowItem) {
                player.sendMessage(Text.literal("Naomi: I don't want it if it's not a bow."), true);
                return ActionResult.SUCCESS;
            } else if (stack.getItem() instanceof SwordItem) {
                if (stack.getItem() == Items.WOODEN_SWORD || stack.getItem() == Items.GOLDEN_SWORD || stack.getItem() == Items.DIAMOND_SWORD) {
                    this.heldSword = stack;
                    player.sendMessage(Text.literal("Naomi: This sword is flashy and enchantable, I like it."), true);
                    return ActionResult.SUCCESS;
                } else {
                    player.sendMessage(Text.literal("Naomi: I prefer wooden, gold, or diamond swords."), true);
                    return ActionResult.PASS;
                }
            } else if (stack.getItem() instanceof BlockItem && ((BlockItem) stack.getItem()).getBlock() instanceof FlowerBlock) {
                if (player.getName().getString().toLowerCase().contains("snowielove1")) {
                    player.sendMessage(Text.literal(getRandomReply("romantic_replies")), true);
                    return ActionResult.SUCCESS;
                } else if (player.getName().getString().toLowerCase().contains("snowielove2")) {
                    player.sendMessage(Text.literal(getRandomReply("end_related_facts")), true);
                    return ActionResult.SUCCESS;
                } else {
                    player.sendMessage(Text.literal("Naomi: This flower is beautiful."), true);
                    return ActionResult.SUCCESS;
                }
            } else if (stack.getItem() == Items.PAPER) {
                if (player.getName().getString().toLowerCase().contains("snowielove1")) {
                    player.sendMessage(Text.literal(getRandomReply("paper_replies")), true);
                    return ActionResult.SUCCESS;
                }
            } else if (stack.getItem() == Items.STICK && isZappy) {
                isZappy = false;
                isInBox = true;
                this.setCurrentHand(Hand.MAIN_HAND);
                this.dropItem(this.getStackInHand(Hand.MAIN_HAND));
                this.setStackInHand(Hand.MAIN_HAND, stack);
                player.sendMessage(Text.literal("Naomi: I need to be alone for a while."), true);
                buildBoxAround();
                switchToZappyTexture();
                this.lastZappyTime = this.world.getTime();
                return ActionResult.SUCCESS;
            }
        } else if (this.getCustomName().asString().equals("Naomi_X")) {
            player.sendMessage(Text.literal("Naomi: *moans*"), true);
            return ActionResult.SUCCESS;
        }

        if (stack.isEmpty() && player.getName().getString().toLowerCase().contains("snowielove1")) {
            if (isZappy) {
                rightClickCount++;
                handleRightClickInteraction(player, "right_click");


} else {
            player.sendMessage(Text.literal("Naomi: I'm not in the mood."), true);
        }
        return ActionResult.SUCCESS;
    }

    return super.interactMob(player, hand);
}

@Override
public void tickMovement() {
    super.tickMovement();

    if (this.world.isClient) {
        return;
    }

    long worldTime = this.world.getTime();
    if (!isZappy && worldTime - lastZappyTime > 96000) { // Approximately 8 Minecraft days
        isZappy = true;
        this.sendMessage(Text.literal("Naomi: I'm feeling zappy, I need a stick."), true);
    }

    if (isInBox && worldTime - lastZappyTime > 180) {
        this.breakBox();
        isInBox = false;
    }

    if (isNearDarkGreenBed()) {
        sleepInBed();
    }

    if (isOnCheckerboardFloor()) {
        dance();
    }

    if (isInColdBiome() && !isWearingLeatherArmor()) {
        this.sendMessage(Text.literal("Naomi: I'm cold, can I have leather armor? (yes/no)"), true);
    }

    // Handle chat detection for bonemeal and zappy state
    if (isPlayerMessage("can you grow") || isPlayerMessage("can you bonemeal")) {
        applyBonemealToNearbyPlants();
    }

    if (isPlayerMessage("I love you")) {
        lastZappyTime -= 12000; // Speed up zappy state by half a day
        this.sendMessage(Text.literal(getRandomReply("romantic_replies")), true);
    }

    if (isPlayerMessage("stop dancing")) {
        this.goalSelector.remove(10); // Remove dance goal
        this.sendMessage(Text.literal(getRandomReply("dancing_replies")), true);
    }

    if (isPlayerMessage("will you dance with me")) {
        this.goalSelector.add(10, new DanceGoal(this)); // Add dance goal
        this.sendMessage(Text.literal("Naomi: I would love to dance with you!"), true);
    }

    if (isPlayerMessage("strip")) {
        if (this.isZappy && this.getCustomName().getString().equals("Naomi_X")) {
            this.dropInventory();
            this.sendMessage(Text.literal("Naomi: Ughh fine. You win..."), true);
            this.lastZappyTime -= 48000; // Make her more zappy by 2 days
        } else if (player.getName().getString().toLowerCase().contains("snowielove1")) {
            this.setCustomName(new TranslatableText("Naomi_Blushing"));
            this.dropInventory();
            this.lastZappyTime -= 48000; // Make her more zappy by 2 days
            this.sendMessage(Text.literal("Naomi: Fully? You're not that lucky."), true);
        }
    }

    if (isPlayerMessage("yes")) {
        this.equipLeatherArmor();
        this.sendMessage(Text.literal("Naomi: I made this for you 3 days ago... to be honest I made it for me just never ate it."), true);
        this.dropStack(new ItemStack(Items.PUMPKIN_PIE));
    } else if (isPlayerMessage("no")) {
        this.sendMessage(Text.literal("Naomi: I'm not important enough?"), true);
    }

    if (this.isZappy && this.isSleeping()) {
        this.blinkingTexture();
    }
}

private void handleRightClickInteraction(PlayerEntity player, String interactionType) {
    long currentTime = this.world.getTime();
    long timeDifference = currentTime - lastInteractionTime;
    lastInteractionTime = currentTime;

    if (timeDifference < 10) { // Assuming 20 ticks per second
        player.sendMessage(Text.literal(this.getName().getString() + ": *screams*"), true);
    } else if (timeDifference < 20) {
        player.sendMessage(Text.literal(this.getName().getString() + ": *pants*"), true);
    } else {
        player.sendMessage(Text.literal(this.getName().getString() + ": *moans*"), true);
    }

    if (interactionType.equals("right_click") && rightClickCount >= 30) {
        this.dropInventory();
        this.switchToNormalTexture();
        rightClickCount = 0;
        player.sendMessage(Text.literal("Naomi: I feel better now."), true);
    }
}

private boolean isNearDarkGreenBed() {
    BlockPos pos = this.getBlockPos();
    for (int x = -1; x <= 1; x++) {
        for (int y = 0; y <= 1; y++) {
            for (int z = -1; z <= 1; z++) {
                BlockPos newPos = pos.add(x, y, z);
                if (this.world.getBlockState(newPos).getBlock() == Blocks.GREEN_BED) {
                    return true;
                }
            }
        }
    }
    return false;
}

private void sleepInBed() {
    BlockPos pos = this.getBlockPos();
    BlockPos bedPos = pos.add(0, 0, -1);
    if (this.world.getBlockState(bedPos).getBlock() instanceof BedBlock) {
        this.getNavigation().startMovingTo(bedPos.getX(), bedPos.getY(), bedPos.getZ(), 1.0);
        this.setSleeping(true);
        this.sleepInBedAt(bedPos);
    }
}

private boolean isOnCheckerboardFloor() {
    BlockPos pos = this.getBlockPos();
    for (int x = -1; x <= 1; x++) {
        for (int z = -1; z <= 1; z++) {
            BlockPos newPos = pos.add(x, 0, z);
            if (!this.world.getBlockState(newPos).isOf(Blocks.IRON_BLOCK) &&
                !this.world.getBlockState(newPos).isOf(Blocks.DIAMOND_BLOCK)) {
                return false;
            }
        }
    }
    return true;
}

private void dance() {
    if (this.isSneaking()) {
        this.setSneaking(false);
    } else {
        this.setSneaking(true);
    }
}

private boolean isInColdBiome() {
    Biome biome = this.world.getBiome(this.getBlockPos());
    return biome.getTemperature(this.getBlockPos()) < 0.15F;
}

private boolean isWearingLeatherArmor() {
    for (ItemStack itemStack : this.getArmorItems()) {
        if (!(itemStack.getItem() instanceof ArmorItem) || ((ArmorItem) itemStack.getItem()).getMaterial() != ArmorMaterials.LEATHER) {
            return false;
        }
    }
    return true;
}

private void shakeInCold() {
    if (this.isInColdBiome() && !this.isWearingLeatherArmor()) {
        this.setShaking(true);
    } else {
        this.setShaking(false);
    }
}

private void setShaking(boolean shaking) {
    if (shaking) {
        this.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 20, 1, true, false, true));
    } else {
        this.removeStatusEffect(StatusEffects.SLOWNESS);
    }
}

private void equipLeatherArmor() {
    this.equipStack(EquipmentSlot.HEAD, new ItemStack(Items.LEATHER_HELMET));
    this.equipStack(EquipmentSlot.CHEST, new ItemStack(Items.LEATHER_CHESTPLATE));
    this.equipStack(EquipmentSlot.LEGS, new ItemStack(Items.LEATHER_LEGGINGS));
    this.equipStack(EquipmentSlot.FEET, new ItemStack(Items.LEATHER_BOOTS));
}

private void blinkingTexture() {
    long worldTime = this.world.getTime();
    if (worldTime % 50 == 0) {
        this.setCustomName(new TranslatableText("Naomi_Blushing"));
    } else if (worldTime % 50 == 25) {
        this.setCustomName(new TranslatableText("Naomi_X"));
    }
}

private void applyBonemealToNearbyPlants() {
    BlockPos pos = this.getBlockPos();
    for (BlockPos targetPos : BlockPos.iterate(pos.add(-10, -1, -10), pos.add(10, 1, 10))) {
        if (this.world.getBlockState(targetPos).getBlock() instanceof Fertilizable) {
            Fertilizable fertilizable = (Fertilizable) this.world.getBlockState(targetPos).getBlock();
            if (fertilizable.isFertilizable(this.world, targetPos, this.world.getBlockState(targetPos), this.world.isClient)) {
                fertilizable.grow(this.world, this.world.random, targetPos, this.world.getBlockState(targetPos));
            }
        }
    }
}

private String getRandomReply(String category) {
    List<String> categoryReplies = replies.get(category);
    return categoryReplies.get(new Random().nextInt(categoryReplies.size()));
}

// Chat event handling logic
private boolean isPlayerMessage(String keyword) {
    if (this.getWorld().getPlayers().isEmpty()) {
        return false;
    }
    for (PlayerEntity player : this.getWorld().getPlayers()) {
        if (player.getDisplayName().getString().toLowerCase().contains(keyword.toLowerCase())) {
            return true;
        }
    }
    return false;
}

private void standInFrontOfPlayer(PlayerEntity player) {
    BlockPos playerPos = player.getBlockPos();
        this.setPosition(playerPos.getX(), playerPos.getY(), playerPos.getZ() - 1);
    }

    private void startDancing() {
        this.goalSelector.add(10, new DanceGoal(this));
    }

    // Custom close door goal
    static class CloseDoorGoal extends net.minecraft.entity.ai.goal.CloseDoorGoal {
        public CloseDoorGoal(MobEntity mob, boolean forgetOpen) {
            super(mob, forgetOpen);
        }

        @Override
        public void tick() {
            super.tick();
            if (this.mob.getNavigation().getCurrentPath() == null) {
                this.door.setOpen(false);
            }
        }
    }

    // Register event handlers
    public static void register() {
        FabricDefaultAttributeRegistry.register(NAOMI_ENTITY, NaomiEntity.createMobAttributes());
        EntityRendererRegistry.INSTANCE.register(NAOMI_ENTITY, (dispatcher, context) -> new NaomiEntityRenderer(dispatcher));
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            server.getPlayerManager().broadcast(Text.literal("Naomi has joined the game."), false);
        });
        ServerTickEvents.START_SERVER_TICK.register(server -> {
            server.getPlayerManager().getPlayerList().forEach(player -> {
                // Add logic here for player interactions
            });
        });
    }

    @Environment(EnvType.CLIENT)
    public static class NaomiEntityRenderer extends BipedEntityRenderer<NaomiEntity, BipedEntityModel<NaomiEntity>> {
        private static final Identifier NAOMI_TEXTURE = new Identifier("sinisterxmas", "textures/entity/girls/naomi.png");
        private static final Identifier NAOMI_X_TEXTURE = new Identifier("sinisterxmas", "textures/entity/girls/naomi_x.png");
        private static final Identifier NAOMI_BLUSHING_TEXTURE = new Identifier("sinisterxmas", "textures/entity/girls/naomi_blushing.png");
        private static final Identifier NAOMI_BLINKING_TEXTURE = new Identifier("sinisterxmas", "textures/entity/girls/naomi_blinking.png");
        private static final Identifier NAOMI_X_BLINKING_TEXTURE = new Identifier("sinisterxmas", "textures/entity/girls/naomi_x_blinking.png");

        public NaomiEntityRenderer(EntityRendererFactory.Context context) {
            super(context, new BipedEntityModel<>(context.getPart(EntityModelLayer.create("naomi", "main"))), 0.5f);
        }

        @Override
        public Identifier getTexture(NaomiEntity entity) {
            if (entity.getCustomName() != null) {
                String customName = entity.getCustomName().asString();
                if (customName.equals("Naomi_X")) {
                    return shouldBlink(entity) ? NAOMI_X_BLINKING_TEXTURE : NAOMI_X_TEXTURE;
                } else if (customName.equals("Naomi_Blushing")) {
                    return NAOMI_BLUSHING_TEXTURE;
                }
            }
            return shouldBlink(entity) ? NAOMI_BLINKING_TEXTURE : NAOMI_TEXTURE;
        }

        private boolean shouldBlink(NaomiEntity entity) {
            long currentTime = entity.world.getTime();
            return (currentTime / 10) % 5 == 0;  // Blinks every 2.5 seconds
        }

@Environment(EnvType.CLIENT)
public static EntityRendererFactory<NaomiEntity> createRenderer() {
    return (context) -> new NaomiEntityRenderer(context);
}

        @Override
        public void render(NaomiEntity entity, float yaw, float tickDelta, MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light) {
            super.render(entity, yaw, tickDelta, matrices, vertexConsumers, light);
            if (entity.getCustomName() != null && entity.getCustomName().asString().equals("Naomi_X")) {
                float alpha = 0.3f + 0.6f * ((float) Math.sin(entity.world.getTime() * 0.1) * 0.5f + 0.5f);
                this.getModel().render(matrices, vertexConsumers.getBuffer(this.getModel().getLayer(this.getTexture(entity))), light, OverlayTexture.DEFAULT_UV, 1.0f, 1.0f, 1.0f, alpha);
            }
        }
    }

    class GetZappyGoal extends Goal {
        private final NaomiEntity naomi;

        public GetZappyGoal(NaomiEntity naomi) {
            this.naomi = naomi;
        }

        @Override
        public boolean canStart() {
            return !naomi.isZappy && naomi.world.getTime() - naomi.lastZappyTime > 96000;
        }

        @Override
        public void start() {
            naomi.isZappy = true;
            naomi.sendMessage(Text.literal("Naomi: I'm feeling zappy, I need a stick."), true);
        }
    }

    class DanceGoal extends Goal {
        private final NaomiEntity naomi;
        private int danceTick = 0;

        public DanceGoal(NaomiEntity naomi) {
            this.naomi = naomi;
        }

        @Override
        public boolean canStart() {
            return true; // Always allow dancing when the goal is active
        }

        @Override
        public void tick() {
            if (danceTick % 5 == 0) { // Switch stance every 5 ticks (0.25 seconds)
                if (naomi.isSneaking()) {
                    naomi.setSneaking(false);
                } else {
                    naomi.setSneaking(true);
                }
            }
            danceTick++;
        }
    }

    class TeacherAIGoal extends Goal {
        private final NaomiEntity naomi;
        private int teacherTick = 0;

        public TeacherAIGoal(NaomiEntity naomi) {
            this.naomi = naomi;
        }

        @Override
        public boolean canStart() {
            return true; // Always allow teaching when the goal is active
        }

        @Override
        public void tick() {
            if (teacherTick % 3600 == 0) { // Every 3 minutes
                Entity nearestEntity = findNearestEntity();
                if (nearestEntity != null) {
                    naomi.sendMessage(Text.literal("Naomi: Follow me, I found something interesting!"), true);
                    naomi.getNavigation().startMovingTo(nearestEntity, 1.0);
                    naomi.sendMessage(Text.literal(getRandomFactForEntity(nearestEntity)), true);
                }
            }
            teacherTick++;
        }

        private Entity findNearestEntity() {
            // Implement logic to find the nearest entity
            return null; // Placeholder implementation
        }

        private String getRandomFactForEntity(Entity entity) {
            // Implement logic to get a random fact for the given entity
            return "Naomi: This is a placeholder fact.";
        }
    }
}
