package com.example.sinisterxmas.entity;

import com.example.sinisterxmas.entity.renderer.AnomalyRenderer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.rendereregistry.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.entity.FabricEntityTypeBuilder;
import net.minecraft.block.Blocks;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.Packet;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.state.property.Properties;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.registry.Registry;
import net.minecraft.world.World;

public class AnomalyEntity extends Entity {
    public enum AnomalyType {
        GOOD, NEUTRAL, EVIL, FLUX, TAINT, ENDER, WITHER, SKULK
    }

    public enum AnomalyRenderType {
        PORTAL_RENDER, FIRE_RENDER, SOUL_FIRE_RENDER, ITEM_RENDER, SLIME_RENDER, INVISIBLE
    }

    private AnomalyType type;
    private AnomalyRenderType renderType;
    private float activationRange;
    public static Item renderItem;

    public static Boolean anomalyHasToBeInsideBlock() {
        return true;
    }

    public static final EntityType<AnomalyEntity> ANOMALY = Registry.register(
            Registry.ENTITY_TYPE,
            new Identifier("sinisterxmas", "anomaly"),
            FabricEntityTypeBuilder.create(SpawnGroup.MISC, AnomalyEntity::new)
                    .dimensions(EntityDimensions.fixed(0.5f, 0.5f))
                    .build()
    );

    static {
        // Auto-register entity renderer
        EntityRendererRegistry.INSTANCE.register(AnomalyEntity.ANOMALY, (context) -> new AnomalyRenderer(context));
    }

    public AnomalyEntity(EntityType<?> type, World world) {
        super(type, world);
    }

    public void setActivationRange(float range) {
        this.activationRange = range;
    }

    public void setRenderType(AnomalyRenderType renderType) {
        this.renderType = renderType;
    }

    public static void setRenderItem(Item item) {
        renderItem = item;
    }

    public static void effects(World world, BlockPos pos) {
        PlayerEntity closestPlayer = world.getClosestPlayer(pos.getX(), pos.getY(), pos.getZ(), 10, false);

        // Implement your effect logic here, using closestPlayer if needed
    }

    @Override
    public void tick() {
        super.tick();

        if (!world.isClient && anomalyHasToBeInsideBlock()) {
            BlockPos pos = this.getBlockPos();
            if (world.isAir(pos)) {
                this.remove(RemovalReason.KILLED);
            }
        }

        if (!world.isClient) {
            effects(world, this.getBlockPos());
        }
    }

    @Environment(EnvType.CLIENT)
    private AnomalyRenderType renderAnomaly() {
        return renderType;
    }

    public static AnomalyEntity spawnAt(World world, BlockPos pos, AnomalyType type, AnomalyRenderType renderType, float range) {
        AnomalyEntity anomaly = new AnomalyEntity(ANOMALY, world);
        anomaly.setPosition(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5);
        anomaly.setType(type);
        anomaly.setRenderType(renderType);
        anomaly.setActivationRange(range);
        world.spawnEntity(anomaly);
        return anomaly;
    }

    public static AnomalyEntity spawnAt(World world, double x, double y, double z, AnomalyType type, AnomalyRenderType renderType, float range) {
        AnomalyEntity anomaly = new AnomalyEntity(ANOMALY, world);
        anomaly.setPosition(x, y, z);
        anomaly.setType(type);
        anomaly.setRenderType(renderType);
        anomaly.setActivationRange(range);
        world.spawnEntity(anomaly);
        return anomaly;
    }

    @Override
    protected void initDataTracker() {
    }

    @Override
    protected void readCustomDataFromNbt(NbtCompound nbt) {
        this.renderType = AnomalyRenderType.valueOf(nbt.getString("RenderType"));
        this.type = AnomalyType.valueOf(nbt.getString("Type"));
        this.activationRange = nbt.getFloat("ActivationRange");
    }

    @Override
    protected void writeCustomDataToNbt(NbtCompound nbt) {
        nbt.putString("RenderType", renderType.name());
        nbt.putString("Type", type.name());
        nbt.putFloat("ActivationRange", activationRange);
    }

    @Override
    public Packet<?> createSpawnPacket() {
        return EntitySpawnPacket.create(this, ANOMALY);
    }

    public void setType(AnomalyType type) {
        this.type = type;
    }

    public AnomalyType getType() {
        return type;
    }
}