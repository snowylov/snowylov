package com.example.sinisterxmas.entity;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.rendereregistry.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.passive.CowEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.registry.Registry;
import net.minecraft.world.World;

import java.util.List;

public class CannibalCowAnomaly extends AnomalyEntity {
    private CowEntity attachedCow;

    public static final EntityType<CannibalCowAnomaly> CANNIBAL_COW_ANOMALY = Registry.register(
            Registry.ENTITY_TYPE,
            new Identifier("sinisterxmas", "cannibal_cow_anomaly"),
            FabricEntityTypeBuilder.create(SpawnGroup.MISC, CannibalCowAnomaly::new)
                    .dimensions(EntityDimensions.fixed(0.5f, 0.5f))
                    .build()
    );

    static {
        // Auto-register entity renderer
        EntityRendererRegistry.INSTANCE.register(CannibalCowAnomaly.CANNIBAL_COW_ANOMALY, (context) -> new AnomalyRenderer(context) {
            @Override
            public ItemStack getRenderStack() {
                return new ItemStack(Items.BEEF);
            }
        });
    }

    public CannibalCowAnomaly(EntityType<?> type, World world) {
        super(type, world);
        setRenderType(AnomalyRenderType.ITEM_RENDER);
        setRenderItem(Items.BEEF);
    }

    public void attachToCow(CowEntity cow) {
        this.attachedCow = cow;
    }

    @Override
    public void tick() {
        super.tick();

        if (!world.isClient) {
            if (attachedCow != null && attachedCow.isAlive()) {
                // Make a random cow aggressive to other cows every minute
                long gameTime = world.getTime();
                if (gameTime % 1200 == 0) { // 1200 ticks = 1 minute
                    List<CowEntity> cows = world.getEntitiesByClass(CowEntity.class, attachedCow.getBoundingBox().expand(80), cow -> cow != attachedCow);
                    if (!cows.isEmpty()) {
                        CowEntity target = cows.get(world.random.nextInt(cows.size()));
                        target.setAttacking(attachedCow);
                        target.setMovementSpeed(0.3F); // Sprinting player speed
                    }
                }
            } else {
                this.remove(RemovalReason.KILLED);
            }
        }
    }
}