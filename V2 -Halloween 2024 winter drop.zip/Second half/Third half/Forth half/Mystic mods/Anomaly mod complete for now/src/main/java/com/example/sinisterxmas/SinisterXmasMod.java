
package com.example.sinisterxmas;

import com.example.sinisterxmas.item.HaydayAnomalyPlacer;
import com.example.sinisterxmas.item.SkulkusAnomalyPlacer;
import com.example.sinisterxmas.item.FreshRawBeef;
import com.example.sinisterxmas.item.AnomalyDetector;
import net.fabricmc.api.ModInitializer;

public class SinisterXmasMod implements ModInitializer {
  
  public static final Item SUBSPACE_AMMO_LINK = new IngredientItem(new Item.Settings(), "subspace_ammo_link");
    public static final Item GLASS_NEEDLE_FIRING_TUBE = new IngredientItem(new Item.Settings(), "glass_needle_firing_tube");
    public static final Item TRIGGER_MECHANISM = new IngredientItem(new Item.Settings(), "trigger_mechanism");
    public static final Item SUBSPACE_MAGAZINE_HANDLE = new IngredientItem(new Item.Settings(), "subspace_magazine_handle");
    
    @Override
    public void onInitialize() {
        // Initialize the items
        new HaydayAnomalyPlacer(new Item.Settings().maxCount(1));
        new SkulkusAnomalyPlacer(new Item.Settings().maxCount(1));
        new FreshRawBeef(new Item.Settings().maxCount(1));
        new AnomalyDetector(new Item.Settings().maxCount(1));
        new WeedKiller(new Item.Settings());
        NeedleItem.NEEDLE.register();
        NeedleGun.NEEDLE_GUN.register();
        NeedleProjectile.register();
        new IngredientItem(new Item.Settings().maxCount(64), "micro_nether_reactor");
        new IngredientItem(new Item.Settings().maxCount(64), "heat_resistant_tubing");
        new IngredientItem(new Item.Settings().maxCount(64), "intense_heat_output_device");
        new FlamethrowerItem(new Item.Settings().maxCount(1));
        HealingOakSapling.registerAll();
        HealingTreeAnomaly.register();
        // Call the method to register Specimen31
        Specimen31EntityRegistration.registerSpecimen31();
        EntityRendererRegistry.register(NaomiEntity.NAOMI_ENTITY, NaomiEntity::createRenderer);
        
    }
}