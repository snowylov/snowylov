package com.example.sinisterxmas.item;

import com.example.sinisterxmas.entity.CannibalCowAnomaly;
import net.fabricmc.api.ModInitializer;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.item.ItemStack;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.text.TranslatableText;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;

import java.util.List;

public class FreshRawBeef extends Item {

    public static final FreshRawBeef FRESH_RAW_BEEF = new FreshRawBeef(new Item.Settings().maxCount(1));

    public FreshRawBeef(Settings settings) {
        super(settings);
        Registry.register(Registry.ITEM, new Identifier("sinisterxmas", "fresh_raw_beef"), this);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        return new TypedActionResult<>(ActionResult.SUCCESS, user.getStackInHand(hand));
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext context) {
        World world = context.getWorld();
        BlockPos pos = context.getBlockPos();
        if (!world.isClient && (world.getBlockState(pos).getBlock() == Blocks.GRASS_BLOCK || world.getBlockState(pos).getBlock() == Blocks.DIRT)) {
            BlockPos spawnPos = pos.up();
            CannibalCowAnomaly anomaly = new CannibalCowAnomaly(CannibalCowAnomaly.CANNIBAL_COW_ANOMALY, world);
            anomaly.setPosition(spawnPos.getX() + 0.5, spawnPos.getY(), spawnPos.getZ() + 0.5);
            world.spawnEntity(anomaly);
            context.getStack().decrement(1);
            world.playSound(null, spawnPos, SoundEvents.ENTITY_COW_AMBIENT, SoundCategory.BLOCKS, 1.0F, 1.0F);
            return ActionResult.SUCCESS;
        }
        return ActionResult.FAIL;
    }

    @Override
    public void appendTooltip(ItemStack stack, World world, List<Text> tooltip, TooltipContext context) {
        super.appendTooltip(stack, world, tooltip, context);
        if (Screen.hasShiftDown()) {
            tooltip.add(new TranslatableText("item.sinisterxmas.fresh_raw_beef.tooltip.shift").formatted(Formatting.YELLOW));
        } else {
            tooltip.add(new TranslatableText("item.sinisterxmas.fresh_raw_beef.tooltip").formatted(Formatting.GRAY));
        }
    }
}