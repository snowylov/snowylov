package com.example.sinisterxmas.client;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;

@Environment(EnvType.CLIENT)
public class FluxRenderer {
    private static final Identifier TEXTURE = new Identifier("textures/block/vine.png");

    public static void renderOverlay(float transparency) {
        MinecraftClient client = MinecraftClient.getInstance();
        MatrixStack matrixStack = new MatrixStack();
        matrixStack.push();
        matrixStack.translate(0, 0, -90);
        matrixStack.scale(1.0f, 1.0f, 1.0f);

        client.getTextureManager().bindTexture(TEXTURE);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.color4f(0.5F, 0.0F, 0.5F, transparency); // Purple color

        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder bufferBuilder = tessellator.getBuffer();
        bufferBuilder.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE);
        bufferBuilder.vertex(matrixStack.peek().getModel(), -1.0F, -1.0F, -0.5F).texture(0.0F, 0.0F).next();
        bufferBuilder.vertex(matrixStack.peek().getModel(), 1.0F, -1.0F, -0.5F).texture(1.0F, 0.0F).next();
        bufferBuilder.vertex(matrixStack.peek().getModel(), 1.0F, 1.0F, -0.5F).texture(1.0F, 1.0F).next();
        bufferBuilder.vertex(matrixStack.peek().getModel(), -1.0F, 1.0F, -0.5F).texture(0.0F, 1.0F).next();
        tessellator.draw();

        RenderSystem.disableBlend();
        matrixStack.pop();
    }
}