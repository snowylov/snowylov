package com.example.sinisterxmas.item;

import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.entity.FabricEntityTypeBuilder;
import net.minecraft.client.render.entity.EmptyEntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.model.json.ModelTransformation;
import net.minecraft.client.util.math.Vector3f;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.registry.Registry;
import net.minecraft.world.World;

import java.util.HashMap;
import java.util.Map;

public class FlamethrowerItem extends Item {
    public static final EntityType<FlamethrowerProjectile> FLAMETHROWER_PROJECTILE = Registry.register(
            Registry.ENTITY_TYPE,
            new Identifier("sinisterxmas", "flamethrower_projectile"),
            FabricEntityTypeBuilder.create(SpawnGroup.MISC, FlamethrowerProjectile::new)
                    .dimensions(EntityDimensions.fixed(0.5f, 0.5f))
                    .trackable(128, 3)
                    .build()
    );

    private static final Map<PlayerEntity, Boolean> activeFlamethrowers = new HashMap<>();
    private static final Map<PlayerEntity, Integer> activeTimers = new HashMap<>();

    public FlamethrowerItem(Settings settings) {
        super(settings);
        Registry.register(Registry.ITEM, new Identifier("sinisterxmas", "flamethrower"), this);
        EntityRendererRegistry.register(FLAMETHROWER_PROJECTILE, FlamethrowerProjectileRenderer::new);
    }

    @Override
    public ActionResult use(World world, PlayerEntity player, Hand hand) {
        if (!world.isClient) {
            boolean isActive = activeFlamethrowers.getOrDefault(player, false);
            if (player.getItemCooldownManager().isCoolingDown(this)) {
                player.sendMessage(Text.literal("Flamethrower is cooling down!"), true);
                return ActionResult.FAIL;
            }
            activeFlamethrowers.put(player, !isActive);
            if (!isActive) {
                world.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.ITEM_FLINTANDSTEEL_USE, SoundCategory.PLAYERS, 1.0F, 1.0F);
                activeTimers.put(player, 0);
            }
        }
        return ActionResult.SUCCESS;
    }

    @Override
    public void inventoryTick(ItemStack stack, World world, PlayerEntity player, int slot, boolean selected) {
        if (world.isClient || !selected || !activeFlamethrowers.getOrDefault(player, false)) {
            return;
        }

        int timer = activeTimers.getOrDefault(player, 0);
        if (timer >= 25 * 20) { // 25 seconds in ticks
            player.sendMessage(Text.literal("Flamethrower overheated! Cooling down for 5 seconds."), true);
            player.getItemCooldownManager().set(this, 100); // 5 seconds cooldown
            activeFlamethrowers.put(player, false);
            return;
        }

        activeTimers.put(player, timer + 1);

        FlamethrowerProjectile projectile = new FlamethrowerProjectile(FLAMETHROWER_PROJECTILE, world, player.isSneaking() ? 150 : 300);
        projectile.setOwner(player);
        projectile.setPosition(player.getX(), player.getEyeY() - 0.1, player.getZ());
        projectile.setVelocity(player, player.getPitch(), player.getYaw(), 0.0F, 3.0F, 1.0F);
        world.spawnEntity(projectile);
        world.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.BLOCK_FIRE_AMBIENT, SoundCategory.PLAYERS, 1.0F, 1.0F);
    }

    public static class FlamethrowerProjectile extends PersistentProjectileEntity {
        private final int projectilesPerSecond;

        public FlamethrowerProjectile(EntityType<? extends PersistentProjectileEntity> entityType, World world, int projectilesPerSecond) {
            super(entityType, world);
            this.projectilesPerSecond = projectilesPerSecond;
        }

        @Override
        public void tick() {
            super.tick();
            if (this.age >= 20) {
                this.remove(RemovalReason.KILLED);
                return;
            }

            Vec3d position = this.getPos();
            Vec3d direction = this.getVelocity().normalize();
            double maxDistance = 16.0;

            for (int i = 0; i < projectilesPerSecond / 20; ++i) {
                double distance = i * (maxDistance / (projectilesPerSecond / 20.0));
                double width = calculateWidth(distance);

                Vec3d offset = new Vec3d(
                        (random.nextDouble() - 0.5) * width,
                        (random.nextDouble() - 0.5) * width,
                        (random.nextDouble() - 0.5) * width
                );

                Vec3d particlePos = position.add(direction.multiply(distance)).add(offset);
                this.world.addParticle(ParticleTypes.FLAME, particlePos.x, particlePos.y, particlePos.z, 0.0, 0.0, 0.0);

                BlockPos blockPos = new BlockPos(particlePos);
                if (this.world.getBlockState(blockPos).isAir() && this.world.getBlockState(blockPos.down()).isSolidBlock(this.world, blockPos.down())) {
                    this.world.setBlockState(blockPos, Blocks.FIRE.getDefaultState());
                } else if (this.world.getBlockState(blockPos).isFlammable(this.world, blockPos, null)) {
                    this.world.setBlockState(blockPos, Blocks.FIRE.getDefaultState());
                }

                this.world.getOtherEntities(this, this.getBoundingBox().expand(width), entity -> !entity.equals(this.getOwner())).forEach(entity -> {
                    entity.setOnFireFor(5);
                });
            }
        }

        private double calculateWidth(double distance) {
            if (distance <= 1) {
                return 1;
            } else if (distance <= 4) {
                return 3;
            } else if (distance <= 7) {
                return 6;
            } else if (distance <= 10) {
                return 8;
            } else {
                return 12;
            }
        }

        @Override
        protected ItemStack asItemStack() {
            return ItemStack.EMPTY;
        }

        @Override
        public void readCustomDataFromNbt(NbtCompound nbt) {
            super.readCustomDataFromNbt(nbt);
        }

        @Override
        public void writeCustomDataToNbt(NbtCompound nbt) {
            super.writeCustomDataToNbt(nbt);
        }
    }

    public static class FlamethrowerProjectileRenderer extends EntityRenderer<FlamethrowerProjectile> {
        public FlamethrowerProjectileRenderer(EntityRendererFactory.Context context) {
            super(context);
        }

        @Override
        public void render(FlamethrowerProjectile entity, float yaw, float tickDelta, MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light) {
            matrices.push();

            // Position the fire block in the world
            matrices.translate(0.0, 0.5, 0.0);

            // Rotate the fire block to align with the projectile direction
            matrices.multiply(Vector3f.POSITIVE_Y.getDegreesQuaternion(MathHelper.lerp(tickDelta, entity.prevYaw, entity.yaw) - 90.0F));
            matrices.multiply(Vector3f.POSITIVE_Z.getDegreesQuaternion(MathHelper.lerp(tickDelta, entity.prevPitch, entity.pitch) - 45.0F));

            // Render the fire block
            float scale = 0.5F;
            matrices.scale(scale, scale, scale);
            this.renderModel(entity, tickDelta, matrices, vertexConsumers, light);

            matrices.pop();
            super.render(entity, yaw, tickDelta, matrices, vertexConsumers, light);
        }

        private void renderModel(FlamethrowerProjectile entity, float tickDelta, MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light) {
            ItemStack fireItemStack = new ItemStack(Blocks.FIRE.asItem());
            this.dispatcher.getHeldItemRenderer().renderItem(fireItemStack, ModelTransformation.Mode.NONE, light, 0, matrices, vertexConsumers, entity.world, 0);
        }

        @Override
        public Identifier getTexture(FlamethrowerProjectile entity) {
            return new Identifier("sinisterxmas", "textures/entity/fire.png");
        }
    }
}