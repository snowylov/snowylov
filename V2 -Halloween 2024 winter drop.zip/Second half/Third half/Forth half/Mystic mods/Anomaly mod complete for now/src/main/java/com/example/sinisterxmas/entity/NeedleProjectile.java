package com.example.sinisterxmas.entity.needle;

import com.example.sinisterxmas.entity.TaintAnomaly;
import com.example.sinisterxmas.entity.TwilightAnomaly;
import net.fabricmc.fabric.api.client.rendereregistry.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.entity.FabricEntityTypeBuilder;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.registry.Registry;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.world.World;

public class NeedleProjectile extends PersistentProjectileEntity {
    public static final EntityType<NeedleProjectile> NEEDLE_ENTITY = Registry.register(
            Registry.ENTITY_TYPE,
            new Identifier("sinisterxmas", "needle_entity"),
            FabricEntityTypeBuilder.create(SpawnGroup.MISC, NeedleProjectile::new)
                    .dimensions(EntityDimensions.fixed(0.5f, 0.5f))
                    .trackable(128, 3)
                    .build()
    );

    private String needleType;

    public NeedleProjectile(EntityType<? extends PersistentProjectileEntity> entityType, World world) {
        super(entityType, world);
    }

    public static NeedleProjectile createNeedle(World world, ItemStack needleStack) {
        NeedleProjectile needle = new NeedleProjectile(NEEDLE_ENTITY, world);
        NbtCompound nbt = needleStack.getOrCreateNbt();
        needle.needleType = nbt.getString("NeedleType");
        return needle;
    }

    @Override
    protected void onHit(HitResult hitResult) {
        super.onHit(hitResult);
        this.setVelocity(0, 0, 0);
        this.inGround = true;
    }

    @Override
    protected void onHitEntity(EntityHitResult entityHitResult) {
        super.onHitEntity(entityHitResult);

        if (entityHitResult.getEntity() instanceof PlayerEntity player) {
            switch (needleType) {
                case "taint":
                    TaintAnomaly taintAnomaly = new TaintAnomaly(TaintAnomaly.TAINT_ANOMALY, world);
                    taintAnomaly.attachToPlayer(player);
                    world.spawnEntity(taintAnomaly);
                    break;
                case "twilight":
                    TwilightAnomaly twilightAnomaly = new TwilightAnomaly(TwilightAnomaly.TWILIGHT_ANOMALY, world);
                    twilightAnomaly.attachToPlayer(player);
                    world.spawnEntity(twilightAnomaly);
                    break;
                case "standard":
                    player.damage(DamageSource.GENERIC, 0.5F);
                    break;
                case "life_drain":
                    player.damage(DamageSource.GENERIC, 0.5F);
                    if (getOwner() instanceof PlayerEntity) {
                        ((PlayerEntity) getOwner()).heal(0.5F);
                    }
                    break;
                case "wither":
                    player.addStatusEffect(new StatusEffectInstance(StatusEffects.WITHER, 300, 1));
                    break;
                case "poison":
                    player.addStatusEffect(new StatusEffectInstance(StatusEffects.POISON, 400, 2));
                    break;
                case "healing":
                    player.heal(10.0F);
                    break;
                case "deadly":
                    player.damage(DamageSource.GENERIC, 3.5F);
                    break;
            }
        }
        this.setVelocity(0, 0, 0);
        this.inGround = true;
    }

    @Override
    public void tick() {
        super.tick();

        if (this.inGround) {
            if (this.age >= 2400) { // 2 minutes in ticks
                this.remove(RemovalReason.KILLED);
            } else if (this.distanceTraveled > 500) {
                this.remove(RemovalReason.KILLED);
            }
        } else if (this.distanceTraveled > 1000) {
            this.remove(RemovalReason.KILLED);
        }
    }

    @Override
    protected ItemStack asItemStack() {
        return new ItemStack(NeedleItem.STANDARD_NEEDLE);
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        this.needleType = nbt.getString("NeedleType");
    }

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putString("NeedleType", this.needleType);
    }

    @Override
    public boolean hasNoGravity() {
        return true;
    }

    @Override
    public void setVelocity(double x, double y, double z, float speed, float divergence) {
        Vec3d velocity = new Vec3d(x, y, z).normalize().multiply(speed);
        this.setVelocity(velocity.x, velocity.y, velocity.z);
    }

    @Override
    public void setVelocity(Entity shooter, float pitch, float yaw, float roll, float speed, float divergence) {
        super.setVelocity(shooter, pitch, yaw, roll, speed * 3.0F, 0.0F);  // Speed increased and no divergence for perfect accuracy
    }

    public static void register() {
        EntityRendererRegistry.register(NEEDLE_ENTITY, NeedleEntityRenderer::new);
    }

    public static class NeedleEntityRenderer extends EntityRenderer<NeedleProjectile> {
        public NeedleEntityRenderer(EntityRendererFactory.Context context) {
            super(context);
        }

        @Override
        public void render(NeedleProjectile entity, float yaw, float tickDelta, MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light) {
            matrices.push();

            // Position the needle in the world
            matrices.translate(0.0, 0.5, 0.0);

            // Rotate the needle to point away from the player
            matrices.multiply(Vector3f.POSITIVE_Y.getDegreesQuaternion(MathHelper.lerp(tickDelta, entity.prevYaw, entity.yaw) - 90.0F));
            matrices.multiply(Vector3f.POSITIVE_Z.getDegreesQuaternion(MathHelper.lerp(tickDelta, entity.prevPitch, entity.pitch) - 45.0F));

            // Render a rectangle
            float width = 0.1F;
            float height = 0.5F;
            matrices.scale(width, height, width);
            this.renderModel(entity, tickDelta, matrices, vertexConsumers, light);

            matrices.pop();
            super.render(entity, yaw, tickDelta, matrices, vertexConsumers, light);
        }

        private void renderModel(NeedleProjectile entity, float tickDelta, MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light) {
            ItemStack needleItemStack = entity.asItemStack();
            this.dispatcher.getHeldItemRenderer().renderItem(needleItemStack, ModelTransformation.Mode.NONE, light, 0, matrices, vertexConsumers);
        }

        @Override
        public Identifier getTexture(NeedleProjectile entity) {
            return new Identifier("sinisterxmas", "textures/entity/needle.png");
        }
    }
}