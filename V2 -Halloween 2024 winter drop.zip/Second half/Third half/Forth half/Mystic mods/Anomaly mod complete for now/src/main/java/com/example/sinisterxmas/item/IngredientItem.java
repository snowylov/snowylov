package com.example.sinisterxmas.item;

import net.minecraft.item.Item;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

public class IngredientItem extends Item {
    public IngredientItem(Settings settings, String name) {
        super(settings);
        Registry.register(Registry.ITEM, new Identifier("sinisterxmas", name), this);
    }
}