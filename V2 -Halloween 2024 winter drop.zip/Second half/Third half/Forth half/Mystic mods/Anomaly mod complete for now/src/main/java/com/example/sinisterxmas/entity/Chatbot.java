package com.example.sinisterxmas.entity;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import java.util.HashMap;
import java.util.Map;

public class Chatbot {
    private final Map<String, String> responses = new HashMap<>();

    public Chatbot() {
        // Define some simple responses
        responses.put("hello", "Hello, player!");
        responses.put("who are you", "I am Specimen 31, created to spread taint and flux.");
        responses.put("help", "I'm here to help you... or maybe not.");
        // Add more responses as needed
    }

    public void onPlayerChat(PlayerEntity player, String message) {
        String lowerMessage = message.toLowerCase();
        if (responses.containsKey(lowerMessage)) {
            String response = responses.get(lowerMessage);
            if (player instanceof ServerPlayerEntity) {
                ((ServerPlayerEntity) player).sendMessage(Text.literal(response), false);
            }
        }
    }
}