package com.example.sinisterxmas.item;

import com.example.sinisterxmas.entity.needle.NeedleProjectile;
import net.fabricmc.api.ModInitializer;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.text.TranslatableText;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.model.json.ModelTransformation;
import net.minecraft.client.util.math.Vector3f;
import net.minecraft.tag.ItemTags;
import net.minecraft.item.Items;

import java.util.List;

public class NeedleGun extends Item {

    public static final NeedleGun NEEDLE_GUN = new NeedleGun(new Item.Settings().maxCount(1));

    public NeedleGun(Settings settings) {
        super(settings);
        Registry.register(Registry.ITEM, new Identifier("sinisterxmas", "needle_gun"), this);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        ItemStack offhandStack = user.getOffHandStack();

        if (!world.isClient) {
            if (offhandStack.getItem() instanceof NeedleItem || offhandStack.isIn(ItemTags.ARROWS)) {
                shootNeedle(world, user, offhandStack);
            }
        }

        return new TypedActionResult<>(ActionResult.SUCCESS, stack);
    }

    private void shootNeedle(World world, PlayerEntity player, ItemStack needleStack) {
        if (needleStack.getItem() instanceof NeedleItem) {
            NeedleProjectile needleProjectile = NeedleProjectile.createNeedle(world, needleStack);
            needleProjectile.setPosition(player.getX(), player.getEyeY() - 0.1, player.getZ());
            needleProjectile.setVelocity(player, player.getPitch(), player.getYaw(), 0.0F, 3.0F, 1.0F);
            world.spawnEntity(needleProjectile);

            // Play thorns armor collide sound effect
            world.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.ENCHANT_THORNS_HIT, SoundCategory.PLAYERS, 1.0F, 1.0F);

            needleStack.decrement(1);
        } else if (needleStack.isIn(ItemTags.ARROWS)) {
            ArrowEntity arrowEntity = new ArrowEntity(world, player);
            arrowEntity.setProperties(player, player.getPitch(), player.getYaw(), 0.0F, 3.0F, 1.0F);
            world.spawnEntity(arrowEntity);

            // Play thorns armor collide sound effect
            world.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.ENCHANT_THORNS_HIT, SoundCategory.PLAYERS, 1.0F, 1.0F);

            needleStack.decrement(1);
        }
    }

    @Override
    public void appendTooltip(ItemStack stack, World world, List<Text> tooltip, TooltipContext context) {
        super.appendTooltip(stack, world, tooltip, context);
        if (Screen.hasShiftDown()) {
            tooltip.add(new TranslatableText("item.sinisterxmas.needle_gun.tooltip.shift").formatted(Formatting.YELLOW));
        } else {
            tooltip.add(new TranslatableText("item.sinisterxmas.needle_gun.tooltip").formatted(Formatting.GRAY));
        }
    }
}