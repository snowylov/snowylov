package com.example.sinisterxmas.entity;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendereregistry.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.entity.FabricEntityTypeBuilder;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.Packet;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;
import net.minecraft.world.World;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;

import java.util.Random;

public class TaintAnomaly extends ParasiteAnomalyEntity {
    public static final EntityType<TaintAnomaly> TAINT_ANOMALY = Registry.register(
            Registry.ENTITY_TYPE,
            new Identifier("sinisterxmas", "taint_anomaly"),
            FabricEntityTypeBuilder.create(SpawnGroup.MISC, TaintAnomaly::new)
                    .dimensions(EntityDimensions.fixed(0.5f, 0.5f))
                    .build()
    );

    static {
        // Auto-register entity renderer
        EntityRendererRegistry.INSTANCE.register(TAINT_ANOMALY, (context) -> new TaintOverlay());
        TaintOverlay.register();
    }

    public TaintAnomaly(EntityType<?> type, World world) {
        super(type, world);
        setRenderType(AnomalyRenderType.INVISIBLE);
        setType(AnomalyType.TAINT);
        setParasiteType(ParasiteType.TAINT);
    }

    @Override
    public void tick() {
        super.tick();
        if (!world.isClient) {
            PlayerEntity closestPlayer = world.getClosestPlayer(this, 5);
            if (closestPlayer != null) {
                this.setPosition(closestPlayer.getX(), closestPlayer.getY(), closestPlayer.getZ());
                spreadToNearbyPlayers();
                applyEffectsToPlayer(closestPlayer);
                ensureSpecimen31HasAnomaly(closestPlayer);
            }
        }
    }

    private void spreadToNearbyPlayers() {
        world.getEntitiesByClass(PlayerEntity.class, this.getBoundingBox().expand(1), player -> player != this.getOwner()).forEach(player -> {
            TaintAnomaly newAnomaly = new TaintAnomaly(TAINT_ANOMALY, world);
            newAnomaly.setPosition(player.getX(), player.getY(), player.getZ());
            world.spawnEntity(newAnomaly);
        });
    }

    private void applyEffectsToPlayer(PlayerEntity player) {
        if (world.getTime() % (5 * 20 * 60) == 0) { // Every five in-game minutes
            player.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 200, 1)); // 10 seconds
        }
    }

    private void ensureSpecimen31HasAnomaly(PlayerEntity player) {
        if ("Specimen_31".equals(player.getEntityName())) {
            if (!this.isAlive()) {
                TaintAnomaly newAnomaly = new TaintAnomaly(TAINT_ANOMALY, world);
                newAnomaly.setPosition(player.getX(), player.getY(), player.getZ());
                world.spawnEntity(newAnomaly);
            }
        }
    }

    @Override
    public boolean isFireImmune() {
        return true;
    }

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
    }

    @Override
    public Packet<?> createSpawnPacket() {
        return EntitySpawnPacket.create(this, TAINT_ANOMALY);
    }

    @Environment(EnvType.CLIENT)
    public static class TaintOverlay {
        private static float currentTransparency = 0.5f;
        private static final Random random = new Random();
        private static long lastUpdateTime = 0;
        private static final Identifier TEXTURE = new Identifier("textures/block/vine.png");

        public static void register() {
            ClientTickEvents.END_CLIENT_TICK.register(client -> {
                if (client.player != null) {
                    long currentTime = client.world.getTime();
                    if (currentTime != lastUpdateTime) {
                        currentTransparency = 0.3f + (random.nextFloat() * (0.8f - 0.3f)); // Fluctuate between 30% and 80%
                        lastUpdateTime = currentTime;
                    }
                    renderOverlay(currentTransparency);
                }
            });
        }

        public static void renderOverlay(float transparency) {
            MinecraftClient client = MinecraftClient.getInstance();
            MatrixStack matrixStack = new MatrixStack();
            matrixStack.push();
            matrixStack.translate(0, 0, -90);
            matrixStack.scale(1.0f, 1.0f, 1.0f);

            client.getTextureManager().bindTexture(TEXTURE);
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            RenderSystem.color4f(0.5F, 0.0F, 0.5F, transparency); // Purple color

            Tessellator tessellator = Tessellator.getInstance();
            BufferBuilder bufferBuilder = tessellator.getBuffer();
            bufferBuilder.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE);
            bufferBuilder.vertex(matrixStack.peek().getModel(), -1.0F, -1.0F, -0.5F).texture(0.0F, 0.0F).next();
            bufferBuilder.vertex(matrixStack.peek().getModel(), 1.0F, -1.0F, -0.5F).texture(1.0F, 0.0F).next();
            bufferBuilder.vertex(matrixStack.peek().getModel(), 1.0F, 1.0F, -0.5F).texture(1.0F, 1.0F).next();
            bufferBuilder.vertex(matrixStack.peek().getModel(), -1.0F, 1.0F, -0.5F).texture(0.0F, 1.0F).next();
            tessellator.draw();

            RenderSystem.disableBlend();
            matrixStack.pop();
        }
    }
}