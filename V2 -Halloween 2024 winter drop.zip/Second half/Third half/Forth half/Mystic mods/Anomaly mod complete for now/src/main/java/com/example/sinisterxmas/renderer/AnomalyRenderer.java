package com.example.sinisterxmas.renderer;

import com.example.sinisterxmas.entity.CannibalCowAnomaly;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.ItemEntityRenderer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;

public class AnomalyRenderer extends ItemEntityRenderer {

    public AnomalyRenderer(EntityRendererFactory.Context context) {
        super(context);
    }

    @Override
    public Identifier getTexture(CannibalCowAnomaly entity) {
        return new Identifier("sinisterxmas", "textures/entity/cannibal_cow_anomaly.png");
    }

    @Override
    public ItemStack getRenderStack() {
        return new ItemStack(Items.BEEF);
    }
}