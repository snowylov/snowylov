package com.example.sinisterxmas.entity;

import com.example.sinisterxmas.entity.needle.NeedleProjectile;
import net.fabricmc.fabric.api.client.rendereregistry.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.entity.FabricEntityTypeBuilder;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.*;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.equipment.EquipmentSlot;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ArrowEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.text.TranslatableText;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.registry.Registry;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.world.World;

import java.util.EnumSet;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class Specimen31Entity extends MobEntity {
    public static final EntityType<Specimen31Entity> SPECIMEN_31_ENTITY = Registry.register(
            Registry.ENTITY_TYPE,
            new Identifier("sinisterxmas", "specimen_31_entity"),
            FabricEntityTypeBuilder.create(SpawnGroup.MONSTER, Specimen31Entity::new)
                    .dimensions(EntityDimensions.fixed(0.6f, 1.8f))
                    .trackable(128, 3)
                    .build()
    );

    private int healUses = 100;
    private final Chatbot chatbot = new Chatbot();
    private boolean playerArmorRemoved = false;

    public Specimen31Entity(EntityType<? extends MobEntity> entityType, World world) {
        super(entityType, world);
        this.equipArmor();
        this.equipWeapon();
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(1, new Specimen31Entity.AttackGoal(this));
        this.goalSelector.add(2, new Specimen31Entity.HealGoal(this));
        this.goalSelector.add(3, new WanderAroundGoal(this, 1.0));
        this.goalSelector.add(4, new LookAroundGoal(this));
        this.goalSelector.add(5, new Specimen31Entity.ArmorCheckGoal(this));
        this.goalSelector.add(6, new Specimen31Entity.DodgeProjectileGoal(this));
    }

    private void equipArmor() {
        ItemStack chestplate = new ItemStack(Items.NETHERITE_CHESTPLATE);
        chestplate.addEnchantment(Enchantments.PROTECTION, 4);
        chestplate.addEnchantment(Enchantments.FIRE_PROTECTION, 4);
        chestplate.addEnchantment(Enchantments.BLAST_PROTECTION, 4);

        ItemStack leggings = new ItemStack(Items.NETHERITE_LEGGINGS);
        leggings.addEnchantment(Enchantments.PROTECTION, 4);
        leggings.addEnchantment(Enchantments.FIRE_PROTECTION, 4);
        leggings.addEnchantment(Enchantments.BLAST_PROTECTION, 4);

        ItemStack boots = new ItemStack(Items.NETHERITE_BOOTS);
        boots.addEnchantment(Enchantments.PROTECTION, 4);
        boots.addEnchantment(Enchantments.FIRE_PROTECTION, 4);
        boots.addEnchantment(Enchantments.BLAST_PROTECTION, 4);

        this.equipStack(EquipmentSlot.CHEST, chestplate);
        this.equipStack(EquipmentSlot.LEGS, leggings);
        this.equipStack(EquipmentSlot.FEET, boots);
    }

    private void equipWeapon() {
        this.equipStack(EquipmentSlot.MAINHAND, new ItemStack(SinisterXmasItems.NEEDLE_GUN));
    }

    @Override
    protected void applyAttributes() {
        super.applyAttributes();
        this.getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH).setBaseValue(80.0);
        this.getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED).setBaseValue(0.35);
    }

    @Override
    public void tick() {
        super.tick();
        if (this.getHealth() <= 20.0F && !this.hasStatusEffect(StatusEffects.REGENERATION)) {
            this.disableAI();
            this.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 6000, 1, false, false, true));
        } else if (this.hasStatusEffect(StatusEffects.REGENERATION) && this.getHealth() > 20.0F) {
            this.enableAI();
        }

        // Chatbot random voodoo attack
        if (this.age % (20 * 300) == 0) {
            if (this.random.nextDouble() < 0.10) {
                this.chatbot.voodooAttack(this);
            }
        }
    }

    private void disableAI() {
        this.goalSelector.clear();
        this.addStatusEffect(new StatusEffectInstance(StatusEffects.INVISIBILITY, 6000, 0, false, false, true));
        this.chatbot.say(this, "oh It's You...");

        // Reset health after 3 real life hours
        this.world.getServer().getScheduler().schedule(() -> {
            this.heal(this.getMaxHealth());
            this.enableAI();
        }, 3, TimeUnit.HOURS);
    }

    private void enableAI() {
        this.initGoals();
        this.removeStatusEffect(StatusEffects.INVISIBILITY);
    }

    @Override
    public boolean damage(DamageSource source, float amount) {
        if (super.damage(source, amount)) {
            if (this.getHealth() < 0.6 * this.getMaxHealth() && this.healUses > 0) {
                this.heal(10.0F);
                this.healUses--;
                this.equipStack(EquipmentSlot.OFFHAND, new ItemStack(SinisterXmasItems.HEALING_NEEDLE));
                this.chatbot.say(this, "Help, I'm low on health!");
            }
            return true;
        }
        return false;
    }

    @Override
    protected void onKilledBy(LivingEntity adversary) {
        if (adversary instanceof PlayerEntity player) {
            this.chatbot.sayFalseFacts(player);
            // Leave player alone for 15 minutes
            this.disableAI();
            this.world.getServer().getScheduler().schedule(this::enableAI, 15, TimeUnit.MINUTES);
        }
        super.onKilledBy(adversary);
    }

    public static void register() {
        Registry.register(Registry.ENTITY_TYPE, new Identifier("sinisterxmas", "specimen_31"), SPECIMEN_31_ENTITY);
        EntityRendererRegistry.INSTANCE.register(SPECIMEN_31_ENTITY, Specimen31EntityRenderer::new);
    }

    public static class AttackGoal extends Goal {
        private final Specimen31Entity entity;

        public AttackGoal(Specimen31Entity entity) {
            this.entity = entity;
            this.setControls(EnumSet.of(Control.MOVE, Control.LOOK));
        }

        @Override
        public boolean canStart() {
            return this.entity.getTarget() != null && this.entity.getTarget().isAlive();
        }

        @Override
        public void start() {
            this.entity.getNavigation().startMovingTo(this.entity.getTarget(), 1.0);
        }

        @Override
        public void stop() {
            this
            

entity.setTarget(null);
this.entity.getNavigation().stop();
}


    @Override
    public void tick() {
        PlayerEntity target = this.entity.getTarget();
        if (target != null && this.entity.squaredDistanceTo(target) < 6400.0) {
            if (this.entity.getAttackCooldown() <= 0) {
                this.entity.shootNeedleAt(target);
                this.entity.resetAttackCooldown();
            }

            if (this.entity.squaredDistanceTo(target) < 1.0) {
                // Infect with Taint Parasite
                this.chatbot.say(this, "Feeling ill yet?");
            }

            // Breaking blocks to reach the player
            BlockPos targetPos = target.getBlockPos();
            if (!world.isAir(targetPos)) {
                world.breakBlock(targetPos, true);
            }

            // Climb ladders
            if (world.getBlockState(this.entity.getBlockPos().up()).getBlock() instanceof LadderBlock) {
                this.entity.setVelocity(0, 1, 0);
            }

            // Multiple players logic
            if (world.getPlayers().size() > 1) {
                this.entity.chatbot.say(this, "fine I'll leave you two alone and stay at a 30-500 block distance.");
                this.entity.stayAtDistance(30, 500);
            }
        }
    }
}

public static class HealGoal extends Goal {
    private final Specimen31Entity entity;

    public HealGoal(Specimen31Entity entity) {
        this.entity = entity;
        this.setControls(EnumSet.of(Control.MOVE));
    }

    @Override
    public boolean canStart() {
        return this.entity.getHealth() < this.entity.getMaxHealth();
    }

    @Override
    public void start() {
        this.entity.getNavigation().startMovingTo(this.entity.getHealTarget(), 1.0);
    }

    @Override
    public void stop() {
        this.entity.setHealTarget(null);
        this.entity.getNavigation().stop();
    }

    @Override
    public void tick() {
        if (this.entity.getHealth() < 0.6 * this.entity.getMaxHealth()) {
            this.entity.heal(10.0F);
            this.entity.healUses--;
            this.entity.equipStack(EquipmentSlot.OFFHAND, new ItemStack(SinisterXmasItems.HEALING_NEEDLE));
            this.entity.chatbot.say(this, "Help, I'm low on health!");
        }
    }
}

public static class ArmorCheckGoal extends Goal {
    private final Specimen31Entity entity;

    public ArmorCheckGoal(Specimen31Entity entity) {
        this.entity = entity;
        this.setControls(EnumSet.of(Control.MOVE));
    }

    @Override
    public boolean canStart() {
        return !this.entity.playerArmorRemoved && this.entity.getTarget() != null;
    }

    @Override
    public void start() {
        PlayerEntity player = this.entity.getTarget();
        if (player != null && !player.isWearingArmor()) {
            this.entity.unequipArmor();
            this.entity.chatbot.say(this, "is it getting hot? Oh it's just me? Oh well. *giggles*");
        }
    }

    @Override
    public void stop() {
        this.entity.equipArmor();
    }
}

public static class Specimen31EntityRenderer extends EntityRenderer<Specimen31Entity> {
    private final BipedEntityModel<Specimen31Entity> model = new BipedEntityModel<>(0.0F);

    public Specimen31EntityRenderer(EntityRendererFactory.Context context) {
        super(context);
    }

    @Override
    public void render(Specimen31Entity entity, float yaw, float tickDelta, MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light) {
        matrices.push();

        // Position the entity in the world
        matrices.translate(0.0, 0.5, 0.0);

        // Rotate the entity to point away from the player
        matrices.multiply(Vector3f.POSITIVE_Y.getDegreesQuaternion(MathHelper.lerp(tickDelta, entity.prevYaw, entity.yaw) - 90.0F));
        matrices.multiply(Vector3f.POSITIVE_Z.getDegreesQuaternion(MathHelper.lerp(tickDelta, entity.prevPitch, entity.pitch) - 45.0F));

        // Render the model
        this.model.render(matrices, vertexConsumers.getBuffer(this.model.getLayer(new Identifier("sinisterxmas", "textures/entity/tainted_baddies/specimen_31.png"))), light, OverlayTexture.DEFAULT_UV, 1.0F, 1.0F, 1.0F, 1.0F);

        matrices.pop();
        super.render(entity, yaw, tickDelta, matrices, vertexConsumers, light);
    }

    @Override
    public Identifier getTexture(Specimen31Entity entity) {
        return new Identifier("sinisterxmas", "textures/entity/tainted_baddies/specimen_31.png");
    }
}
}