package com.example.sinisterxmas.entity;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.rendereregistry.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.entity.FabricEntityTypeBuilder;
import net.minecraft.block.Blocks;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.state.property.Properties;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.registry.Registry;
import net.minecraft.world.World;

public class HaydayAnomaly extends AnomalyEntity {
    public static final EntityType<HaydayAnomaly> HAYDAY_ANOMALY = Registry.register(
            Registry.ENTITY_TYPE,
            new Identifier("sinisterxmas", "hayday_anomaly"),
            FabricEntityTypeBuilder.create(SpawnGroup.MISC, HaydayAnomaly::new)
                    .dimensions(EntityDimensions.fixed(0.5f, 0.5f))
                    .build()
    );

    static {
        // Auto-register entity renderer
        EntityRendererRegistry.INSTANCE.register(HaydayAnomaly.HAYDAY_ANOMALY, (context) -> new AnomalyRenderer(context));
    }

    public HaydayAnomaly(EntityType<?> type, World world) {
        super(type, world);
        setRenderType(AnomalyRenderType.ITEM_RENDER);
        setRenderItem(Blocks.HAY_BLOCK.asItem());
    }

    public static void effects(World world, PlayerEntity player) {
        BlockPos playerPos = player.getBlockPos();

        BlockPos.stream(playerPos.add(-1, 0, -1), playerPos.add(1, 0, 1)).forEach(blockPos -> {
            if (world.getBlockState(blockPos).getBlock() == Blocks.WHEAT) {
                world.setBlockState(blockPos, Blocks.WHEAT.getDefaultState().with(Properties.AGE_7, 7), 3);
            }
        });
    }
}