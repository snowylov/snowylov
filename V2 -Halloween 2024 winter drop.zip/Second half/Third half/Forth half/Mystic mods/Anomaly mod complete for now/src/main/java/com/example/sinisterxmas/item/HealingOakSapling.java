package com.example.sinisterxmas.block;

import com.example.sinisterxmas.entity.HealingTreeAnomaly;
import net.fabricmc.api.ModInitializer;
import net.minecraft.block.BlockState;
import net.minecraft.block.LeavesBlock;
import net.minecraft.block.Material;
import net.minecraft.block.SaplingBlock;
import net.minecraft.block.sapling.SaplingGenerator;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.loot.context.LootContext;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.text.TranslatableText;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.registry.Registry;
import net.minecraft.world.BlockView;
import net.minecraft.world.StructureWorldAccess;
import net.minecraft.world.World;
import net.minecraft.world.gen.chunk.ChunkGenerator;
import net.minecraft.world.gen.feature.ConfiguredFeature;
import net.minecraft.world.gen.feature.ConfiguredFeatures;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class HealingOakSapling extends SaplingBlock {

    public static final HealingOakSapling HEALING_OAK_SAPLING = new HealingOakSapling(new HealingOakSaplingGenerator(), new Item.Settings());
    public static final HealingOakLeaves HEALING_OAK_LEAVES = new HealingOakLeaves(Settings.of(Material.LEAVES).strength(0.2F).ticksRandomly().nonOpaque());

    public HealingOakSapling(SaplingGenerator generator, Settings settings) {
        super(generator, settings);
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext context) {
        World world = context.getWorld();
        BlockPos pos = context.getBlockPos();
        ItemStack stack = context.getStack();
        if (!world.isClient) {
            world.setBlockState(pos.up(), this.getDefaultState(), 3);
            stack.decrement(1);
            world.playSound(null, pos, SoundEvents.BLOCK_GRASS_PLACE, SoundCategory.BLOCKS, 1.0F, 1.0F);
        }
        return ActionResult.SUCCESS;
    }

    public static void registerAll() {
        Registry.register(Registry.BLOCK, new Identifier("sinisterxmas", "healing_oak_sapling"), HEALING_OAK_SAPLING);
        Registry.register(Registry.ITEM, new Identifier("sinisterxmas", "healing_oak_sapling"), new BlockItem(HEALING_OAK_SAPLING, new Item.Settings().group(ItemGroup.MISC)));

        Registry.register(Registry.BLOCK, new Identifier("sinisterxmas", "healing_oak_leaves"), HEALING_OAK_LEAVES);
        Registry.register(Registry.ITEM, new Identifier("sinisterxmas", "healing_oak_leaves"), new BlockItem(HEALING_OAK_LEAVES, new Item.Settings().group(ItemGroup.DECORATIONS)));
    }

    static class HealingOakLeaves extends LeavesBlock {
        public HealingOakLeaves(Settings settings) {
            super(settings);
        }

        @Override
        protected int getSaplingDropChance(BlockState state) {
            return 2; // 50% chance
        }

        @Override
        public boolean canDropFromExplosion(BlockState state) {
            return false; // Prevents dropping from explosions
        }

        @Override
        public ItemStack getPickStack(BlockView world, BlockPos pos, BlockState state) {
            return new ItemStack(HealingOakSapling.HEALING_OAK_SAPLING);
        }

        @Override
        public List<ItemStack> getDroppedStacks(BlockState state, LootContext.Builder builder) {
            List<ItemStack> drops = new ArrayList<>();
            Random random = builder.getWorld().random;
            if (random.nextInt(2) == 0) {
                drops.add(new ItemStack(HealingOakSapling.HEALING_OAK_SAPLING));
            } else {
                drops.add(new ItemStack(Items.STICK));
            }
            return drops;
        }
    }

    static class HealingOakSaplingGenerator extends SaplingGenerator {
        @Override
        protected ConfiguredFeature<?, ?> getTreeFeature(Random random, boolean bees) {
            return ConfiguredFeatures.OAK; // Using default oak tree configuration
        }

        @Override
        public boolean generate(StructureWorldAccess world, ChunkGenerator chunkGenerator, BlockPos pos, BlockState state, Random random) {
            boolean success = super.generate(world, chunkGenerator, pos, state, random);
            if (success) {
                spawnAnomaly(world, pos);
            }
            return success;
        }

        private void spawnAnomaly(StructureWorldAccess world, BlockPos pos) {
            HealingTreeAnomaly anomaly = new HealingTreeAnomaly(HealingTreeAnomaly.HEALING_TREE_ANOMALY, world.toServerWorld());
            anomaly.setPosition(pos.getX(), pos.getY(), pos.getZ());
            world.spawnEntity(anomaly);
        }
    }
}