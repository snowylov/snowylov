package com.example.sinisterxmas.registry;

import com.example.sinisterxmas.entity.NaomiEntity;
import net.fabricmc.fabric.api.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.client.rendereregistry.v1.EntityRendererRegistry;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

public class NaomiRegistry {

    public static void registerEntities() {
        // Register the Naomi entity
        Registry.register(Registry.ENTITY_TYPE, new Identifier("sinisterxmas", "naomi"), NaomiEntity.NAOMI_ENTITY);
        FabricDefaultAttributeRegistry.register(NaomiEntity.NAOMI_ENTITY, NaomiEntity.createMobAttributes());

        // Register the renderer
        EntityRendererRegistry.INSTANCE.register(NaomiEntity.NAOMI_ENTITY, (dispatcher, context) -> new NaomiEntity.NaomiEntityRenderer(dispatcher));
    }
}