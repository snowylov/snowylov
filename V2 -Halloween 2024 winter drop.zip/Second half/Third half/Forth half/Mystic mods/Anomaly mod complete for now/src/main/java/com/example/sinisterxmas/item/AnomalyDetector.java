package com.example.sinisterxmas.item;

import net.fabricmc.api.ModInitializer;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.item.ItemStack;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.text.TranslatableText;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.List;

public class AnomalyDetector extends Item {

    public static final AnomalyDetector ANOMALY_DETECTOR = new AnomalyDetector(new Item.Settings().maxCount(1));

    public AnomalyDetector(Settings settings) {
        super(settings);
        Registry.register(Registry.ITEM, new Identifier("sinisterxmas", "anomaly_detector"), this);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (!world.isClient) {
            BlockPos playerPos = user.getBlockPos();
            boolean anomalyDetected = world.getEntitiesByClass(AnomalyEntity.class, user.getBoundingBox().expand(50), anomaly -> true).size() > 0;

            if (anomalyDetected) {
                user.sendMessage(new TranslatableText("item.sinisterxmas.anomaly_detector.detected").formatted(Formatting.GREEN), true);
                world.playSound(null, playerPos, SoundEvents.BLOCK_NOTE_BLOCK_PLING, SoundCategory.PLAYERS, 1.0F, 1.0F);
            } else {
                user.sendMessage(new TranslatableText("item.sinisterxmas.anomaly_detector.not_detected").formatted(Formatting.RED), true);
                world.playSound(null, playerPos, SoundEvents.BLOCK_NOTE_BLOCK_BASS, SoundCategory.PLAYERS, 1.0F, 1.0F);
            }
        }
        return new TypedActionResult<>(ActionResult.SUCCESS, stack);
    }

    @Override
    public void appendTooltip(ItemStack stack, World world, List<Text> tooltip, TooltipContext context) {
        super.appendTooltip(stack, world, tooltip, context);
        if (Screen.hasShiftDown()) {
            tooltip.add(new TranslatableText("item.sinisterxmas.anomaly_detector.tooltip.shift").formatted(Formatting.YELLOW));
        } else {
            tooltip.add(new TranslatableText("item.sinisterxmas.anomaly_detector.tooltip").formatted(Formatting.GRAY));
        }
    }
}