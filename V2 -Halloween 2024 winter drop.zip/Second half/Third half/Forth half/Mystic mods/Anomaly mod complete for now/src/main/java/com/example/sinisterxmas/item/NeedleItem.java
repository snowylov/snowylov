package com.example.sinisterxmas.item;

import net.minecraft.item.Item;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

public class NeedleItem extends Item {
    public static final NeedleItem TAINT_NEEDLE = new NeedleItem(new Item.Settings().maxCount(4000), "taint");
    public static final NeedleItem TWILIGHT_NEEDLE = new NeedleItem(new Item.Settings().maxCount(4000), "twilight");
    public static final NeedleItem STANDARD_NEEDLE = new NeedleItem(new Item.Settings().maxCount(4000), "standard");
    public static final NeedleItem LIFE_DRAIN_NEEDLE = new NeedleItem(new Item.Settings().maxCount(4000), "life_drain");
    public static final NeedleItem WITHER_NEEDLE = new NeedleItem(new Item.Settings().maxCount(4000), "wither");
    public static final NeedleItem POISON_NEEDLE = new NeedleItem(new Item.Settings().maxCount(4000), "poison");
    public static final NeedleItem HEALING_NEEDLE = new NeedleItem(new Item.Settings().maxCount(4000), "healing");
    public static final NeedleItem DEADLY_NEEDLE = new NeedleItem(new Item.Settings().maxCount(4000), "deadly");

    private final String type;

    public NeedleItem(Settings settings, String type) {
        super(settings);
        this.type = type;
        Registry.register(Registry.ITEM, new Identifier("sinisterxmas", type + "_needle"), this);
    }

    @Override
    public NbtCompound getOrCreateNbt(ItemStack stack) {
        NbtCompound nbt = stack.getOrCreateNbt();
        nbt.putString("NeedleType", type);
        return nbt;
    }
}