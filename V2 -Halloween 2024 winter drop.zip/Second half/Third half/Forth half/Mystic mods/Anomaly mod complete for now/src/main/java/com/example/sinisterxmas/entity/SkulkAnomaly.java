### SkulkAnomaly Entity Class

```java
package com.example.sinisterxmas.entity;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.rendereregistry.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.entity.FabricEntityTypeBuilder;
import net.minecraft.block.Blocks;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.state.property.Properties;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.registry.Registry;
import net.minecraft.world.World;

public class SkulkAnomaly extends AnomalyEntity {
    private static int skulkNodeCount = 0;

    public static final EntityType<SkulkAnomaly> SKULK_ANOMALY = Registry.register(
            Registry.ENTITY_TYPE,
            new Identifier("sinisterxmas", "skulk_anomaly"),
            FabricEntityTypeBuilder.create(SpawnGroup.MISC, SkulkAnomaly::new)
                    .dimensions(EntityDimensions.fixed(0.5f, 0.5f))
                    .build()
    );

    static {
        // Auto-register entity renderer
        EntityRendererRegistry.INSTANCE.register(SkulkAnomaly.SKULK_ANOMALY, (context) -> new AnomalyRenderer(context));
    }

    public SkulkAnomaly(EntityType<?> type, World world) {
        super(type, world);
        setRenderType(AnomalyRenderType.PORTAL_RENDER);
        setType(AnomalyType.SKULK);
    }

    @Override
    public void tick() {
        super.tick();

        if (!world.isClient) {
            effects(world, this.getBlockPos());
        }
    }

    public static void effects(World world, BlockPos pos) {
        // Check for XP orbs within 80 blocks
        world.getEntitiesByClass(ExperienceOrbEntity.class, new Box(pos.add(-80, -80, -80), pos.add(80, 80, 80)), entity -> true)
             .forEach(orb -> {
                // Spread skulk around the position of the XP orb
                BlockPos orbPos = orb.getBlockPos();
                spreadSkulk(world, orbPos);
                orb.remove();
             });
    }

    private static void spreadSkulk(World world, BlockPos pos) {
        if (skulkNodeCount >= 8) return;

        BlockPos.stream(pos.add(-1, -1, -1), pos.add(1, 1, 1)).forEach(blockPos -> {
            if (world.getBlockState(blockPos).isAir()) {
                world.setBlockState(blockPos, Blocks.SCULK.getDefaultState(), 3);
                if (world.random.nextInt(100) < 10) { // 10% chance to create a skulk node
                    world.setBlockState(blockPos, Blocks.SCULK_CATALYST.getDefaultState(), 3);
                    skulkNodeCount++;
                }
            }
        });
    }
}