{
  "parent": "item/generated",
  "textures": {
    "layer0": "minecraft:block/fire_layer_0"
  }
}