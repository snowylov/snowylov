package com.example.sinisterxmas.client;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import java.util.Random;

@Environment(EnvType.CLIENT)
public class VisionColorOverlay implements ClientModInitializer {
    private static boolean hasVisionColorOverlay = true;
    private static float currentTransparency = 0.5f;
    private static final Random random = new Random();
    private static long lastUpdateTime = 0;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (hasVisionColorOverlay && client.player != null) {
                long currentTime = client.world.getTime();
                if (currentTime != lastUpdateTime) {
                    currentTransparency = 0.3f + (random.nextFloat() * (0.8f - 0.3f)); // Fluctuate between 30% and 80%
                    lastUpdateTime = currentTime;
                }
                renderOverlay(currentTransparency);
            }
        });
    }

    public static void renderOverlay(float transparency) {
        MinecraftClient client = MinecraftClient.getInstance();
        MatrixStack matrixStack