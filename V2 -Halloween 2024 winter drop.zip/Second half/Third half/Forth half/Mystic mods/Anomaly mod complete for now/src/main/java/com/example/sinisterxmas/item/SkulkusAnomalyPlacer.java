package com.example.sinisterxmas.item;

import com.example.sinisterxmas.entity.SkulkAnomaly;
import net.fabricmc.api.ModInitializer;
import net.minecraft.block.Blocks;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.item.ItemStack;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.text.TranslatableText;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.client.gui.screen.Screen;

import java.util.List;

public class SkulkusAnomalyPlacer extends Item {

    public static final SkulkusAnomalyPlacer SKULKUS_ANOMALY_PLACER = new SkulkusAnomalyPlacer(new Item.Settings().maxCount(1));

    public SkulkusAnomalyPlacer(Settings settings) {
        super(settings);
        Registry.register(Registry.ITEM, new Identifier("sinisterxmas", "skulkus_anomaly_placer"), this);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        return new TypedActionResult<>(ActionResult.SUCCESS, user.getStackInHand(hand));
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext context) {
        World world = context.getWorld();
        BlockPos pos = context.getBlockPos();
        if (!world.isClient && (world.getBlockState(pos).getBlock() == Blocks.GRASS_BLOCK || world.getBlockState(pos).getBlock() == Blocks.DIRT)) {
            BlockPos spawnPos = pos.up();
            SkulkAnomaly anomaly = new SkulkAnomaly(SkulkAnomaly.SKULK_ANOMALY, world);
            anomaly.setPosition(spawnPos.getX() + 0.5, spawnPos.getY(), spawnPos.getZ() + 0.5);
            world.spawnEntity(anomaly);
            context.getStack().decrement(1);
            world.playSound(null, spawnPos, SoundEvents.BLOCK_SCULK_CATALYST_PLACE, SoundCategory.BLOCKS, 1.0F, 1.0F);
            return ActionResult.SUCCESS;
        }
        return ActionResult.FAIL;
    }

    @Override
    public void appendTooltip(ItemStack stack, World world, List<Text> tooltip, TooltipContext context) {
        super.appendTooltip(stack, world, tooltip, context);
        if (Screen.hasShiftDown()) {
            tooltip.add(new TranslatableText("item.sinisterxmas.skulkus_anomaly_placer.tooltip.shift").formatted(Formatting.YELLOW));
        } else {
            tooltip.add(new TranslatableText("item.sinisterxmas.skulkus_anomaly_placer.tooltip").formatted(Formatting.GRAY));
        }
    }
}