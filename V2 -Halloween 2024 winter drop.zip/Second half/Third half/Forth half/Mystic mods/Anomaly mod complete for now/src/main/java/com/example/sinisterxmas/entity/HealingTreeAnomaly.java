package com.example.sinisterxmas.entity;

import net.fabricmc.fabric.api.client.rendereregistry.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.Packet;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.registry.Registry;
import net.minecraft.world.World;

public class HealingTreeAnomaly extends AnomalyEntity {
    public static final EntityType<HealingTreeAnomaly> HEALING_TREE_ANOMALY = Registry.register(
            Registry.ENTITY_TYPE,
            new Identifier("sinisterxmas", "healing_tree_anomaly"),
            FabricEntityTypeBuilder.create(SpawnGroup.MISC, HealingTreeAnomaly::new)
                    .dimensions(EntityDimensions.fixed(0.5f, 0.5f))
                    .trackable(128, 3)
                    .build()
    );

    public HealingTreeAnomaly(EntityType<? extends AnomalyEntity> entityType, World world) {
        super(entityType, world);
        this.anomalyHasToBeInsideBlock = true;
        this.setType(AnomalyType.GOOD);
    }

    @Override
    public void tick() {
        super.tick();
        if (this.age % 72000 == 0) { // Every 3 Minecraft days
            clearNearbyAnomalies();
        }
    }

    private void clearNearbyAnomalies() {
        BlockPos pos = this.getBlockPos();
        world.getEntitiesByClass(AnomalyEntity.class, this.getBoundingBox().expand(50), entity -> true)
                .forEach(entity -> {
                    if (entity instanceof SkulkAnomaly || entity instanceof WitherAnomaly || entity instanceof EvilAnomaly) {
                        entity.remove(RemovalReason.KILLED);
                    }
                });
    }

    @Override
    protected void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
    }

    @Override
    protected void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
    }

    @Override
    public Packet<?> createSpawnPacket() {
        return EntitySpawnPacket.create(this, HEALING_TREE_ANOMALY);
    }

    public static void register() {
        Registry.register(Registry.ENTITY_TYPE, new Identifier("sinisterxmas", "healing_tree_anomaly"), HEALING_TREE_ANOMALY);
        EntityRendererRegistry.INSTANCE.register(HEALING_TREE_ANOMALY, (context) -> new AnomalyRenderer(context));
    }
}