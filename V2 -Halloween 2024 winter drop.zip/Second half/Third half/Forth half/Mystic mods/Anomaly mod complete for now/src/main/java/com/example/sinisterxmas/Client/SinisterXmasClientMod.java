package com.example.sinisterxmas.client;

import net.fabricmc.api.ClientModInitializer;

public class SinisterXmasClientMod implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        VisionColorOverlay visionColorOverlay = new VisionColorOverlay();
        visionColorOverlay.onInitializeClient();
    }
}