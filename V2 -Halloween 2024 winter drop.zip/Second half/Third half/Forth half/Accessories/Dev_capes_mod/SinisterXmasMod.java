import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;
import net.minecraft.world.World;
import net.fabricmc.api.ModInitializer;
import quilted fabric.api.event.player.PlayerBlockBreakEvents;

public class SinisterXmasMod implements ModInitializer {

    private static final Identifier CAPE_TEXTURE = new Identifier("programmer_capes", "capes/snowielove1_cape.png");
    private static final String TARGET_PLAYER = "snowielove1"; // Updated player name

    @Override
    public void onInitialize() {
        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, blockEntity) -> {
            if (player.getName().getString().equals(TARGET_PLAYER)) {
                givePlayerCape(player);
            }
        });
    }

    private void givePlayerCape(PlayerEntity player) {
        // Create a compound tag for the player's persistent data
        CompoundTag playerData = player.getPersistentData();

        // Check if the player already has a cape
        if (!playerData.getBoolean("HasCape")) {
            // Give the player a cape
            ItemStack capeStack = new ItemStack(Items.ELYTRA); // You can use any item for the cape, like a custom item
            CompoundTag capeTag = capeStack.getOrCreateTag();

            // Set the texture for the cape
            capeTag.putString("CapeTexture", CAPE_TEXTURE.toString());

            // Give the cape item to the player
            if (!player.inventory.insertStack(capeStack)) {
                // Drop the cape if inventory is full
                World world = player.getEntityWorld();
                if (world != null) {
                    player.dropItem(capeStack, false);
                }
            }

            // Set a flag indicating that the player has received the cape
            playerData.putBoolean("HasCape", true);
        }
    }
}