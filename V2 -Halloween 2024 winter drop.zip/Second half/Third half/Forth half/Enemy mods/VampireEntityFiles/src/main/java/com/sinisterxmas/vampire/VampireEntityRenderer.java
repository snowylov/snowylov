
package com.sinisterxmas.vampire;

import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.util.Identifier;

public class VampireEntityRenderer extends MobEntityRenderer<VampireEntity, VampireEntityModel<VampireEntity>> {

    public VampireEntityRenderer(EntityRendererFactory.Context context) {
        super(context, new VampireEntityModel<>(context.getPart(VampireEntityModel.LAYER)), 0.5f);
    }

    @Override
    public Identifier getTexture(VampireEntity entity) {
        return new Identifier("sinisterxmas", "textures/entity/vampire/" + entity.getSkinType());
    }
}
