
package com.sinisterxmas.vampire;

import net.minecraft.block.Blocks;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ToolItem;
import net.minecraft.item.SwordItem;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.EnumSet;
import java.util.List;
import java.util.Random;

public class VampireEntity extends PathAwareEntity {

    private final String skinType;
    private static final String[] SKIN_TYPES = {
        "vampire_skin_1.png",
        "vampire_skin_2.png",
        "vampire_skin_3.png",
        "vampire_skin_4.png",
        "vampire_skin_5.png"
    };

    public VampireEntity(EntityType<? extends PathAwareEntity> entityType, World world) {
        super(entityType, world);
        this.skinType = SKIN_TYPES[new Random().nextInt(SKIN_TYPES.length)];
        
        // Add goals
        this.goalSelector.add(1, new FollowPlayerGoal(this, 1.0D, 10.0F, 2.0F));
        this.goalSelector.add(2, new BreakBlocksGoal(this));
        this.goalSelector.add(3, new AttackCreativePlayerGoal(this));
        this.goalSelector.add(4, new NerdPoleGoal(this));
        this.goalSelector.add(5, new BridgeToTargetGoal(this));
        this.goalSelector.add(6, new SprintTowardsTargetGoal(this));
        this.goalSelector.add(7, new FleeWhenLowHealthGoal(this, 2.0D, 20.0F, 1.0F));
        this.goalSelector.add(8, new RegainHealthGoal(this));
        this.goalSelector.add(9, new HideFromSunGoal(this));
        this.goalSelector.add(10, new GroupRoamingGoal(this));
        this.goalSelector.add(11, new PickUpEquipmentGoal(this));
        this.goalSelector.add(12, new AdvancedAIGoal1(this));
        this.goalSelector.add(13, new AdvancedAIGoal2(this));
        this.goalSelector.add(14, new AdvancedAIGoal3(this));
        this.goalSelector.add(15, new AdvancedAIGoal4(this));
        this.goalSelector.add(16, new AdvancedAIGoal5(this));
        this.goalSelector.add(17, new AdvancedAIGoal6(this));
        this.goalSelector.add(18, new AdvancedAIGoal7(this));
        this.goalSelector.add(19, new AdvancedAIGoal8(this));
    }

    @Override
    public Identifier getTexture() {
        return new Identifier("sinisterxmas", "textures/entity/" + this.skinType);
    }

    static class PickUpEquipmentGoal extends Goal {
        private final PathAwareEntity mob;

        public PickUpEquipmentGoal(PathAwareEntity mob) {
            this.mob = mob;
            this.setControls(EnumSet.of(Control.MOVE, Control.LOOK));
        }

        @Override
        public boolean canStart() {
            List<ItemEntity> items = this.mob.world.getEntitiesByClass(ItemEntity.class, this.mob.getBoundingBox().expand(8.0D), (item) -> true);
            return !items.isEmpty();
        }

        @Override
        public void start() {
            List<ItemEntity> items = this.mob.world.getEntitiesByClass(ItemEntity.class, this.mob.getBoundingBox().expand(8.0D), (item) -> true);
            for (ItemEntity itemEntity : items) {
                this.mob.getNavigation().startMovingTo(itemEntity, 1.0D);
            }
        }

        @Override
        public void tick() {
            List<ItemEntity> items = this.mob.world.getEntitiesByClass(ItemEntity.class, this.mob.getBoundingBox().expand(2.0D), (item) -> true);
            for (ItemEntity itemEntity : items) {
                ItemStack stack = itemEntity.getStack();
                if (stack.getItem() instanceof ArmorItem) {
                    this.mob.equipStack(((ArmorItem) stack.getItem()).getSlotType(), stack);
                } else if (stack.getItem() instanceof ToolItem || stack.getItem() instanceof SwordItem) {
                    this.mob.equipStack(EquipmentSlot.MAINHAND, stack);
                }
                itemEntity.remove(RemovalReason.DISCARDED);
            }
        }
    }

    @Override
    public void tick() {
        super.tick();
        if (this.world.isDay() && this.world.getLightLevel(this.getBlockPos()) > 8) {
            this.setOnFireFor(8);
        }
    }
}
