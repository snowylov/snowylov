package com.sinisterxmas.items;

import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class TrifidProteinItem extends Item {

    public TrifidProteinItem() {
        super(new FabricItemSettings().maxCount(1));
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext context) {
        World world = context.getWorld();
        BlockPos pos = context.getBlockPos();

        if (!world.isClient()) {
            spawnGreenDustParticles(world, pos);
            world.playSound(null, pos, SoundEvents.ENTITY_GENERIC_EAT, SoundCategory.PLAYERS, 1.0F, 1.0F);
        }

        return ActionResult.SUCCESS;
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        return new TypedActionResult<>(ActionResult.SUCCESS, stack);
    }

    @Override
    public ActionResult useOnEntity(ItemStack stack, PlayerEntity player, LivingEntity entity, Hand hand) {
        if (!player.world.isClient && entity instanceof PassiveEntity) {
            PassiveEntity passiveEntity = (PassiveEntity) entity;

            // Make the entity aggressive
            passiveEntity.targetSelector.add(0, new AggressiveTargetGoal(passiveEntity));

            // Spawn green dust particles
            spawnGreenDustParticles((ServerWorld) player.world, entity.getBlockPos());

            // Play sound
            player.world.playSound(null, entity.getBlockPos(), SoundEvents.ENTITY_GENERIC_EAT, SoundCategory.PLAYERS, 1.0F, 1.0F);

            stack.decrement(1); // Consume one item from the stack
            return ActionResult.SUCCESS;
        }
        return ActionResult.PASS;
    }

    private void spawnGreenDustParticles(World world, BlockPos pos) {
        if (world instanceof ServerWorld) {
            DustParticleEffect dustParticle = new DustParticleEffect(0.0f, 1.0f, 0.0f, 1.0f);
            ((ServerWorld) world).spawnParticles(dustParticle, pos.getX() + 0.5, pos.getY() + 1, pos.getZ() + 0.5, 5, 0.5, 0.5, 0.5, 0.0);
        }
    }

    public static class AggressiveTargetGoal extends ActiveTargetGoal<LivingEntity> {

        public AggressiveTargetGoal(MobEntity mob) {
            super(mob, LivingEntity.class, true);
        }

        @Override
        public boolean canStart() {
            return super.canStart() && (this.target instanceof VillagerEntity || this.target instanceof PassiveEntity);
        }
    }
}