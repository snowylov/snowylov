package com.sinisterxmas.items;

import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.minecraft.item.Item;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

public class TriffidItems {

DefaultParticleType myParticleType = ParticleMaker.registerCustomParticle("sinisterxmas", "green_acid_spit.png", "green_acid_spit");

    // Define the Triffid Heart item
    public static final Item TRIFFID_HEART = new TriffidHeartItem();

    // Define the Triffid Protein item
    public static final Item TRIFID_PROTEIN = new TrifidProteinItem();

    // Register the Triffid items
    public static void registerItems() {
        // Register Triffid Heart
        Registry.register(Registry.ITEM, new Identifier("sinisterxmas", "triffid_heart"), TRIFFID_HEART);

        // Register Triffid Protein
        Registry.register(Registry.ITEM, new Identifier("sinisterxmas", "triffid_protein"), TRIFID_PROTEIN);
    }
}