import net.minecraft.potion.Potion;
import net.minecraft.potion.Potions;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.recipe.BrewingRecipeRegistry;

public class ModPotions {

    public static final Potion DRUID_POTION = Registry.register(Registry.POTION, new Identifier("sinisterxmas", "druid_potion"), new Potion(new StatusEffectInstance(StatusEffects.POISON, 16 * 20, 4)));
    public static final Potion REGENERATION_DRUID_POTION = Registry.register(Registry.POTION, new Identifier("sinisterxmas", "regeneration_druid_potion"), new Potion(new StatusEffectInstance(StatusEffects.REGENERATION, 16 * 20, 4)));
    public static final Potion WEAKNESS_DRUID_POTION = Registry.register(Registry.POTION, new Identifier("sinisterxmas", "weakness_druid_potion"), new Potion(new StatusEffectInstance(StatusEffects.WEAKNESS, 16 * 20, 4)));
    public static final Potion STRENGTH_DRUID_POTION = Registry.register(Registry.POTION, new Identifier("sinisterxmas", "strength_druid_potion"), new Potion(new StatusEffectInstance(StatusEffects.STRENGTH, 16 * 20, 4)));
    public static final Potion SPARKLE_TRAIL_POTION = Registry.register(Registry.POTION, new Identifier("sinisterxmas", "sparkle_trail_potion"), new Potion(new StatusEffectInstance(SparkleTrailEffect.INSTANCE, 16 * 20)));
    public static final Potion DRUID_BLOOD_POTION = Registry.register(Registry.POTION, new Identifier("sinisterxmas", "druid_blood_potion"), new Potion(new StatusEffectInstance(DruidBloodEffect.INSTANCE, 16 * 20)));

    static {
        if (DruidPotionsConfig.shouldActivatePotions()) {
            BrewingRecipeRegistry.registerPotionRecipe(Potions.POISON, TriffidItems.TRIFFID_PROTEIN, ModPotions.DRUID_POTION);
            BrewingRecipeRegistry.registerPotionRecipe(Potions.HEALING, TriffidItems.TRIFFID_PROTEIN, ModPotions.REGENERATION_DRUID_POTION);
            BrewingRecipeRegistry.registerPotionRecipe(Potions.WEAKNESS, TriffidItems.TRIFFID_PROTEIN, ModPotions.WEAKNESS_DRUID_POTION);
            BrewingRecipeRegistry.registerPotionRecipe(Potions.STRENGTH, TriffidItems.TRIFFID_PROTEIN, ModPotions.STRENGTH_DRUID_POTION);
            BrewingRecipeRegistry.registerPotionRecipe(Potions.AWKWARD, TriffidItems.TRIFFID_HEART, ModPotions.DRUID_BLOOD_POTION);
            BrewingRecipeRegistry.registerPotionRecipe(Potions.AWKWARD, TriffidItems.TRIFFID_HEART, ModPotions.SPARKLE_TRAIL_POTION);
        }
    }
}