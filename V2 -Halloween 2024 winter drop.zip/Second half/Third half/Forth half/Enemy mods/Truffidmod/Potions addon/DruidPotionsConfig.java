package com.sinisterxmas.config;

import net.fabricmc.loader.api.FabricLoader;
import java.io.*;

public class DruidPotionsConfig {

    private static final File configFile = new File(FabricLoader.getInstance().getConfigDir().toFile(), "DruidPotions/config.txt");
    private static boolean activatePotions = false;

    public static void initialize() {
        try {
            if (!configFile.exists()) {
                configFile.getParentFile().mkdirs();
                configFile.createNewFile();
                writeDefaultConfig();
            } else {
                readConfig();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void writeDefaultConfig() throws IOException {
        FileWriter writer = new FileWriter(configFile);
        writer.write("activate_potions=false");
        writer.close();
    }

    private static void readConfig() throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(configFile));
        String line = reader.readLine();
        while (line != null) {
            if (line.startsWith("activate_potions=")) {
                String value = line.substring("activate_potions=".length()).trim();
                activatePotions = Boolean.parseBoolean(value);
            }
            line = reader.readLine();
        }
        reader.close();
    }

    public static boolean shouldActivatePotions() {
        return activatePotions;
    }
}