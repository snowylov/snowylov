import net.minecraft.entity.LivingEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectType;
import net.minecraft.entity.effect.StatusEffectInstance;

public class SparkleTrailEffect extends StatusEffect {
    public static final SparkleTrailEffect INSTANCE = new SparkleTrailEffect();

    protected SparkleTrailEffect() {
        super(StatusEffectType.NEUTRAL, 0xFFFFFF); // White color
    }

    @Override
    public void onApplied(LivingEntity entity, StatusEffectInstance instance, int amplifier) {
        super.onApplied(entity, instance, amplifier);
    }

    @Override
    public void onRemoved(LivingEntity entity, StatusEffectInstance instance, int amplifier) {
        super.onRemoved(entity, instance, amplifier);
    }

    @Override
    public void onScheduledTick(LivingEntity entity, StatusEffectInstance instance) {
        if (!entity.world.isClient()) {
            entity.world.spawnParticles(ParticleTypes.GLOW_SQUID_INK, entity.getX(), entity.getY(), entity.getZ(), 1, 0, 0, 0, 0.0);
        }
    }
}