import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectType;
import net.minecraft.entity.attribute.AttributeContainer;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.attribute.EntityAttributeModifier.Operation;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.LivingEntity;

import java.util.UUID;

public class DruidBloodEffect extends StatusEffect {
    public static final DruidBloodEffect INSTANCE = new DruidBloodEffect();
    private static final UUID HEALTH_MODIFIER_ID = UUID.fromString("b93bba84-7b50-4f61-a0a7-4c533ef221b2");
    private static final UUID SPEED_MODIFIER_ID = UUID.fromString("0d50ed2f-88b0-4f92-98ad-7e6690de1653");

    protected DruidBloodEffect() {
        super(StatusEffectType.BENEFICIAL, 0x7CFC00); // Hex color for green
    }

    @Override
    public void onApplied(LivingEntity entity, AttributeContainer attributes, int amplifier) {
        super.onApplied(entity, attributes, amplifier);
        applyModifiers(entity, amplifier);
    }

    @Override
    public void onRemoved(LivingEntity entity, AttributeContainer attributes, int amplifier) {
        super.onRemoved(entity, attributes, amplifier);
        removeModifiers(entity, amplifier);
    }

    private void applyModifiers(LivingEntity entity, int amplifier) {
        if (!entity.world.isClient()) {
            entity.getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH).addPersistentModifier(new EntityAttributeModifier(
                HEALTH_MODIFIER_ID, "Druid Blood Health Boost", 14 * amplifier, Operation.ADDITION
            ));
            entity.getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED).addPersistentModifier(new EntityAttributeModifier(
                SPEED_MODIFIER_ID, "Druid Blood Speed Boost", 0.1 * amplifier, Operation.ADDITION
            ));
        }
    }

    private void removeModifiers(LivingEntity entity, int amplifier) {
        if (!entity.world.isClient()) {
            entity.getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH).removeModifier(HEALTH_MODIFIER_ID);
            entity.getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED).removeModifier(SPEED_MODIFIER_ID);
        }
    }
}