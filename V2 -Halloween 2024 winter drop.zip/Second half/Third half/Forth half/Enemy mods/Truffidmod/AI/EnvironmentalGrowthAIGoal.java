package com.sinisterxmas.entity;

import net.minecraft.block.Blocks;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

public class EnvironmentalGrowthAIGoal extends Goal {
    private final TriffidEntity triffid;
    private int tickCooldown;

    public EnvironmentalGrowthAIGoal(TriffidEntity triffid) {
        this.triffid = triffid;
        this.tickCooldown = 0;
    }

    @Override
    public boolean canStart() {
        return this.triffid.getTarget() != null;
    }

    @Override
    public void tick() {
        if (--tickCooldown <= 0) {
            ServerWorld world = (ServerWorld) this.triffid.world;
            BlockPos pos = this.triffid.getBlockPos();

            growVines(world, pos);
            growTrees(world, pos);
            growLeaves(world, pos);
            turnBlocksToMoss(world, pos);

            // Reset the cooldown to 100 ticks (5 seconds)
            tickCooldown = 100;
        }
    }

    private void growVines(ServerWorld world, BlockPos pos) {
        BlockPos.Mutable mutable = new BlockPos.Mutable();
        for (Direction direction : Direction.values()) {
            BlockPos checkPos = pos.offset(direction);
            if (world.getBlockState(checkPos).isAir() && world.getBlockState(checkPos.offset(direction.getOpposite())).isSideSolidFullSquare(world, checkPos, direction)) {
                world.setBlockState(checkPos, Blocks.VINE.getDefaultState().with(Properties.HORIZONTAL_FACING, direction));
            }
        }
    }

    private void growTrees(ServerWorld world, BlockPos pos) {
        for (int dx = -3; dx <= 3; dx++) {
            for (int dz = -3; dz <= 3; dz++) {
                BlockPos checkPos = pos.add(dx, 0, dz);
                if (world.getBlockState(checkPos).getBlock() == Blocks.GRASS_BLOCK || world.getBlockState(checkPos).getBlock() == Blocks.DIRT) {
                    world.setBlockState(checkPos.up(), Blocks.OAK_SAPLING.getDefaultState());
                }
            }
        }
    }

    private void growLeaves(ServerWorld world, BlockPos pos) {
        BlockPos.Mutable mutable = new BlockPos.Mutable();
        for (Direction direction : Direction.values()) {
            BlockPos checkPos = pos.offset(direction);
            if (world.getBlockState(checkPos).getBlock() == Blocks.OAK_LOG || 
                world.getBlockState(checkPos).getBlock() == Blocks.OAK_PLANKS || 
                world.getBlockState(checkPos).getBlock() == Blocks.CRAFTING_TABLE) {
                world.setBlockState(checkPos.offset(direction), Blocks.OAK_LEAVES.getDefaultState());
            }
        }
    }

    private void turnBlocksToMoss(ServerWorld world, BlockPos pos) {
        BlockPos.Mutable mutable = new BlockPos.Mutable();
        for (Direction direction : Direction.values()) {
            BlockPos checkPos = pos.offset(direction);
            if (world.getBlockState(checkPos).getBlock() == Blocks.COBBLESTONE || 
                world.getBlockState(checkPos).getBlock() == Blocks.STONE || 
                world.getBlockState(checkPos).getBlock() == Blocks.BRICKS || 
                world.getBlockState(checkPos).getBlock() == Blocks.NETHER_BRICKS) {
                world.setBlockState(checkPos, Blocks.MOSSY_COBBLESTONE.getDefaultState());
            }
        }
    }
}