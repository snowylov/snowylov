package com.example.mod;

import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.BlockState;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class CrackedTransformationTask {

    public static void transformNearbyBlocks(ZombieEntity entity) {
        World world = entity.getWorld();
        BlockPos entityPos = entity.getBlockPos();
        int radius = 5; // Define the radius around the mob to check for blocks

        for (BlockPos pos : BlockPos.iterate(entityPos.add(-radius, -1, -radius), entityPos.add(radius, 1, radius))) {
            if (!world.isAir(pos)) {
                transformBlock(world, pos);
            }
        }
    }

    private static void transformBlock(World world, BlockPos pos) {
        BlockState state = world.getBlockState(pos);
        Block block = state.getBlock();

        if (block == Blocks.STONE_BRICKS) {
            world.setBlockState(pos, Blocks.CRACKED_STONE_BRICKS.getDefaultState());
        } else if (block == Blocks.BLACKSTONE) {
            world.setBlockState(pos, Blocks.CRACKED_POLISHED_BLACKSTONE_BRICKS.getDefaultState());
        } else if (block == Blocks.NETHER_BRICKS) {
            world.setBlockState(pos, Blocks.CRACKED_NETHER_BRICKS.getDefaultState());
        }
    }
}