package com.sinisterxmas.items;

import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

public class TriffidHeartItem extends Item {

    public TriffidHeartItem() {
        super(new FabricItemSettings().maxCount(1));
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        ItemStack shearsStack = new ItemStack(net.minecraft.item.Items.SHEARS);
        
        if (!world.isClient && user.inventory.contains(shearsStack)) {
            user.inventory.insertStack(new ItemStack(SinisterxmasMod.TRIFID_PROTEIN));
            world.playSound(null, user.getX(), user.getY(), user.getZ(), SoundEvents.ITEM_SHEAR, SoundCategory.PLAYERS, 1.0F, 1.0F);
            stack.decrement(1); // Consume one item from the stack
            user.inventory.removeOne(shearsStack); // Remove one shear from inventory
        }
        
        return new TypedActionResult<>(ActionResult.SUCCESS, stack);
    }
}