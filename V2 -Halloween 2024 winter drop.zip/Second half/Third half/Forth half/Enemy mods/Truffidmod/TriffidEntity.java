package com.sinisterxmas.entity;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.block.Blocks;
import net.minecraft.block.BlockState;
import net.minecraft.server.world.ServerWorld;

import java.util.Random;

public class TriffidEntity extends HostileEntity {

    private static final Random random = new Random();
    private static final int DAMAGE_COOLDOWN = 800; // 40 seconds in ticks
    private static final int DAMAGE_ON_FIRE_COOLDOWN = 600; // 30 seconds in ticks
    private static final int DAMAGE_LIMIT = 20;
    private static final int ATTACK_DAMAGE = 10;
    private static final float ATTACK_REACH = 5.0f;

    public TriffidEntity(EntityType<? extends HostileEntity> entityType, World world) {
        super(entityType, world);
    }

    @Override
    protected void dropLoot(DamageSource source, boolean causedByPlayer) {
        super.dropLoot(source, causedByPlayer);
        if (causedByPlayer) {
            this.dropItem(TriffidItems.TRIFFID_HEART);
        }
    }

    public static DefaultAttributeContainer.Builder createTriffidAttributes() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 220.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.0)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 16.0)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 100.0);
    }

    @Override
    protected void initGoals() {
        // Add attack goal
        this.goalSelector.add(1, new TriffidAttackGoal(this, ATTACK_DAMAGE, ATTACK_REACH));

        // Add special attack goal
        this.goalSelector.add(2, new TriffidSpecialAttackGoal(this));
    }

    private int getDamageCooldown() {
        return this.isOnFire() ? DAMAGE_ON_FIRE_COOLDOWN : DAMAGE_COOLDOWN;
    }

    private boolean canTakeDamage() {
        return this.age >= this.getDamageCooldown();
    }

    @Override
    public void damage(DamageSource source, float amount) {
        if (this.canTakeDamage()) {
            super.damage(source, Math.min(amount, DAMAGE_LIMIT));
            this.age = 0; // Reset damage cooldown
        }
    }

    private static class TriffidAttackGoal extends MeleeAttackGoal {
        public TriffidAttackGoal(TriffidEntity entity, double speed, boolean pauseWhenMobIdle) {
            super(entity, speed, pauseWhenMobIdle);
        }

        @Override
        public boolean canStart() {
            return super.canStart() && this.mob.getTarget() instanceof PlayerEntity;
        }
    }

    private static class TriffidSpecialAttackGoal extends Goal {
        private final TriffidEntity triffid;

        public TriffidSpecialAttackGoal(TriffidEntity triffid) {
            this.triffid = triffid;
        }

        @Override
        public boolean canStart() {
            return this.triffid.getTarget() != null && random.nextInt(100) < 5; // 5% chance
        }

        @Override
        public void tick() {
            PlayerEntity target = (PlayerEntity) this.triffid.getTarget();
            if (target == null) return;

            World world = this.triffid.world;
            BlockPos pos = target.getBlockPos();

            // Place cactus in a checkerboard pattern around the player
            for (int x = -3; x <= 3; x++) {
                for (int z = -3; z <= 3; z++) {
                    if ((x + z) % 2 == 0) {
                        world.setBlockState(pos.add(x, 0, z), Blocks.CACTUS.getDefaultState());
                    }
                }
            }

            // Environmental growth AI
            growVines(world, pos);
            growTrees(world, pos);
            growLeaves(world, pos);
            turnBlocksToMoss(world, pos);
        }

        private void growVines(World world, BlockPos pos) {
            if (world instanceof ServerWorld) {
                BlockPos.Mutable mutable = new BlockPos.Mutable();
                for (Direction direction : Direction.values()) {
                    BlockPos checkPos = pos.offset(direction);
                    if (world.getBlockState(checkPos).isAir() && world.getBlockState(checkPos.offset(direction.getOpposite())).isSideSolidFullSquare(world, checkPos, direction)) {
                        world.setBlockState(checkPos, Blocks.VINE.getDefaultState().with(Properties.HORIZONTAL_FACING, direction));
                    }
                }
            }
        }

        private void growTrees(World world, BlockPos pos) {
            if (world instanceof ServerWorld) {
                for (int dx = -3; dx <= 3; dx++) {
                    for (int dz = -3; dz <= 3; dz++) {
                        BlockPos checkPos = pos.add(dx, 0, dz);
                        BlockState state = world.getBlockState(checkPos);
                        if (state.getBlock() == Blocks.GRASS_BLOCK || state.getBlock() == Blocks.DIRT) {
                            world.setBlockState(checkPos.up(), Blocks.OAK_SAPLING.getDefaultState());
                        }
                    }
                }
            }
        }

        private void growLeaves(World world, BlockPos pos) {
            if (world instanceof ServerWorld) {
                BlockPos.Mutable mutable = new BlockPos.Mutable();
                for (Direction direction : Direction.values()) {
                    BlockPos checkPos = pos.offset(direction);
                    BlockState state = world.getBlockState(checkPos);
                    if (state.getBlock() == Blocks.OAK_LOG || 
                        state.getBlock() == Blocks.OAK_PLANKS || 
                        state.getBlock() == Blocks.CRAFTING_TABLE) {
                        world.setBlockState(checkPos.offset(direction), Blocks.OAK_LEAVES.getDefaultState());
                    }
                }
            }
        }

        private void turnBlocksToMoss(World world, BlockPos pos) {
            if (world instanceof ServerWorld) {
                BlockPos.Mutable mutable = new BlockPos.Mutable();
                for (Direction direction : Direction.values()) {
                    BlockPos checkPos = pos.offset(direction);
                    BlockState state = world.getBlockState(checkPos);
                    if (state.getBlock() == Blocks.COBBLESTONE || 
                        state.getBlock() == Blocks.STONE || 
                        state.getBlock() == Blocks.BRICKS || 
                        state.getBlock() == Blocks.NETHER_BRICKS) {
                        world.setBlockState(checkPos, Blocks.MOSSY_COBBLESTONE.getDefaultState());
                    }
                }
            }
        }
    }
}