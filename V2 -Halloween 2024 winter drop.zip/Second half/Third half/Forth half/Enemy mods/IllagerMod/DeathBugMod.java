package com.deathbug;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerEntityWorldChangeEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.fabricmc.fabric.api.registry.BiomeModifications;
import net.fabricmc.fabric.api.registry.BiomeSelectors;
import net.fabricmc.fabric.api.datagen.v1.FabricDataGenerator;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricAdvancementProvider;
import net.minecraft.advancement.Advancement;
import net.minecraft.advancement.AdvancementFrame;
import net.minecraft.advancement.AdvancementRewards;
import net.minecraft.advancement.criterion.EntityKilledCriterion;
import net.minecraft.block.*;
import net.minecraft.client.render.entity.EntityRendererRegistry;
import net.minecraft.client.render.entity.EvokerEntityRenderer;
import net.minecraft.client.render.entity.PillagerEntityRenderer;
import net.minecraft.entity.*;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.IllagerEntity;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.raid.RaiderEntity;
import net.minecraft.entity.raid.Raid;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.registry.Registry;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.biome.Biome.Category;

import java.util.Random;

public class DeathBugMod implements ModInitializer {

    public static final String MODID = "deathbug";
    public static final EntityType<TerroristIllager> TERRORIST_ILLAGER = Registry.register(
            Registry.ENTITY_TYPE,
            new Identifier(MODID, "terrorist_illager"),
            FabricEntityTypeBuilder.create(SpawnGroup.MONSTER, TerroristIllager::new)
                    .dimensions(EntityType.EVOKER.getDimensions())
                    .build()
    );

    public static final EntityType<PirateIllager> PIRATE_ILLAGER = Registry.register(
            Registry.ENTITY_TYPE,
            new Identifier(MODID, "pirate_illager"),
            FabricEntityTypeBuilder.create(SpawnGroup.MONSTER, PirateIllager::new)
                    .dimensions(EntityType.PILLAGER.getDimensions())
                    .build()
    );

    @Override
    public void onInitialize() {
        FabricDefaultAttributeRegistry.register(TERRORIST_ILLAGER, TerroristIllager.createTerroristIllagerAttributes());
        FabricDefaultAttributeRegistry.register(PIRATE_ILLAGER, PirateIllager.createPirateIllagerAttributes());

        ServerEntityWorldChangeEvents.AFTER_PLAYER_CHANGE_WORLD.register((entity, origin, destination) -> {
            if (entity instanceof TerroristIllager && !entity.world.isClient) {
                if (destination.getRegistryKey().equals(World.NETHER)) {
                    entity.kill();
                } else if (origin.getRegistryKey().equals(World.OVERWORLD) && !isInMesaBiome((TerroristIllager) entity)) {
                    teleportBackToMesa((TerroristIllager) entity);
                }
            }
        });

        BiomeModifications.addSpawn(
                BiomeSelectors.categories(Category.MESA),
                SpawnGroup.MONSTER,
                TERRORIST_ILLAGER,
                1, 1, 1
        );

        BiomeModifications.addSpawn(
                BiomeSelectors.categories(Category.OCEAN, Category.BEACH),
                SpawnGroup.MONSTER,
                PIRATE_ILLAGER,
                10, 2, 4
        );
    }

    private static boolean isInMesaBiome(TerroristIllager entity) {
        Biome biome = entity.world.getBiome(entity.getBlockPos());
        return biome.getCategory() == Category.MESA;
    }

    private static void teleportBackToMesa(TerroristIllager entity) {
        BlockPos pos = entity.world.locateBiome(biome -> biome.getCategory() == Category.MESA, entity.getBlockPos(), 10000, 8);
        if (pos != null) {
            entity.teleport(pos.getX(), pos.getY(), pos.getZ());
        } else {
            entity.kill();
        }
    }

    public static class TerroristIllager extends IllagerEntity {

        public TerroristIllager(EntityType<? extends IllagerEntity> entityType, World world) {
            super(entityType, world);
        }

        public static DefaultAttributeContainer.Builder createTerroristIllagerAttributes() {
            return IllagerEntity.createIllagerAttributes()
                    .add(EntityAttributes.GENERIC_MAX_HEALTH, 40.0)
                    .add(EntityAttributes.GENERIC_ARMOR, 8.0)
                    .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 9.0)
                    .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.35);
        }

        @Override
        protected void initGoals() {
            this.goalSelector.add(0, new SwimGoal(this));
            this.goalSelector.add(1, new MeleeAttackGoal(this, 1.0D, false));
            this.goalSelector.add(2, new OpenDoorGoal(this, true));
            this.goalSelector.add(3, new CloseDoorGoal(this));
            this.goalSelector.add(4, new ClimbLadderGoal(this));
            this.goalSelector.add(5, new LookAtEntityGoal(this, PlayerEntity.class, 8.0F));
            this.goalSelector.add(6, new WanderAroundGoal(this, 1.0D));
            this.goalSelector.add(7, new HideFromPlayerGoal(this));
            this.goalSelector.add(8, new BreakAndLootGoal(this));
            this.goalSelector.add(9, new PlaceTntAndRunGoal(this));
        }

        @Override
        public void tick() {
            super.tick();
            if (!this.world.isClient && this.world.getDifficulty().getId() < 2) { // Avoid spawning on Easy or Peaceful difficulty
                this.discard();
            }
            if (this.world.isDay()) {
                this.setInvisible(true);
                this.setTarget(null);  // Prevent attacking during the day
            } else {
                this.setInvisible(false);
            }
        }

        @Override
        public boolean tryAttack(Entity target) {
            if (target instanceof PlayerEntity) {
                this.playSound(SoundEvents.ENTITY_ILLUSIONER_CAST_SPELL, 1.0F, 1.0F);
                return super.tryAttack(target);
            }
            return false;
        }

        @Override
        public ItemStack getPickBlockStack() {
            return new ItemStack(Items.IRON_SWORD);
        }

        @Override
        protected void dropLoot(DamageSource source, boolean causedByPlayer) {
            super.dropLoot(source, causedByPlayer);
            this.dropItem(Items.IRON_SWORD);
        }
    }

    public static class PirateIllager extends IllagerEntity {

        private BlockPos spawnPos;

        public PirateIllager(EntityType<? extends IllagerEntity> entityType, World world) {
            super(entityType, world);
            this.spawnPos = this.getBlockPos();
        }

        public static DefaultAttributeContainer.Builder createPirateIllagerAttributes() {
            return IllagerEntity.createIllagerAttributes()
                    .add(EntityAttributes.GENERIC_MAX_HEALTH, 30.0)
                    .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.25);
        }

        @Override
        protected void initGoals() {
            this.goalSelector.add(0, new SwimGoal(this));
            this.goalSelector.add(1, new LootChestGoal(this));
            this.goalSelector.add(2, new ReturnToSpawnGoal(this));
            this.goalSelector.add(3, new MeleeAttackGoal(this, 1.0D, false));
            this.goalSelector.add(4, new LookAtEntityGoal(this, PlayerEntity.class, 8.0F));
            this.goalSelector.add(5, new WanderAroundGoal(this, 1.0D));
            this.goalSelector.add(6, new AlertIllagersGoal(this));
        }

        @Override
        public void tick() {
            super.tick();
            if (!this.world.isClient && this.world.getDifficulty().getId() < 2) { // Avoid spawning on Easy or Peaceful difficulty
                this.discard();
            }
        }

        @Override
        public boolean tryAttack(Entity target) {
            if (target instanceof PlayerEntity) {
                this.playSound(SoundEvents.ENTITY_PILLAGER_AMBIENT, 1.0F, 1.0F);
                return super.tryAttack(target);
            }
            return false;
        }

        @Override
        public ItemStack getPickBlockStack() {
            return new ItemStack(Items.IRON_SWORD);
        }

        @Override
        protected void dropLoot(DamageSource source, boolean causedByPlayer) {
            super.dropLoot(source, causedByPlayer);
            this.dropInventory();
        }
    }

    public static class CloseDoorGoal extends Goal {
        private final PathAwareEntity entity;

        public CloseDoorGoal(PathAware Entity entity) {
            this.entity = entity;
        }

        @Override
        public boolean canStart() {
            return this.entity.getNavigation().isIdle() && this.entity.hasEnteredOpenDoor();
        }

        @Override
        public void start() {
            BlockPos blockPos = this.entity.getBlockPos().down();
            this.entity.world.setBlockState(blockPos, this.entity.world.getBlockState(blockPos).with(DoorBlock.OPEN, false));
        }
    }

    public static class ClimbLadderGoal extends Goal {
        private final PathAwareEntity entity;

        public ClimbLadderGoal(PathAwareEntity entity) {
            this.entity = entity;
        }

        @Override
        public boolean canStart() {
            return this.entity.isOnLadder();
        }

        @Override
        public void start() {
            this.entity.getNavigation().startMovingTo(this.entity.getPos().up(), 1.0D);
        }
    }

    public static class HideFromPlayerGoal extends Goal {
        private final PathAwareEntity entity;

        public HideFromPlayerGoal(PathAwareEntity entity) {
            this.entity = entity;
        }

        @Override
        public boolean canStart() {
            PlayerEntity player = this.entity.world.getClosestPlayer(this.entity, 8.0D);
            return player != null && this.entity.canSee(player);
        }

        @Override
        public void start() {
            this.entity.getNavigation().startMovingAwayFrom(this.entity.world.getClosestPlayer(this.entity, 8.0D), 1.0D);
        }
    }

    public static class BreakAndLootGoal extends Goal {
        private final PathAwareEntity entity;

        public BreakAndLootGoal(PathAwareEntity entity) {
            this.entity = entity;
        }

        @Override
        public boolean canStart() {
            return this.entity.world.getBiome(this.entity.getBlockPos()).getCategory() == Category.MESA;
        }

        @Override
        public void start() {
            BlockPos pos = this.entity.getBlockPos();
            for (int x = -2; x <= 2; x++) {
                for (int y = -2; y <= 2; y++) {
                    for (int z = -2; z <= 2; z++) {
                        BlockPos targetPos = pos.add(x, y, z);
                        BlockState state = this.entity.world.getBlockState(targetPos);
                        if (state.getBlock() instanceof BedBlock ||
                                state.getBlock() instanceof ChestBlock ||
                                state.getBlock() instanceof FurnaceBlock ||
                                state.getBlock() instanceof CraftingTableBlock ||
                                state.getBlock() instanceof BarrelBlock) {
                            this.entity.world.breakBlock(targetPos, true);
                            this.entity.world.spawnEntity(new ItemEntity(this.entity.world, targetPos.getX(), targetPos.getY(), targetPos.getZ(), new ItemStack(Items.AIR)));
                        }
                    }
                }
            }
        }
    }

    public static class PlaceTntAndRunGoal extends Goal {
        private final PathAwareEntity entity;

        public PlaceTntAndRunGoal(PathAwareEntity entity) {
            this.entity = entity;
        }

        @Override
        public boolean canStart() {
            return this.entity.world.getBiome(this.entity.getBlockPos()).getCategory() == Category.MESA;
        }

        @Override
        public void start() {
            BlockPos pos = this.entity.getBlockPos();
            for (int x = -2; x <= 2; x++) {
                for (int y = -2; y <= 2; y++) {
                    for (int z = -2; z <= 2; z++) {
                        BlockPos targetPos = pos.add(x, y, z);
                        BlockState state = this.entity.world.getBlockState(targetPos);
                        if (state.getBlock() instanceof ChestBlock) {
                            this.entity.world.setBlockState(targetPos.down(), Blocks.TNT.getDefaultState());
                            TNTEntity tnt = new TNTEntity(this.entity.world, targetPos.getX(), targetPos.getY(), targetPos.getZ(), null);
                            tnt.setFuse(1200);  // 1 minute fuse
                            this.entity.world.spawnEntity(tnt);
                            this.entity.getNavigation().startMovingAwayFrom(targetPos, 1.5D);
                        }
                    }
                }
            }
        }
    }

    public static class LootChestGoal extends Goal {
        private final PathAwareEntity entity;

        public LootChestGoal(PathAwareEntity entity) {
            this.entity = entity;
        }

        @Override
        public boolean canStart() {
            return this.entity.world.getBiome(this.entity.getBlockPos()).getCategory() == Category.OCEAN ||
                   this.entity.world.getBiome(this.entity.getBlockPos()).getCategory() == Category.BEACH;
        }

        @Override
        public void start() {
            BlockPos pos = this.entity.getBlockPos();
            for (int x = -2; x <= 2; x++) {
                for (int y = -2; y <= 2; y++) {
                    for (int z = -2; z <= 2; z++) {
                        BlockPos targetPos = pos.add(x, y, z);
                        BlockState state = this.entity.world.getBlockState(targetPos);
                        if (state.getBlock() instanceof ChestBlock || state.getBlock() instanceof BarrelBlock) {
                            this.entity.world.breakBlock(targetPos, true);
                            this.entity.getNavigation().startMovingTo(targetPos, 1.5D);
                        }
                    }
                }
            }
        }

        @Override
        public void tick() {
            if (this.entity.getNavigation().isIdle()) {
                BlockPos pos = this.entity.getBlockPos();
                for (int x = -2; x <= 2; x++) {
                    for (int y = -2; y <= 2; y++) {
                        for (int z = -2; z <= 2; z++) {
                            BlockPos targetPos = pos.add(x, y, z);
                            BlockState state = this.entity.world.getBlockState(targetPos);
                            if (state.getBlock() instanceof ChestBlock || state.getBlock() instanceof BarrelBlock) {
                                this.entity.world.breakBlock(targetPos, true);
                                this.entity.world.spawnEntity(new ItemEntity(this.entity.world, targetPos.getX(), targetPos.getY(), targetPos.getZ(), new ItemStack(Items.AIR)));
                                this.entity.getNavigation().startMovingTo(this.entity.spawnPos, 1.5D);
                            }
                        }
                    }
                }
            }
        }
    }

    public static class ReturnToSpawnGoal extends Goal {
        private final PathAwareEntity entity;

        public ReturnToSpawnGoal(PathAwareEntity entity) {
            this.entity = entity;
        }

        @Override
        public boolean canStart() {
            return this.entity.getNavigation().isIdle();
        }

        @Override
        public void start() {
            this.entity.getNavigation().startMovingTo(this.entity.spawnPos, 1.0D);
        }
    }

    public static class AlertIllagersGoal extends Goal {
        private final PirateIllager entity;

        public AlertIllagersGoal(PirateIllager entity) {
            this.entity = entity;
        }

        @Override
        public boolean canStart() {
            PlayerEntity player = this.entity.world.getClosestPlayer(this.entity, 48.0D);
            return player != null && this.entity.canSee(player);
        }

        @Override
        public void start() {
            PlayerEntity player = this.entity.world.getClosestPlayer(this.entity, 48.0D);
            if (player != null) {
                this.entity.world.getEntitiesByType(EntityType.ILLAGER, new Box(player.getBlockPos()).expand(48.0D), e -> true).forEach(illager -> {
                    if (illager instanceof IllagerEntity) {
                        ((IllagerEntity) illager).setTarget(player);
                    }
                });
            }
        }
    }

    public static class DeathBugDataGenerator implements Runnable {

        @Override
        public void run() {
            FabricDataGenerator dataGenerator = new FabricDataGenerator();
            dataGenerator.addProvider(DeathBugAdvancementProvider::new);
            dataGenerator.run();
        }

        public static class DeathBugAdvancementProvider extends FabricAdvancementProvider {

            public DeathBugAdvancementProvider(FabricDataGenerator dataGenerator) {
                super(dataGenerator);
            }

            @Override
            protected void generateAdvancements() {
                Advancement killTerroristIllager = Advancement.Builder.create()
                        .display(
                                Registry.ITEM.getId(Items.IRON_SWORD),
                                Text.translatable("advancements.deathbug.kill_terrorist_illager.title"),
                                Text.translatable("advancements.deathbug.kill_terrorist_illager.description"),
                                new Identifier("textures/gui/advancements/backgrounds/adventure.png"),
                                AdvancementFrame.TASK,
                                true, true, false
                        )
                        .criterion("kill_terrorist_illager", EntityKilledCriterion.criterion(EntityType.PLAYER, EntityType.Builder.create().build(DeathBugMod.TERRORIST_ILLAGER)))
                        .rewards(AdvancementRewards.Builder.experience(100))
                        .build(new Identifier(DeathBugMod.MODID, "kill_terrorist_illager"));

                Advancement killFivePirateIllagers = Advancement.Builder.create()
                        .display(
                                Registry.ITEM.getId(Items.CROSSBOW),
                                Text.translatable("advancements.deathbug.kill_five_pirate_illagers.title"),
                                Text.translatable("advancements.deathbug.kill_five_pirate_illagers.description"),
                                new Identifier("textures/gui/advancements/backgrounds/adventure.png"),
                                AdvancementFrame.TASK,
                                true, true, false
                        )
                        .criterion("kill_five_pirate_illagers", EntityKilledCriterion.criterion(EntityType.PLAYER, EntityType.Builder.create().build(DeathBugMod.PIRATE_ILLAGER)))
.rewards(AdvancementRewards.Builder.experience(200))
.build(new Identifier(DeathBugMod.MODID, “kill_five_pirate_illagers”));

            dataGenerator.addAdvancement(killTerroristIllager);
            dataGenerator.addAdvancement(killFivePirateIllagers);
        }
    }
}

}