{
  "type": "minecraft:crafting_shaped",
  "pattern": [
    " G ",
    "GRG",
    " G "
  ],
  "key": {
    "G": {
      "item": "minecraft:copper_ingot"
    },
    "R": {
      "item": "witchhaven:red_petal"
    }
  },
  "result": {
    "item": "witchhaven:life_stone",
    "count": 1
  }
}