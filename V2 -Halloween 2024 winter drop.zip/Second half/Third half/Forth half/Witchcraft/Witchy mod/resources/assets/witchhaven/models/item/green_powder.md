{
  "parent": "item/generated",
  "textures": {
    "layer0": "witchhaven:item/green_powder"
  }
}