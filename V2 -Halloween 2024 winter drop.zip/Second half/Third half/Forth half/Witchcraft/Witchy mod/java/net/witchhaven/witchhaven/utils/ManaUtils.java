package net.witchhaven.witchhaven.util;

import net.minecraft.world.entity.player.Player;
import net.minecraft.nbt.CompoundTag;

public class ManaUtils {

    private static final String MANA_TAG = "ManaPoints";

    // Method to check if the player has enough mana
    public static boolean hasEnoughMana(Player player, int requiredMana) {
        CompoundTag playerData = player.getPersistentData();
        CompoundTag modData;

        // Check if our mod's data compound exists
        if (playerData.contains("WitchHavenModData", 10)) { // 10 is the tag type for CompoundTag
            modData = playerData.getCompound("WitchHavenModData");
        } else {
            modData = new CompoundTag();
        }

        int currentMana = modData.getInt(MANA_TAG);
        return currentMana >= requiredMana;
    }

    // Method to get player's current mana
    public static int getPlayerMana(Player player) {
        CompoundTag playerData = player.getPersistentData();
        CompoundTag modData = playerData.getCompound("WitchHavenModData");
        return modData.getInt(MANA_TAG);
    }

    // Method to set or update player's mana
    public static void setPlayerMana(Player player, int mana) {
        CompoundTag playerData = player.getPersistentData();
        CompoundTag modData;

        if (playerData.contains("WitchHavenModData", 10)) {
            modData = playerData.getCompound("WitchHavenModData");
        } else {
            modData = new CompoundTag();
        }

        modData.putInt(MANA_TAG, mana);
        playerData.put("WitchHavenModData", modData);
    }

    // Example method to add mana to a player
    public static void addMana(Player player, int manaToAdd) {
        int currentMana = getPlayerMana(player);
        setPlayerMana(player, currentMana + manaToAdd);
    }

    // Example method to consume mana
    public static void consumeMana(Player player, int manaToConsume) {
        if (hasEnoughMana(player, manaToConsume)) {
            int currentMana = getPlayerMana(player);
            setPlayerMana(player, currentMana - manaToConsume);
        }
    }
}