package net.witchhaven.witchhaven.item;

import net.minecraft.world.item.Item;

public class WhiteSageItem extends Item {
    public WhiteSageItem(Properties settings) {
        super(settings);
    }
}