package net.witchhaven.witchhaven.item;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import java.util.List;

public class SmudgeStickItem extends Item {
    public SmudgeStickItem(Properties settings) {
        super(settings);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level world, Player player, InteractionHand hand) {
        if (!world.isClientSide()) {
            // Define the search box dimensions
            double radius = 10.0; // 20x20 centered on the player requires a 10 block radius
            List<Entity> entities = world.getEntitiesOfClass(Entity.class, player.getBoundingBox().inflate(radius), e -> !(e instanceof Player));

            for (Entity entity : entities) {
                entity.remove(Entity.RemovalReason.KILLED); // Use the appropriate method to "kill" the entity
            }
            
            if (!player.isCreative()) {
                // Consume the smudge stick if the player is not in creative mode
                player.getItemInHand(hand).shrink(1);
            }
            
            return InteractionResultHolder.success(player.getItemInHand(hand));
        }
        return InteractionResultHolder.pass(player.getItemInHand(hand));
    }
}