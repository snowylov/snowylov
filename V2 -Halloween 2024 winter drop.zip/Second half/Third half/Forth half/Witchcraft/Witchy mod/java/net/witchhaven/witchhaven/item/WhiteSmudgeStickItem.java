package net.witchhaven.witchhaven.item;

import net.minecraft.world.item.Item;
import net.minecraft.world.entity.player.Player;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;

public class WhiteSmudgeStickItem extends Item {
    public WhiteSmudgeStickItem(Properties settings) {
        super(settings);
    }

    public static void inventoryTick(ItemStack stack, Level world, Entity entity, int slot, boolean selected) {
        if (!world.isClientSide && world.getGameTime() % 200 == 0) { // Every 10 seconds (200 ticks)
            if (entity instanceof ServerPlayer player) {
                player.heal(2.0F); // Heals 1 heart (2 half hearts)
                
                // Remove negative potion effects
                for (MobEffectInstance effectInstance : player.getActiveEffects()) {
                    if (effectInstance.getEffect().isBeneficial()) continue;
                    player.removeEffect(effectInstance.getEffect());
                }
            }
        }
    }
}