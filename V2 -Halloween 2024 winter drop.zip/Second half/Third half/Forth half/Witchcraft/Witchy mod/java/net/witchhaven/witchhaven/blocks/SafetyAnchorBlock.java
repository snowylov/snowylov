package net.witchhaven.witchhaven.block;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;

public class SafetyAnchorBlock extends Block {
    public SafetyAnchorBlock(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(BlockState state, Level world, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (!world.isClientSide) {
            // Drop the item
            popResource(world, pos, new ItemStack(this));
            // Remove the block
            world.removeBlock(pos, false);
            return InteractionResult.CONSUME;
        }
        return InteractionResult.SUCCESS;
    }

    @Override
    public void onPlaced(Level world, BlockPos pos, BlockState state, LivingEntity placer, ItemStack itemStack) {
        super.onPlaced(world, pos, state, placer, itemStack);
        if (!world.isClientSide) {
            AABB area = new AABB(pos).inflate(8); // Defines a 16x16x16 area centered on the block
            world.getEntitiesOfClass(LivingEntity.class, area, entity -> !(entity instanceof Player)).forEach(Entity::remove);
        }
    }
}