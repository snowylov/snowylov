package net.witchhaven.witchhaven.item;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.util.Mth;

public class LeapWandItem extends Item {
    public LeapWandItem(Properties settings) {
        super(settings);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level world, Player player, InteractionHand hand) {
        if (!world.isClientSide()) {
            // Calculate launch direction based on player's looking direction
            double pitch = Math.toRadians(player.getXRot()); // Convert to radians for trigonometric functions
            double yaw = Math.toRadians(player.getYRot());
            
            double x = -Math.sin(yaw) * Math.cos(pitch);
            double y = -Math.sin(pitch);
            double z = Math.cos(yaw) * Math.cos(pitch);
            
            // Normalize to maintain consistent speed regardless of look direction
            double magnitude = Math.sqrt(x * x + y * y + z * z);
            x /= magnitude;
            y /= magnitude;
            z /= magnitude;

            // Launch the player
            double launchVelocity = 2.0; // Adjust as needed for desired effect
            player.setDeltaMovement(x * launchVelocity, y * launchVelocity + 1, z * launchVelocity); // +1 to Y for a slight lift
            player.hasImpulse = true; // Ensures that the motion is applied immediately
            
            // Trigger cooldown to prevent spamming
            player.getCooldowns().addCooldown(this, 20 * 5); // 5 second cooldown
        }
        
        return InteractionResultHolder.success(player.getItemInHand(hand));
    }
}