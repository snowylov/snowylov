package net.witchhaven.witchhaven.item;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.level.Level;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.EntityType;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

public class MoonstoneItem extends Item {
    public MoonstoneItem(Properties settings) {
        super(settings);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level world, Player player, InteractionHand hand) {
        ItemStack itemStack = player.getItemInHand(hand);
        
        // Check for cooldown
        if (!player.getCooldowns().isOnCooldown(this)) {
            // Check if the player has a Scroll item in inventory
            boolean hasScroll = player.getInventory().contains(new ItemStack(WitchHavenMod.SCROLL_ITEM));
            if (hasScroll && !world.isClientSide()) {
                // Consume Scroll item
                ItemStack scrollStack = player.getInventory().getItem(player.getInventory().findSlotMatchingItem(new ItemStack(WitchHavenMod.SCROLL_ITEM)));
                scrollStack.shrink(1);
                
                // Summon mob logic
                summonMob(world, player);

                // Set cooldown
                player.getCooldowns().addCooldown(this, 75 * 20); // 75 seconds in ticks
                
                return InteractionResultHolder.success(itemStack);
            }
        }
        
        return InteractionResultHolder.fail(itemStack);
    }
    
    private void summonMob(Level world, Player player) {
        if (world instanceof ServerLevel) {
            EntityType<?> entityType = EntityType.ZOMBIE; // Example: Summon a zombie
            Entity entity = entityType.create((ServerLevel) world);
            if (entity instanceof Mob) {
                Vec3 playerPos = player.position();
                entity.setPos(playerPos.x, playerPos.y, playerPos.z);
                world.addFreshEntity(entity);
            }
        }
    }
}