package net.witchhaven.witchhaven.item;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;

public class TravelersTicketItem extends Item {
    public TravelersTicketItem(Properties settings) {
        super(settings);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level world, Player player, InteractionHand hand) {
        if (!world.isClientSide && !player.getCooldowns().isOnCooldown(this)) {
            // Apply the speed boost effect
            player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 120 * 20, 1)); // 120 seconds, Amplifier 1
            
            // Apply cooldown
            player.getCooldowns().addCooldown(this, 80 * 20); // 80 seconds
            
            // The item is not consumed, so no change to the item stack is needed
            return InteractionResultHolder.success(player.getItemInHand(hand));
        }
        return InteractionResultHolder.pass(player.getItemInHand(hand));
    }
}