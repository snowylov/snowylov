package net.witchhaven.witchhaven.item;

import net.minecraft.world.item.Item;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.level.Level;

public class MysticGuardianCharmItem extends Item {
    public MysticGuardianCharmItem(Properties properties) {
        super(properties);
    }

    @Override
    public void onEquipTick(ItemStack stack, Level world, Player player) {
        if (!world.isClientSide) {
            boolean isWearingArmor = player.getArmorSlots().anyMatch(itemStack -> !itemStack.isEmpty());
            if (player.getOffhandItem().getItem() instanceof MysticGuardianCharmItem && !isWearingArmor) {
                // Simulate armor effect; Minecraft doesn't directly support dynamic armor points.
                // You might add potion effects or attribute modifiers to simulate this protection.
                player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 10, 3, false, false, true));
                // Implement additional effects or attribute modifications to simulate armor toughness.
            }
        }
    }
}