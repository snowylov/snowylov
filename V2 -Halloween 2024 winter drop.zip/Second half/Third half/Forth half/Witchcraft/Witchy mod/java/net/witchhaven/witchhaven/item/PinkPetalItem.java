package net.witchhaven.witchhaven.item;

import net.minecraft.world.item.Item;

public class PinkPetalItem extends Item {
    public PinkPetalItem(Properties properties) {
        super(properties);
    }
}