package net.witchhaven.witchhaven.item;

import net.minecraft.world.item.Item;

public class ScrollItem extends Item {
    public ScrollItem(Properties settings) {
        super(settings);
    }
}