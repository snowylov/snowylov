package net.witchhaven.witchhaven.item;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.level.Level;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

public class MoonstoneItem extends Item {
    private final EntityType<?> entityType;

    public MoonstoneItem(Properties settings, EntityType<?> entityType) {
        super(settings);
        this.entityType = entityType;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level world, Player player, InteractionHand hand) {
        ItemStack itemStack = player.getItemInHand(hand);

        if (!player.getCooldowns().isOnCooldown(this)) {
            boolean hasScroll = player.getInventory().contains(new ItemStack(WitchHavenMod.SCROLL_ITEM));
            if (hasScroll && !world.isClientSide()) {
                ItemStack scrollStack = player.getInventory().getItem(player.getInventory().findSlotMatchingItem(new ItemStack(WitchHavenMod.SCROLL_ITEM)));
                scrollStack.shrink(1);
                
                summonMob(world, player);
                player.getCooldowns().addCooldown(this, 75 * 20);
                
                return InteractionResultHolder.success(itemStack);
            }
        }
        
        return InteractionResultHolder.fail(itemStack);
    }
    
    private void summonMob(Level world, Player player) {
        if (world instanceof ServerLevel) {
            Entity entity = entityType.create((ServerLevel) world);
            if (entity != null) {
                Vec3 playerPos = player.position();
                entity.setPos(playerPos.x, playerPos.y, playerPos.z);
                world.addFreshEntity(entity);
            }
        }
    }
}