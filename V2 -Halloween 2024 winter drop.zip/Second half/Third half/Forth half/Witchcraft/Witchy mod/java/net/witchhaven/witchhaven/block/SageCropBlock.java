package net.yourmod.yourpackage.block;

import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.block.state.StateDefinition.Builder;
import java.util.List;

public class SageCropBlock extends CropBlock {
    public static final IntegerProperty AGE = IntegerProperty.create("age", 0, 2); // Assuming 3 stages: 0, 1, 2

    public SageCropBlock(Settings settings) {
        super(settings);
    }

    @Override
    protected void createBlockStateDefinition(Builder<Block, BlockState> builder) {
        builder.add(AGE);
    }

    @Override
    public int getMaxAge() {
        return 2; // Stage 2 is the mature stage
    }

    @Override
    protected List<ItemStack> getDrops(BlockState state, LootContext.Builder builder) {
        List<ItemStack> drops = super.getDrops(state, builder);
        int age = state.getValue(AGE);
        if (age == getMaxAge()) {
            // Add 1 SageItem and 2 SageSeeds at mature stage
            drops.add(new ItemStack(YourMod.SAGE_ITEM, 1));
            drops.add(new ItemStack(YourMod.SAGE_SEEDS, 2));
        }
        return drops;
    }

    @Override
    protected boolean mayPlaceOn(BlockState state, Level world, BlockPos pos) {
        // Ensure SageCrop can only be planted on farmland
        return state.is(Blocks.FARMLAND);
    }
}