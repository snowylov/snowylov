package net.witchhaven.witchhaven.block;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.witchhaven.witchhaven.recipe.WitchHavenRecipeRegistry;

public class WitchHavenCraftingBlock extends Block {
    public WitchHavenCraftingBlock(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(BlockState state, Level world, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (!world.isClientSide) {
            ItemStack heldItem = player.getItemInHand(hand);
            WitchHavenRecipeRegistry.Recipe recipe = WitchHavenRecipeRegistry.findRecipe(heldItem.getItem());

            if (recipe != null && recipe.canCraft(player)) {
                ItemStack result = recipe.getResult().copy();
                if (!player.isCreative()) {
                    heldItem.shrink(1);
                }
                Block.popResource(world, pos.above(), result);
                recipe.consumeRequirements(player);
                return InteractionResult.SUCCESS;
            }
        }
        return InteractionResult.PASS;
    }
}