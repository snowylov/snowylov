package net.yourmod.yourpackage.item;

import net.minecraft.world.item.Item;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.level.Level;

public class IronWillTalismanItem extends Item {
    public IronWillTalismanItem(Properties properties) {
        super(properties);
    }

    @Override
    public void inventoryTick(ItemStack stack, Level world, Entity entity, int slot, boolean selected) {
        if (entity instanceof Player player && !world.isClientSide) {
            boolean noArmor = player.getInventory().armor.stream().allMatch(ItemStack::isEmpty);
            boolean offHand = player.getOffhandItem() == stack;

            if (noArmor && offHand) {
                player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 100, 2, false, false, true));
            }
        }
    }
}