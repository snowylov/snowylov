package net.witchhaven.witchhaven.item;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.nbt.CompoundTag;

public class ManaScrollItem extends Item {
    private static final String MANA_KEY = "PlayerMana";
    private static final int MANA_RESTORE_AMOUNT = 50;

    public ManaScrollItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level world, Player player, InteractionHand hand) {
        if (!world.isClientSide) {
            ItemStack itemStack = player.getItemInHand(hand);
            CompoundTag playerData = player.getPersistentData();
            
            // Ensure the player has a custom tag compound for mod-related data
            CompoundTag modData = playerData.getCompound("WitchHavenModData");
            int currentMana = modData.getInt(MANA_KEY);
            currentMana += MANA_RESTORE_AMOUNT; // Restore mana
            modData.putInt(MANA_KEY, currentMana);
            playerData.put("WitchHavenModData", modData);
            
            if (!player.isCreative()) {
                itemStack.shrink(1); // Consume the Mana Scroll
            }

            return InteractionResultHolder.success(itemStack);
        }
        return InteractionResultHolder.pass(player.getItemInHand(hand));
    }
}