package net.yourmod.yourpackage.item;

import net.minecraft.world.item.Item;

public class SageItem extends Item {
    public SageItem(Properties settings) {
        super(settings);
    }
}