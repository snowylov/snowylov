package net.witchhaven.witchhaven.item;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.nbt.CompoundTag;

public class WerewolfMoonstoneItem extends Item {
    public WerewolfMoonstoneItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level world, Player player, InteractionHand hand) {
        if (!world.isClientSide) {
            CompoundTag modData = player.getPersistentData().getCompound("WitchHavenModData");
            modData.putBoolean("IsWerewolf", true); // Activates the Werewolf state
            player.getPersistentData().put("WitchHavenModData", modData);
            player.displayClientMessage(new TextComponent("You feel the power of the werewolf coursing through your veins!"), true);

            // Optional: Consume the item upon use
            player.getItemInHand(hand).shrink(1);

            return InteractionResultHolder.success(player.getItemInHand(hand));
        }
        return InteractionResultHolder.pass(player.getItemInHand(hand));
    }
}