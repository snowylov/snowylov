package net.witchhaven.witchhaven.util;

import net.minecraft.server.level.ServerPlayer;

public class CustomPlayerEffects {

public void updateZombieState(Player player) {
    boolean isZombie = player.getPersistentData().getBoolean("IsZombie");
    if (isZombie) {
        // Adjust speed to match a zombie's
        player.getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(0.23F * 0.5); // Approx. zombie speed, adjust as necessary

        // For health, this requires more complex handling to adjust max health based on XP.
        // Consider tracking XP gain through a custom system and adjusting max health accordingly.
        // Below is a very simplified approach.
        int xpLevels = player.experienceLevel;
        float additionalHearts = Math.min(xpLevels / 5.0F, 10.0F); // Example: every 5 levels grants an extra heart, up to 10
        player.getAttribute(Attributes.MAX_HEALTH).setBaseValue(10.0F + additionalHearts * 2); // Base of 5 hearts + additional
    }
}

public void updateVampireState(Player player) {
    boolean isVampire = player.getPersistentData().getBoolean("IsVampire");
    if (isVampire && player.level.isDay() && player.level.canSeeSky(player.blockPosition()) && player.getInventory().getArmor(3).isEmpty()) {
        // Apply burning effect
        player.setSecondsOnFire(3); // Keep applying the effect to simulate continuous burning
    }
}


// This method should be called every tick for each player
public void updateGhostState(Player player) {
    boolean isGhost = player.getPersistentData().getBoolean("IsGhost");
    player.getAbilities().mayfly = isGhost;
    if (isGhost) {
        player.getAbilities().flying = true;
    }
    player.onUpdateAbilities();
}

public static void updateWerewolfState(ServerPlayer player) {
    CompoundTag playerData = player.getPersistentData();
    CompoundTag modData = playerData.getCompound("WitchHavenModData");
    
    boolean isWerewolf = modData.getBoolean("IsWerewolf");
    if (isWerewolf) {
        // Apply faster health regeneration. Minecraft does not directly support % increase in regeneration speed.
        // This could be approximated by giving the player Regeneration effect for short bursts or under specific conditions.
        player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 200, 0, false, false, true));
        
        // Apply speed boost when sprinting or sneaking.
        AttributeInstance attribute = player.getAttribute(Attributes.MOVEMENT_SPEED);
        AttributeModifier sprintModifier = new AttributeModifier(UUID.fromString("7107DE5E-7CE8-4030-940E-514C1F160890"), "Werewolf sprint boost", 0.2, Operation.MULTIPLY_TOTAL);
        AttributeModifier sneakModifier = new AttributeModifier(UUID.fromString("55FCED67-E92A-486E-9800-B47F202C4386"), "Werewolf sneak boost", 0.1, Operation.MULTIPLY_TOTAL);
        
        if (player.isSprinting()) {
            if (attribute.getModifier(sprintModifier.getId()) == null) {
                attribute.addPermanentModifier(sprintModifier);
            }
        } else {
            attribute.removeModifier(sprintModifier);
        }

        if (player.isCrouching()) {
            if (attribute.getModifier(sneakModifier.getId()) == null) {
                attribute.addPermanentModifier(sneakModifier);
            }
        } else {
            attribute.removeModifier(sneakModifier);
        }
    } else {
        // Ensure to remove modifiers if not a werewolf
        removeModifiers(player, sprintModifier, sneakModifier);
    }
}

private static void removeModifiers(ServerPlayer player, AttributeModifier... modifiers) {
    AttributeInstance attribute = player.getAttribute(Attributes.MOVEMENT_SPEED);
    for (AttributeModifier modifier : modifiers) {
        if (attribute.getModifier(modifier.getId()) != null) {
            attribute.removeModifier(modifier);
        }
    }
}

    public static void checkAndUpdatePlayerStates(ServerPlayer player) {
        // Here, you'd implement the logic for checking and updating each of the custom states.
        // This could involve calling methods similar to those provided in the previous answer,
updateWerewolfState(player);
updateGhostState(player);
updateVampireState(player);
updateZombieState(player);
    }
}