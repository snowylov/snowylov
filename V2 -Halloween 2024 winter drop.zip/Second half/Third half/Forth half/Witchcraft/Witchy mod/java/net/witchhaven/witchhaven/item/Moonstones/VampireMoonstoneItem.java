package net.witchhaven.witchhaven.item;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.nbt.CompoundTag;

public class VampireMoonstoneItem extends Item {
    public VampireMoonstoneItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level world, Player player, InteractionHand hand) {
        if (!world.isClientSide) {
            CompoundTag modData = player.getPersistentData().getCompound("WitchHavenModData");
            modData.putBoolean("IsVampire", true);
            player.getPersistentData().put("WitchHavenModData", modData);
            player.displayClientMessage(new TextComponent("The thirst for blood overwhelms you!"), true);
            
            player.getItemInHand(hand).shrink(1); // Consume the item
            
            return InteractionResultHolder.success(player.getItemInHand(hand));
        }
        return InteractionResultHolder.pass(player.getItemInHand(hand));
    }
}