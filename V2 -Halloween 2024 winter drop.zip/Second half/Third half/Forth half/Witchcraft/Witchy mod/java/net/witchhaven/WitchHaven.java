
package net.witchhaven;

import net.fabricmc.api.ModInitializer;

public class WitchHavenMod implements ModInitializer {


￼    // Register each colored petal as a separate item but using the same texture.
    public static final Item[] COLORED_PETALS = new Item[DyeColor.values().length];

//================================
//==========RETRO ITEMS============
//================================

public static final Item SOUL_STONE = new SoulStoneItem(new Item.Properties().stacksTo(1).durability(100));

￼ public static final Item LIFE_STONE = new LifeStoneItem(new FabricItemSettings().stacksTo(1).durability(100));

public static final Item ATHAME = new AthameItem(ItemTiers.IRON, 3, -2.4F, new Item.Properties().stacksTo(1));
    
        public static final Item CREEPER_LAUNCHER = new CreeperLauncherItem(new Item.Properties().stacksTo(1).durability(10));￼
        
        
        
        
//================================
//==========MOONSTONE ITEMS======
//================================

// Declare the moonstone items
    public static final Item WEREWOLF_MOONSTONE = new WerewolfMoonstoneItem(new Item.Properties().stacksTo(1));
    public static final Item GHOST_MOONSTONE = new GhostMoonstoneItem(new Item.Properties().stacksTo(1));
    public static final Item VAMPIRE_MOONSTONE = new VampireMoonstoneItem(new Item.Properties().stacksTo(1));
    public static final Item ZOMBIE_MOONSTONE = new ZombieMoonstoneItem(new Item.Properties().stacksTo(1));

public static final Item MOONSTONE_ITEM = new Item(new Item.Properties().stacksTo(1).durability(10));

public static final Item GHAST_MOONSTONE_ITEM = new MoonstoneItem(new Item.Properties().stacksTo(1), EntityType.GHAST);

public static final Item SPIDER_MOONSTONE_ITEM = new MoonstoneItem(new Item.Properties().stacksTo(1), EntityType.SPIDER);

public static final Item BAT_MOONSTONE_ITEM = new MoonstoneItem(new Item.Properties().stacksTo(1), EntityType.BAT);

public static final Item MOONSTONE_OF_NIGHTFALL = new MoonstoneOfNightfallItem(new Item.Properties().stacksTo(1));

public static final Item MOONSTONE_VEX = new MoonstoneItem(new FabricItemSettings(), EntityType.VEX);

//================================
//==========SAGE ITEMS=============
//================================

public static final Item WHITE_SAGE = new WhiteSageItem(new Item.Properties());
    public static final Item WHITE_SMUDGE_STICK = new WhiteSmudgeStickItem(new Item.Properties().stacksTo(1));

public static final SageItem SAGE_ITEM = new SageItem(new Item.Properties());
    public static final Item SAGE_SEEDS = new BlockItem(SAGE_CROP_BLOCK, new Item.Properties());
    public static final Block SAGE_CROP_BLOCK = new SageCropBlock(Block.Settings.copy(Blocks.WHEAT));
    
    public static final Item SMUDGE_STICK_ITEM = new SmudgeStickItem(new Item.Properties().stacksTo(1));

//================================
//==========scrolls ITEMS============
//================================

public static final
    public static final Item MANA_SCROLL = new ManaScrollItem(new Item.Properties().stacksTo(16));

    public static final Item SCROLL_ITEM = new ScrollItem(new Item.Properties().stacksTo(16));
    
//================================
//==========WITCHY ITEMS============
//================================
    
    public static final Item Villager_To_Hoe_ITEM = new VillagerTransformationItem(new Item.Properties());
    
    public static final Item SOUL_STONE = new SoulStoneItem(new Item.Properties().stacksTo(1).durability(100));

 public static final Item LIFE_STONE = new LifeStoneItem(new FabricItemSettings().stacksTo(1).durability(100));

public static final Item ATHAME = new AthameItem(ItemTiers.IRON, 3, -2.4F, new Item.Properties().stacksTo(1));
    
        public static final Item CREEPER_LAUNCHER = new CreeperLauncherItem(new Item.Properties().stacksTo(1).durability(10));

    
    public static final Item LEAP_WAND = new LeapWandItem(new FabricItemSettings());
    
    public static final Item TRAVELERS_TICKET = new TravelersTicketItem(new Item.Properties().stacksTo(1));
    
    public static final Item BOOTS_OF_THE_TRAVELER = new BootsOfTheTravelerItem(ArmorMaterials.LEATHER, EquipmentSlot.FEET, new Item.Properties().stacksTo(1));

public static final Item IRON_WILL_TALISMAN = new IronWillTalismanItem(new Item.Properties().stacksTo(1));

public static final Item NATURES_ESSENCE = new Item(new Item.Properties().tab(CreativeModeTab.TAB_MISC));

//================================
//==========WITCHY ITEMS============
//================================
    
    public static final Item Villager_To_Hoe_ITEM = new VillagerTransformationItem(new Item.Properties());
    
    public static final Item SOUL_STONE = new SoulStoneItem(new Item.Properties().stacksTo(1).durability(100));

 public static final Item LIFE_STONE = new LifeStoneItem(new FabricItemSettings().stacksTo(1).durability(100));

public static final Item ATHAME = new AthameItem(ItemTiers.IRON, 3, -2.4F, new Item.Properties().stacksTo(1));
    
        public static final Item CREEPER_LAUNCHER = new CreeperLauncherItem(new Item.Properties().stacksTo(1).durability(10));

public static final Item INVISIBILITY_BAT_SUMMONER = new InvisibilityBatSummonerItem(new FabricItemSettings().stacksTo(1));

//================================
//==========Books  ITEMS============
//================================

public static final Item HERBAL_COMPENDIUM = new LoreBookItem(new Item.Properties().stacksTo(1), "Herbs and How to Use Them", "Sage is a green herb it grows rarely if at all in most parts of Minecraftia due to witches over farming it. If you find Sage, use it to duplicate its seeds for it is very rare. Once you have 3 Sage, you can craft a smudge stick that will wipe out harmful entities in a 20x20 radius. 10 blocks on each side of the player. When combined with redstone and glowstone, it creates a more powerful Sage, called White Sage.");

public static final Item POPPET_COMPENDIUM = new LoreBookItem(new Item.Properties().stacksTo(1), "Poppet Compendium", "Harming poppets can be made with azalea_leaves and a stick. They can be renamed on an anvil to a specific player's name to harm them on right click. Meanwhile, healing poppets can heal friends and even yourself; they are crafted with glowstone dust and a diamond. They are very useful.");

public static final Item LORE_BOOK_DAY_1 = new LoreBookItem(new Item.Properties().stacksTo(1), "Cropsy's Log - Day 1", "I found a village but all the residents were scared of me could it be because I’m a scarecrow?");
    public static final Item LORE_BOOK_DAY_2 = new LoreBookItem(new Item.Properties().stacksTo(1), "Cropsy's Log - Day 2", "Today I played with kids at the village they called me spud I really like that name… I hid the parents in the village well I wonder why the kids keep asking when they’ll be back I told them it’ll be awhile maybe even longer then they will live to be.");

public static final Item CROPSYS_DEATH_CERTIFICATE = new LoreBookItem(new Item.Properties().stacksTo(1), "Cropsy's Death Certificate", "Cropsy was mistaken for a piñata at one of the village members birthday party. He was beaten to a pulp while sleeping. This was a traumatic event, and shall hopefully never happen again. Be a better witch then I was and only make golems of iron - Cedric Firebum the lesser");

public static final Item WALKING_HOE_DIARY = new LoreBookItem(new Item.Properties().stacksTo(1), "Day in the Life of a Walking Hoe", "I was cursed on my 18th birthday to be forever transformed into a tool for my favorite hobby, farming. Now I’m being used by my father. And I’m almost broken; my boyfriend doesn’t even know I turned into a diamond hoe, and everyone thinks I’m dead… I’m breaking now, goodbye world.");

//================================
//==========poppet ITEMS============
//================================

    
    public static final Item HARMING_VOODOO_DOLL = new VoodooDollItem(new Item.Properties().stacksTo(1).durability(10));
    
    public static final Item HEALING_VOODOO_DOLL = new HealingVoodooDollItem(new Item.Properties().stacksTo(1));
    
//================================
//==========Useful Blocks============
//================================
    
   public static final Block SAFETY_ANCHOR_BLOCK = new SafetyAnchorBlock(FabricBlockSettings.of(Material.STONE).strength(4.0f));
    public static final Item SAFETY_ANCHOR_ITEM = new BlockItem(SAFETY_ANCHOR_BLOCK, new FabricItemSettings());
    
    //================================
//==========WITCHY ITEMS============
//================================
    
    public static final Item Villager_To_Hoe_ITEM = new VillagerTransformationItem(new Item.Properties());
    
    public static final Item SOUL_STONE = new SoulStoneItem(new Item.Properties().stacksTo(1).durability(100));

 public static final Item LIFE_STONE = new LifeStoneItem(new FabricItemSettings().stacksTo(1).durability(100));

public static final Item ATHAME = new AthameItem(ItemTiers.IRON, 3, -2.4F, new Item.Properties().stacksTo(1));
    
        public static final Item CREEPER_LAUNCHER = new CreeperLauncherItem(new Item.Properties().stacksTo(1).durability(10));

public static final Item INVISIBILITY_BAT_SUMMONER = new InvisibilityBatSummonerItem(new FabricItemSettings().stacksTo(1));

//================================
//==========Books  ITEMS============
//================================

public static final Item HERBAL_COMPENDIUM = new LoreBookItem(new Item.Properties().stacksTo(1), "Herbs and How to Use Them", "Sage is a green herb it grows rarely if at all in most parts of Minecraftia due to witches over farming it. If you find Sage, use it to duplicate its seeds for it is very rare. Once you have 3 Sage, you can craft a smudge stick that will wipe out harmful entities in a 20x20 radius. 10 blocks on each side of the player. When combined with redstone and glowstone, it creates a more powerful Sage, called White Sage.");

public static final Item POPPET_COMPENDIUM = new LoreBookItem(new Item.Properties().stacksTo(1), "Poppet Compendium", "Harming poppets can be made with azalea_leaves and a stick. They can be renamed on an anvil to a specific player's name to harm them on right click. Meanwhile, healing poppets can heal friends and even yourself; they are crafted with glowstone dust and a diamond. They are very useful.");

public static final Item LORE_BOOK_DAY_1 = new LoreBookItem(new Item.Properties().stacksTo(1), "Cropsy's Log - Day 1", "I found a village but all the residents were scared of me could it be because I’m a scarecrow?");
    public static final Item LORE_BOOK_DAY_2 = new LoreBookItem(new Item.Properties().stacksTo(1), "Cropsy's Log - Day 2", "Today I played with kids at the village they called me spud I really like that name… I hid the parents in the village well I wonder why the kids keep asking when they’ll be back I told them it’ll be awhile maybe even longer then they will live to be.");

public static final Item CROPSYS_DEATH_CERTIFICATE = new LoreBookItem(new Item.Properties().stacksTo(1), "Cropsy's Death Certificate", "Cropsy was mistaken for a piñata at one of the village members birthday party. He was beaten to a pulp while sleeping. This was a traumatic event, and shall hopefully never happen again. Be a better witch then I was and only make golems of iron - Cedric Firebum the lesser");

public static final Item WALKING_HOE_DIARY = new LoreBookItem(new Item.Properties().stacksTo(1), "Day in the Life of a Walking Hoe", "I was cursed on my 18th birthday to be forever transformed into a tool for my favorite hobby, farming. Now I’m being used by my father. And I’m almost broken; my boyfriend doesn’t even know I turned into a diamond hoe, and everyone thinks I’m dead… I’m breaking now, goodbye world.");

//================================
//==========poppet ITEMS============
//================================

    
    public static final Item HARMING_VOODOO_DOLL = new VoodooDollItem(new Item.Properties().stacksTo(1).durability(10));
    
    public static final Item HEALING_VOODOO_DOLL = new HealingVoodooDollItem(new Item.Properties().stacksTo(1));
//================================
//==========Wand Items============
//================================
    
    public static final Item FIRE_WAND = new FireWandItem(new FabricItemSettings().stacksTo(1).durability(384));
    
    public static final Item ICE_WAND = new IceWandItem(new FabricItemSettings().stacksTo(1).durability(384));
    
    
//================================
//==========RUNE ITEMS============
//================================
    

public static final Item FIRE_SIGIL_RUNE = new Item(new Item.Settings().group(ItemGroup.MISC).maxCount(48));
    public static final Item BLANK_RUNE = new Item(new Item.Settings().group(ItemGroup.MISC).maxCount(48));
    public static final Item ICE_SIGIL_RUNE = new Item(new Item.Settings().group(ItemGroup.MISC).maxCount(48));
    public static final Item POWER_SIGIL_RUNE = new Item(new Item.Settings().group(ItemGroup.MISC).maxCount(48));



public static final Item POWER_TILE_PART = new Item(new FabricItemSettings().tab(CreativeModeTab.TAB_MISC).stacksTo(1));

    
    
//================================
//==========WITCHY ITEMS============
//================================
    
   public static final Item FIRE_WARD = new FireWardItem(new Item.Properties().stacksTo(1));
    
    public static final Item LEAP_ESSENCE = new LeapEssenceItem(new Item.Properties().stacksTo(1));
    
    public static final Item MYSTIC_GUARDIAN_CHARM = new MysticGuardianCharmItem(new FabricItemSettings().stacksTo(1));
    
    public static final Item PINK_PETAL = new PinkPetalItem(new Item.Properties());
    
    public static final Item GREEN_PETAL = new Item(new Item.Properties());
    
    public static final Item GREEN_POWDER = new EnhancedBonemealItem(new Item.Properties());
    
    public static final Item BLUE_PETAL = new Item(new Item.Properties());
   

  @Override
  public void onInitialize() {
    for (DyeColor color : DyeColor.values()) {
            Item petal = new ColoredPetalItem(new Item.Properties());
            COLORED_PETALS[color.ordinal()] = Registry.register(Registry.ITEM, new ResourceLocation("witchhaven", color.getName() + "_petal"), petal);
    }
    
    ￼ Registry.register(Registry.ITEM, new Identifier("witchhaven", "moonstone"), MOONSTONE_ITEM);
    
    Registry.register(Registry.ITEM, new Identifier("witchhaven", "ghast_moonstone"), GHAST_MOONSTONE_ITEM);
    
    Registry.register(Registry.ITEM, new Identifier("witchhaven", "bat_moonstone"), BAT_MOONSTONE_ITEM);
    
    Registry.register(Registry.ITEM, new Identifier("witchhaven", "moonstone_of_nightfall"), MOONSTONE_OF_NIGHTFALL);
    
    Registry.register(Registry.ITEM, new Identifier("witchhaven", "spider_moonstone"), SPIDER_MOONSTONE_ITEM);
    
    Registry.register(Registry.ITEM, new Identifier("witchhaven", "moonstone_vex"), MOONSTONE_VEX);
    
            // Register the moonstone items
        Registry.register(Registry.ITEM, new Identifier("witchhaven", "werewolf_moonstone"), WEREWOLF_MOONSTONE);
        Registry.register(Registry.ITEM, new Identifier("witchhaven", "ghost_moonstone"), GHOST_MOONSTONE);
        Registry.register(Registry.ITEM, new Identifier("witchhaven", "vampire_moonstone"), VAMPIRE_MOONSTONE);
        Registry.register(Registry.ITEM, new Identifier("witchhaven", "zombie_moonstone"), ZOMBIE_MOONSTONE);
    
    
    //scrolls
    
        Registry.register(Registry.ITEM, new Identifier("witchhaven", "scroll"), SCROLL_ITEM);
    
    Registry.register(Registry.ITEM, new Identifier("witchhaven", "mana_scroll"), MANA_SCROLL);
    
    Registry.register(Registry.ITEM, new Identifier("witchhaven", "invisibility_bat_summoner"), INVISIBILITY_BAT_SUMMONER);
    
    Registry.register(Registry.ITEM, new Identifier("witchhaven", "white_sage"), WHITE_SAGE);
    
        Registry.register(Registry.ITEM, new Identifier("witchhaven", "white_smudge_stick"), WHITE_SMUDGE_STICK);
    
    Registry.register(Registry.ITEM, new ResourceLocation("witchhaven", "sage_item"), SAGE_ITEM);
        Registry.register(Registry.ITEM, new ResourceLocation("witchhaven", "sage_seeds"), SAGE_SEEDS);
        Registry.register(Registry.BLOCK, new ResourceLocation("witchhaven", "sage_crop"), SAGE_CROP_BLOCK);
        
        Registry.register(Registry.ITEM, new Identifier("witchhaven", "smudge_stick"), SMUDGE_STICK_ITEM);
        
        ￼ Registry.register(Registry.ITEM, new Identifier("witchhaven", "leap_wand"), LEAP_WAND);
        
        Registry.register(Registry.ITEM, new Identifier("witchhaven", "travelers_ticket"), TRAVELERS_TICKET);
        
        Registry.register(Registry.ITEM, new Identifier("witchhaven", "boots_of_the_traveler"), BOOTS_OF_THE_TRAVELER);
        
        Registry.register(Registry.ITEM, new Identifier("witchhaven", "poppet_compendium"), POPPET_COMPENDIUM);
        
        Registry.register(Registry.ITEM, new Identifier("witchhaven", "herbal_compendium"), HERBAL_COMPENDIUM);
        
        Registry.register(Registry.ITEM, new Identifier("witchhaven", "voodoo_doll"), HARMING_VOODOO_DOLL);
        
        Registry.register(Registry.ITEM, new Identifier("witchhaven", "lore_book_day_1"), LORE_BOOK_DAY_1);
        Registry.register(Registry.ITEM, new Identifier("witchhaven", "lore_book_day_2"), LORE_BOOK_DAY_2);
        
        Registry.register(Registry.ITEM, new Identifier("witchhaven", "cropsys_death_certificate"), CROPSYS_DEATH_CERTIFICATE);
        ￼
       
       //================================
//==========WITCHY ITEMS============
//================================
    
    public static final Item Villager_To_Hoe_ITEM = new VillagerTransformationItem(new Item.Properties());
    
    public static final Item SOUL_STONE = new SoulStoneItem(new Item.Properties().stacksTo(1).durability(100));

 public static final Item LIFE_STONE = new LifeStoneItem(new FabricItemSettings().stacksTo(1).durability(100));

public static final Item ATHAME = new AthameItem(ItemTiers.IRON, 3, -2.4F, new Item.Properties().stacksTo(1));
    
        public static final Item CREEPER_LAUNCHER = new CreeperLauncherItem(new Item.Properties().stacksTo(1).durability(10));

public static final Item INVISIBILITY_BAT_SUMMONER = new InvisibilityBatSummonerItem(new FabricItemSettings().stacksTo(1));

//================================
//==========Books  ITEMS============
//================================

public static final Item HERBAL_COMPENDIUM = new LoreBookItem(new Item.Properties().stacksTo(1), "Herbs and How to Use Them", "Sage is a green herb it grows rarely if at all in most parts of Minecraftia due to witches over farming it. If you find Sage, use it to duplicate its seeds for it is very rare. Once you have 3 Sage, you can craft a smudge stick that will wipe out harmful entities in a 20x20 radius. 10 blocks on each side of the player. When combined with redstone and glowstone, it creates a more powerful Sage, called White Sage.");

public static final Item POPPET_COMPENDIUM = new LoreBookItem(new Item.Properties().stacksTo(1), "Poppet Compendium", "Harming poppets can be made with azalea_leaves and a stick. They can be renamed on an anvil to a specific player's name to harm them on right click. Meanwhile, healing poppets can heal friends and even yourself; they are crafted with glowstone dust and a diamond. They are very useful.");

public static final Item LORE_BOOK_DAY_1 = new LoreBookItem(new Item.Properties().stacksTo(1), "Cropsy's Log - Day 1", "I found a village but all the residents were scared of me could it be because I’m a scarecrow?");
    public static final Item LORE_BOOK_DAY_2 = new LoreBookItem(new Item.Properties().stacksTo(1), "Cropsy's Log - Day 2", "Today I played with kids at the village they called me spud I really like that name… I hid the parents in the village well I wonder why the kids keep asking when they’ll be back I told them it’ll be awhile maybe even longer then they will live to be.");

public static final Item CROPSYS_DEATH_CERTIFICATE = new LoreBookItem(new Item.Properties().stacksTo(1), "Cropsy's Death Certificate", "Cropsy was mistaken for a piñata at one of the village members birthday party. He was beaten to a pulp while sleeping. This was a traumatic event, and shall hopefully never happen again. Be a better witch then I was and only make golems of iron - Cedric Firebum the lesser");

public static final Item WALKING_HOE_DIARY = new LoreBookItem(new Item.Properties().stacksTo(1), "Day in the Life of a Walking Hoe", "I was cursed on my 18th birthday to be forever transformed into a tool for my favorite hobby, farming. Now I’m being used by my father. And I’m almost broken; my boyfriend doesn’t even know I turned into a diamond hoe, and everyone thinks I’m dead… I’m breaking now, goodbye world.");

//================================
//==========poppet ITEMS============
//================================

    
    public static final Item HARMING_VOODOO_DOLL = new VoodooDollItem(new Item.Properties().stacksTo(1).durability(10));
    
    public static final Item HEALING_VOODOO_DOLL = new HealingVoodooDollItem(new Item.Properties().stacksTo(1));
//================================
//==========Wand Items============
//================================
    
    public static final Item FIRE_WAND = new FireWandItem(new FabricItemSettings().stacksTo(1).durability(384));
    
    public static final Item ICE_WAND = new IceWandItem(new FabricItemSettings().stacksTo(1).durability(384));
    
    
//================================
//==========RUNE ITEMS============
//================================
    

public static final Item FIRE_SIGIL_RUNE = new Item(new Item.Settings().group(ItemGroup.MISC).maxCount(48));
    public static final Item BLANK_RUNE = new Item(new Item.Settings().group(ItemGroup.MISC).maxCount(48));
    public static final Item ICE_SIGIL_RUNE = new Item(new Item.Settings().group(ItemGroup.MISC).maxCount(48));
    public static final Item POWER_SIGIL_RUNE = new Item(new Item.Settings().group(ItemGroup.MISC).maxCount(48));



public static final Item POWER_TILE_PART = new Item(new FabricItemSettings().tab(CreativeModeTab.TAB_MISC).stacksTo(1));

    
    
//================================
//==========WITCHY ITEMS============
//================================
    
   public static final Item FIRE_WARD = new FireWardItem(new Item.Properties().stacksTo(1));
    public static final Block WITCHHAVEN_CRAFTING_BLOCK = new WitchHavenCraftingBlock(FabricBlockSettings.of(Material.STONE).strength(2.0f));
    public static final Item WITCHHAVEN_CRAFTING_BLOCK_ITEM = new BlockItem(WITCHHAVEN_CRAFTING_BLOCK, new FabricItemSettings());
       //recipes
       registerRecipe(Items.paper, new ItemStack(WitchHavenMod.SCROLL_ITEM, 1), 5, 5);
        
        registerRecipe(WitchHavenMod.SCROLL_ITEM, new ItemStack(WitchHavenMod.MANA_SCROLL, 1), 5, 5);
        
        registerRecipe(WitchHavenMod. BLANK_RUNE, new ItemStack(WitchHavenMod.POWER_SIGIL_RUNE, 1), 5, 5);
        
        Registry.register(Registry.ITEM, new Identifier("witchhaven", "walking_hoe_diary"), WALKING_HOE_DIARY);
        
        Registry.register(Registry.ITEM, new Identifier("witchhaven", "healing_voodoo_doll"), HEALING_POPPET_DOLL);
        
        Registry.register(Registry.ITEM, new Identifier("witchhaven", "athame"), ATHAME);
        
        Registry.register(Registry.ITEM, new Identifier("witchhaven", "creeper_launcher"), CREEPER_LAUNCHER);
        
       Registry.register(Registry.ITEM, new Identifier("witchhaven", "villager_hex_scroll"), Villager_To_Hoe_ITEM);
       
       Registry.register(Registry.ITEM, new Identifier("witchhaven", "leap_essence"), LEAP_ESSENCE);
       
       Registry.register(Registry.ITEM, new ResourceLocation("witchhaven", "natures_essence"), NATURES_ESSENCE);
       
       Registry.register(Registry.ITEM, new Identifier("witchhaven", "mystic_guardian_charm"), MYSTIC_GUARDIAN_CHARM);
       
       Registry.register(Registry.ITEM, new Identifier("witchhaven", "iron_will_talisman"), IRON_WILL_TALISMAN);
       
       Registry.register(Registry.ITEM, new Identifier("witchhaven", "green_powder"), GREEN_POWDER);
       
       Registry.register(Registry.ITEM, new Identifier("witchhaven", "pink_leaf"), PINK_PETAL);
       
       Registry.register(Registry.ITEM, new Identifier("witchhaven", "green_leaf"), GREEN_PETAL);
       
       Registry.register(Registry.ITEM, new Identifier("witchhaven", "blue_leaf"), BLUE_PETAL);
       
       Registry.register(Registry.ITEM, new Identifier("witchhaven", "soul_stone"), SOUL_STONE);
       
       Registry.register(Registry.ITEM, new Identifier("witchhaven", "life_stone"), LIFE_STONE);
       
       Registry.register(Registry.ITEM, new Identifier("witchhaven", "fire_ward"), FIRE_WARD);
       
       //wands
       
       Registry.register(Registry.ITEM, new Identifier("witchhaven", "ice_wand"), ICE_WAND);
       Registry.register(Registry.ITEM, new Identifier("witchhaven", "fire_wand"), FIRE_WAND);
       
       //runes
       
       Registry.register(Registry.ITEM, new Identifier("witchhaven", "fire_sigil_rune"), FIRE_SIGIL_RUNE);
        Registry.register(Registry.ITEM, new Identifier("witchhaven", "blank_rune"), BLANK_RUNE);
        Registry.register(Registry.ITEM, new Identifier("witchhaven", "ice_sigil_rune"), ICE_SIGIL_RUNE);
        Registry.register(Registry.ITEM, new Identifier("witchhaven", "power_sigil_rune"), POWER_SIGIL_RUNE);
       Registry.register(Registry.ITEM, new ResourceLocation("witchhaven", "power_tile_part"), POWER_TILE_PART);
       
       //blocks
       
       
       Registry.register(Registries.BLOCK, new ResourceLocation("witchhaven", "safety_anchor"), SAFETY_ANCHOR_BLOCK);
        Registry.register(Registries.ITEM, new ResourceLocation("witchhaven", "safety_anchor"), SAFETY_ANCHOR_ITEM);
        
Registry.register(Registry.BLOCK, new ResourceLocation("witchhaven", "witchhaven_crafting_block"), WITCHHAVEN_CRAFTING_BLOCK);
        Registry.register(Registry.ITEM, new ResourceLocation("witchhaven", "witchhaven_crafting_block"), WITCHHAVEN_CRAFTING_BLOCK_ITEM);

        // Ensure recipes are loaded and registered after the game has finished loading
        ServerLifecycleEvents.SERVER_STARTED.register(server -> WitchHavenRecipeRegistry.loadRecipes());
    }
}}