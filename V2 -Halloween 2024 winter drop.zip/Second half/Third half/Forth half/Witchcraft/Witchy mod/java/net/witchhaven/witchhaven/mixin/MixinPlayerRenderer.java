package net.yourmod.mixin;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.PlayerRenderer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.resources.ResourceLocation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;

@Mixin(PlayerRenderer.class)
public abstract class MixinPlayerRenderer extends LivingEntityRenderer<Player, EntityModel<Player>> {

    // Constructor matching super
    public MixinPlayerRenderer(EntityRendererProvider.Context context, EntityModel<Player> entityModel, float f) {
        super(context, entityModel, f);
    }
    
    @Inject(method = "render", at = @At("HEAD"))
    private void render(Player entity, float f, float g, PoseStack poseStack, MultiBufferSource multiBufferSource, int i, CallbackInfo info) {
        // Check if player is in the zombie state
        if (entity.getPersistentData().getCompound("PlayerData").getBoolean("IsZombie")) {
            // Apply a green tint to the player rendering
            float greenTint = 0.5F; // Example tint strength, adjust as necessary
            this.model.setColor(0.0F, greenTint, 0.0F, 1.0F); // ￼
            
          GL11.glColor4f(0,0,122);
        }
    }
}