package net.witchhaven.witchhaven.item;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;

public class MoonstoneOfNightfallItem extends Item {
    private static final int COOLDOWN_DURATION_TICKS = 40 * 60 * 20; // 40 minutes in ticks

    public MoonstoneOfNightfallItem(Properties settings) {
        super(settings);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level world, Player player, InteractionHand hand) {
        if (!world.isClientSide && !player.getCooldowns().isOnCooldown(this)) {
            world.setDayTime(13000); // Set time to night (13000 ticks)
            player.getCooldowns().addCooldown(this, COOLDOWN_DURATION_TICKS);
            return InteractionResultHolder.success(player.getItemInHand(hand));
        }
        return InteractionResultHolder.pass(player.getItemInHand(hand));
    }
}