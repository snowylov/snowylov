import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.DyeableItem;

public class ColoredItem extends Item implements DyeableItem {
    public ColoredItem(Properties properties) {
        super(properties);
    }

    @Override
    public int getColor(ItemStack stack) {
        return hasCustomColor(stack) ? getCustomColor(stack) : getDefaultColor();
    }

    private int getDefaultColor() {
        // This method returns the default color of the item. 
        // For example, 0xFFFFFF for white. You can change this to any color you prefer.
        return 0xFFFFFF;
    }
}