package com.example.wetbionicles;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawableHelper;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.item.*;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;
import net.minecraft.world.World;

public class WetBioniclesMod implements ModInitializer, ClientModInitializer {

    public static class Items {
        public static final Item PROTODERMIS_SHARD = new Item(new Item.Settings().group(ItemGroup.MISC));
        public static final Item PROTOSTEEL_INGOT = new Item(new Item.Settings().group(ItemGroup.MISC));
        public static final Item HYDRO_BLADE = new SwordItem(ToolMaterials.DIAMOND, 16, -2.4F, new Item.Settings().group(ItemGroup.COMBAT).maxCount(1));
        public static final Item AQUA_AXE = new AxeItem(ToolMaterials.IRON, 8, -3.0F, new Item.Settings().group(ItemGroup.TOOLS).maxCount(1));

        public static void registerItems() {
            Registry.register(Registry.ITEM, new Identifier("wetbionicles", "protodermis_shard"), PROTODERMIS_SHARD);
            Registry.register(Registry.ITEM, new Identifier("wetbionicles", "protosteel_ingot"), PROTOSTEEL_INGOT);
            Registry.register(Registry.ITEM, new Identifier("wetbionicles", "hydro_blade"), HYDRO_BLADE);
            Registry.register(Registry.ITEM, new Identifier("wetbionicles", "aqua_axe"), AQUA_AXE);
        public static final Item AQUA_AXES = new AquaAxes(ToolMaterials.DIAMOND, new Item.Settings().group(ItemGroup.COMBAT));
        public static final Item HYDRO_BLADES = new HydroBlades(ToolMaterials.NETHERITE, new Item.Settings().group(ItemGroup.COMBAT));
        public static final Item PAKARI = new CustomHelmet(ModArmorMaterials.HELMET_MATERIAL, EquipmentSlot.HEAD, new Item.Settings().group(ItemGroup.COMBAT));
        public static final Item KAKAMA = new CustomHelmet(ModArmorMaterials.HELMET_MATERIAL, EquipmentSlot.HEAD, new Item.Settings().group(ItemGroup.COMBAT));
        public static final Item MIRU = new CustomHelmet(ModArmorMaterials.HELMET_MATERIAL, EquipmentSlot.HEAD, new Item.Settings().group(ItemGroup.COMBAT));
        public static final Item KAU_KAU = new CustomHelmet(ModArmorMaterials.HELMET_MATERIAL, EquipmentSlot.HEAD, new Item.Settings().group(ItemGroup.COMBAT));
        public static final Item DIAMOND_CHESTPLATE = new CustomChestplate(ModArmorMaterials.DIAMOND, EquipmentSlot.CHEST, new Item.Settings().group(ItemGroup.COMBAT));
        public static final Item NETHERITE_CHESTPLATE = new CustomChestplate(ModArmorMaterials.NETHERITE, EquipmentSlot.CHEST, new Item.Settings().group(ItemGroup.COMBAT));
            Registry.register(Registry.ITEM, new Identifier("wetbionicles", "aqua_axes"), AQUA_AXES);
            Registry.register(Registry.ITEM, new Identifier("wetbionicles", "hydro_blades"), HYDRO_BLADES);
            Registry.register(Registry.ITEM, new Identifier("wetbionicles", "pakari"), PAKARI);
            Registry.register(Registry.ITEM, new Identifier("wetbionicles", "kakama"), KAKAMA);
            Registry.register(Registry.ITEM, new Identifier("wetbionicles", "miru"), MIRU);
            Registry.register(Registry.ITEM, new Identifier("wetbionicles", "kau_kau"), KAU_KAU);
plate"), DIAMOND_CHESTPLATE);
            Registry.register(Registry.ITEM, new Identifier("wetbionicles", "netherite_chestplate"), NETHERITE_CHESTPLATE);

// Hydro Blades Item
public static class HydroBlades extends Item {
    private static final int COOLDOWN_NORMAL = 50; // 2.5 seconds (20 ticks per second)
    private static final int COOLDOWN_SNEAKING = 30; // 1.5 seconds

    public HydroBlades(ToolMaterial material, Item.Settings settings) {
        super(settings.maxCount(1));
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        ItemStack itemStack = player.getStackInHand(hand);
        if (player.isTouchingWater()) {
            player.setSprinting(true);
            player.addVelocity(player.getRotationVec(1.0F).x * 0.5, 0, player.getRotationVec(1.0F).z * 0.5);
        }

        if (player.isSneaking()) {
            player.getItemCooldownManager().set(this, COOLDOWN_SNEAKING);
            player.addVelocity(0, 0, 0.5); // Knockback effect
        } else {
            player.getItemCooldownManager().set(this, COOLDOWN_NORMAL);
        }

        return TypedActionResult.success(itemStack);
    }
}

// Aqua Axes Item
public static class AquaAxes extends Item {
    private static final int COOLDOWN = 10; // 0.5 seconds

    public AquaAxes(ToolMaterial material, Item.Settings settings) {
        super(settings.maxCount(2));
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        ItemStack itemStack = player.getStackInHand(hand);
        player.getItemCooldownManager().set(this, COOLDOWN);
        return TypedActionResult.success(itemStack);
    }
}

// Custom Helmets
public static class CustomHelmet extends ArmorItem {
    public CustomHelmet(ArmorMaterial material, EquipmentSlot slot, Item.Settings settings) {
        super(material, slot, settings.group(ItemGroup.COMBAT));
    }
}

// Custom Chestplates
public static class CustomChestplate extends ArmorItem {
    public CustomChestplate(ArmorMaterial material, EquipmentSlot slot, Item.Settings settings) {
        super(material, slot, settings.group(ItemGroup.COMBAT));
    }
}

        }
    }

    public static class Entities {
        public static final EntityType<PathAwareEntity> VISARAK = EntityType.Builder.create(PathAwareEntity::new, MobEntity.Category.MONSTER).build("visarak");

        public static void registerEntities() {
            Registry.register(Registry.ENTITY_TYPE, new Identifier("wetbionicles", "visarak"), VISARAK);
        }
    }

    public static class Effects {
        public static void applyElementEffects(Element element, MinecraftClient client) {
            switch (element) {
                case FIRE:
                    applyFireEffects(client);
                    break;
                case WATER:
                    applyWaterEffects(client);
                    break;
                case EARTH:
                    applyEarthEffects(client);
                    break;
                case AIR:
                    applyAirEffects(client);
                    break;
                case JUNGLE:
                    applyJungleEffects(client);
                    break;
                case ICE:
                    applyIceEffects(client);
                    break;
                case STONE:
                    applyStoneEffects(client);
                    break;
                default:
                    break;
            }
        }

        private static void applyFireEffects(MinecraftClient client) {
            client.player.addStatusEffect(new StatusEffectInstance(StatusEffects.FIRE_RESISTANCE, 6000, 0));
        }

        private static void applyWaterEffects(MinecraftClient client) {
            client.player.addStatusEffect(new StatusEffectInstance(StatusEffects.WATER_BREATHING, 6000, 0));
        }

        private static void applyEarthEffects(MinecraftClient client) {
            client.player.addStatusEffect(new StatusEffectInstance(StatusEffects.HASTE, 6000, 1));
        }

        private static void applyAirEffects(MinecraftClient client) {
            client.player.addStatusEffect(new StatusEffectInstance(StatusEffects.JUMP_BOOST, 6000, 1));
        }

        private static void applyJungleEffects(MinecraftClient client) {
            client.player.addStatusEffect(new StatusEffectInstance(StatusEffects.INVISIBILITY, 6000, 0));
        }

        private static void applyIceEffects(MinecraftClient client) {
            client.player.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOW_FALLING, 6000, 0));
        }

        private static void applyStoneEffects(MinecraftClient client) {
            client.player.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 6000, 1));
        }
    }

    public static class HUDOverlay extends DrawableHelper {
        private static final MinecraftClient client = MinecraftClient.getInstance();

        public static void render(MatrixStack matrices) {
            if (shouldDisplayWarning()) {
                client.textRenderer.drawWithShadow(matrices, Text.of("Hordika Warning"), 10, 10, 0xFF0000);
            }
        }

        private static boolean shouldDisplayWarning() {
            return false; // Placeholder logic for determining if the warning should be displayed
        }
    }

    public static class ElementSymbolScanner {
        public enum Element {
            FIRE, WATER, EARTH, AIR, JUNGLE, ICE, STONE, UNKNOWN
        }

        public static Element scanSymbol(Identifier imageId) {
            Element identifiedElement = identifyElement(imageId);
            return identifiedElement != null ? identifiedElement : Element.UNKNOWN;
        }

        private static Element identifyElement(Identifier imageId) {
            if (imageId.getPath().contains("fire")) {
                return Element.FIRE;
            } else if (imageId.getPath().contains("water")) {
                return Element.WATER;
            } else if (imageId.getPath().contains("earth")) {
                return Element.EARTH;
            } else if (imageId.getPath().contains("air")) {
                return Element.AIR;
            } else if (imageId.getPath().contains("jungle")) {
                return Element.JUNGLE;
            } else if (imageId.getPath().contains("ice")) {
                return Element.ICE;
            } else if (imageId.getPath().contains("stone")) {
                return Element.STONE;
            }
            return Element.UNKNOWN;
        }
    }

    // Integrating SymbolReader logic
    public static class SymbolReader {
        private static Element currentElement = Element.UNKNOWN;

        public static void setElement(Element element) {
            currentElement = element;
            Effects.applyElementEffects(element, MinecraftClient.getInstance());
        }

        public static Element getCurrentElement() {
            return currentElement;
        }

        public static void updateElementBasedOnImage(Identifier imageId) {
            Element identifiedElement = ElementSymbolScanner.scanSymbol(imageId);
            setElement(identifiedElement);
        }
    }

    public static class JournalScreen extends Screen {
        private static final Text[] PAGES = {
            Text.of("Journal of a Toa of Water... Lost, but seeking answers."),
            Text.of("Day 1: I've found myself amidst ruins..."),
            Text.of("The Visarak are strange creatures..."),
            Text.of("The green fog limits visibility..."),
            Text.of("Visarak seem to surround their prey..."),
            Text.of("They hide during the day...")
        };
        private int currentPage = 0;

        public JournalScreen() {
            super(Text.of("Journal"));
        }

        @Override
        public void render(MatrixStack matrices, int mouseX, int mouseY, float delta) {
            this.renderBackground(matrices);
            drawCenteredText(matrices, this.textRenderer, PAGES[currentPage], this.width / 2, 20, 0xFFFFFF);
            drawNavigationButtons(matrices);
            super.render(matrices, mouseX, mouseY, delta);
        }

        private void drawNavigationButtons(MatrixStack matrices) {
            int x = this.width / 2;
            int y = this.height - 30;
            int buttonWidth = 100;
            int buttonHeight = 20;

            int prevColor = (currentPage > 0) ? 0xFFFFFF : 0xAAAAAA;
            drawCenteredText(matrices, this.textRenderer, Text.of("Previous"), x - buttonWidth, y, prevColor);

            int nextColor = (currentPage < PAGES.length - 1) ? 0xFFFFFF : 0xAAAAAA;
            drawCenteredText(matrices, this.textRenderer, Text.of("Next"), x + buttonWidth, y, nextColor);
        }

        @Override
        public boolean mouseClicked(double mouseX, double mouseY, int button) {
            int x = this.width / 2;
            int y = this.height - 30;
            int buttonWidth = 100;
            int buttonHeight = 20;

            if (mouseX >= x - buttonWidth - buttonWidth / 2 && mouseX <= x - buttonWidth + buttonWidth / 2 && mouseY >= y - buttonHeight / 2 && mouseY <= y + buttonHeight / 2) {
                if (currentPage > 0) {
                    currentPage--;
                }
                return true;
            }

            if (mouseX >= x + buttonWidth - buttonWidth / 2 && mouseX <= x + buttonWidth + buttonWidth / 2 && mouseY >= y - buttonHeight / 
2 && mouseY <= y + buttonHeight / 2) {
                if (currentPage < PAGES.length - 1) {
                    currentPage++;
                }
                return true;
            }

            return super.mouseClicked(mouseX, mouseY, button);
        }
    }

    @Override
    public void onInitialize() {
        Items.registerItems();
        Entities.registerEntities();
        System.out.println("WetBionicles Mod has been initialized!");
    }

    @Override
    public void onInitializeClient() {
        // Register client-side features, such as rendering overlays or setting up custom screens
    }
}

// Hydro Blades Item
public static class HydroBlades extends SwordItem {
    private static final int COOLDOWN_NORMAL = 50; // 2.5 seconds (20 ticks per second)
    private static final int COOLDOWN_SNEAKING = 30; // 1.5 seconds

    public HydroBlades(ToolMaterial material, Item.Settings settings) {
        super(material, 3, -2.4F, settings.maxCount(1));
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        ItemStack itemStack = player.getStackInHand(hand);
        if (player.isTouchingWater()) {
            player.setSprinting(true);
            player.addVelocity(player.getRotationVec(1.0F).x * 0.5, 0, player.getRotationVec(1.0F).z * 0.5);
        }

        if (player.isSneaking()) {
            player.getItemCooldownManager().set(this, COOLDOWN_SNEAKING);
            player.addVelocity(0, 0, 0.5); // Knockback effect
        } else {
            player.getItemCooldownManager().set(this, COOLDOWN_NORMAL);
        }

        return TypedActionResult.success(itemStack);
    }
}

// Aqua Axes Item
public static class AquaAxes extends AxeItem {
    private static final int COOLDOWN = 10; // 0.5 seconds

    public AquaAxes(ToolMaterial material, Item.Settings settings) {
        super(material, 6.0F, -3.1F, settings.maxCount(2));
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        ItemStack itemStack = player.getStackInHand(hand);
        player.getItemCooldownManager().set(this, COOLDOWN);
        return TypedActionResult.success(itemStack);
    }
}

// Custom Helmets
public static class CustomHelmet extends ArmorItem {
    public CustomHelmet(ArmorMaterial material, EquipmentSlot slot, Item.Settings settings) {
        super(material, slot, settings.group(ItemGroup.COMBAT));
    }
}

// Custom Chestplates
public static class CustomChestplate extends ArmorItem {
    public CustomChestplate(ArmorMaterial material, EquipmentSlot slot, Item.Settings settings) {
        super(material, slot, settings.group(ItemGroup.COMBAT));
    }
}
