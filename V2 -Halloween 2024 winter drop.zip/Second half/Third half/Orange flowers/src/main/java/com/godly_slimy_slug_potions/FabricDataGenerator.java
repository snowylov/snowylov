package com.godly_slimy_slug_potions;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;

public class FabricDataGenerator {
    public void run() {
        generateBlockStates();
        generateBlockModels();
        generateItemModels();
        generateLootTables();
    }

    private void generateBlockStates() {
        for (int i = 1; i <= 9; i++) {
            String blockName = "orange_vine_flower_" + i;
            String blockStateJson = "{ \"variants\": { \"\": { \"model\": \"godly_slimy_slug_potions:block/" + blockName + "\" } } }";
            saveToFile("src/main/resources/assets/godly_slimy_slug_potions/blockstates/" + blockName + ".json", blockStateJson);
        }
    }

    private void generateBlockModels() {
        for (int i = 1; i <= 9; i++) {
            String blockName = "orange_vine_flower_" + i;
            String blockModelJson = "{ \"parent\": \"block/cross\", \"textures\": { \"cross\": \"godly_slimy_slug_potions:block/" + blockName + "\" } }";
            saveToFile("src/main/resources/assets/godly_slimy_slug_potions/models/block/" + blockName + ".json", blockModelJson);
        }
    }

    private void generateItemModels() {
        for (int i = 1; i <= 9; i++) {
            String blockName = "orange_vine_flower_" + i;
            String itemModelJson = "{ \"parent\": \"item/generated\", \"textures\": { \"layer0\": \"godly_slimy_slug_potions:item/" + blockName + "\" } }";
            saveToFile("src/main/resources/assets/godly_slimy_slug_potions/models/item/" + blockName + ".json", itemModelJson);
        }
    }

    private void generateLootTables() {
        for (int i = 1; i <= 9; i++) {
            String blockName = "orange_vine_flower_" + i;
            String lootTableJson = "{ \"type\": \"minecraft:block\", \"pools\": [ { \"rolls\": 1, \"entries\": [ { \"type\": \"minecraft:item\", \"name\": \"godly_slimy_slug_potions:" + blockName + "\" } ] } ] }";
            saveToFile("src/main/resources/data/godly_slimy_slug_potions/loot_tables/blocks/" + blockName + ".json", lootTableJson);
        }
    }

    private void saveToFile(String path, String content) {
        try {
            Files.createDirectories(Paths.get(path).getParent());
            Files.write(Paths.get(path), content.getBytes(StandardCharsets.UTF_8));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}