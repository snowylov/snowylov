package com.godly_slimy_slug_potions;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.SlimeEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.world.World;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

public class BigChungusSlimeEntity extends SlimeEntity {
    public BigChungusSlimeEntity(EntityType<? extends SlimeEntity> entityType, World world) {
        super(entityType, world);
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(1, new SwimGoal(this));
        this.goalSelector.add(2, new WanderAroundFarGoal(this, 1.0D));
        this.goalSelector.add(3, new LookAtEntityGoal(this, PlayerEntity.class, 8.0F));
        this.goalSelector.add(4, new LookAroundGoal(this));
        this.targetSelector.add(1, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    @Override
    public void setSize(int size, boolean heal) {
        super.setSize(size, heal);
        if (size == 3) {
            this.convertTo(EntityType.SLIME, false); // Convert to vanilla slime at size 3
        } else if (size > 3) {
            this.setHealth(this.getMaxHealth() * 1.75f); // Increase health by 75%
        }
    }

    public static DefaultAttributeContainer.Builder createBigChungusSlimeAttributes() {
        return SlimeEntity.createMobAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 16.0D) // Adjust health as needed
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.25D);
    }

    public static void registerEntities() {
        Registry.register(Registry.ENTITY_TYPE, new Identifier(GodlySlimySlugPotionsMod.MODID, "big_chungus_slime"), BIG_CHUNGUS_SLIME);
        FabricDefaultAttributeRegistry.register(BIG_CHUNGUS_SLIME, BigChungusSlimeEntity.createBigChungusSlimeAttributes());
    }
}