package com.godly_slimy_slug_potions;

import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.Items;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionUtil;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;
import net.minecraft.world.event.listener.BrewingRecipeRegistry;

public class ModPotions {
    public static final Potion MENISCUS = new Potion();
    public static final Potion MUCUS = new Potion();
    public static final Potion GOD = new Potion();
    public static final Potion SLIMY = new Potion();
    public static final Potion GLOWING = new Potion(new StatusEffectInstance(StatusEffects.GLOWING, 3600), new StatusEffectInstance(ModEffects.HOLY, 3600));
    public static final Potion LIGHT_AURA = new Potion(new StatusEffectInstance(StatusEffects.GLOWING, 3600), new StatusEffectInstance(StatusEffects.INSTANT_HEALTH, 1, 1), new StatusEffectInstance(StatusEffects.REGENERATION, 800, 1));
    public static final Potion EDEN = new Potion(new StatusEffectInstance(StatusEffects.REGENERATION, 72000, 2), new StatusEffectInstance(ModEffects.HOLY, 72000), new StatusEffectInstance(ModEffects.MASTER, 72000));
    public static final Potion ENHANCED_GOD = new Potion(new StatusEffectInstance(StatusEffects.DURATION_MODIFIER, 96000, 2));
    public static final Potion INSTA_KILL = new Potion(new StatusEffectInstance(ModEffects.INSTA_KILL, 3600));

    public static void registerPotions() {
        Registry.register(Registry.POTION, new Identifier(GodlySlimySlugPotionsMod

.MODID, "meniscus"), MENISCUS);
        Registry.register(Registry.POTION, new Identifier(GodlySlimySlugPotionsMod.MODID, "mucus"), MUCUS);
        Registry.register(Registry.POTION, new Identifier(GodlySlimySlugPotionsMod.MODID, "god"), GOD);
        Registry.register(Registry.POTION, new Identifier(GodlySlimySlugPotionsMod.MODID, "slimy"), SLIMY);
        Registry.register(Registry.POTION, new Identifier(GodlySlimySlugPotionsMod.MODID, "glowing"), GLOWING);
        Registry.register(Registry.POTION, new Identifier(GodlySlimySlugPotionsMod.MODID, "light_aura"), LIGHT_AURA);
        Registry.register(Registry.POTION, new Identifier(GodlySlimySlugPotionsMod.MODID, "eden"), EDEN);
        Registry.register(Registry.POTION, new Identifier(GodlySlimySlugPotionsMod.MODID, "enhanced_god"), ENHANCED_GOD);
        Registry.register(Registry.POTION, new Identifier(GodlySlimySlugPotionsMod.MODID, "insta_kill"), INSTA_KILL);
    }

    public static void registerBrewingRecipes() {
        BrewingRecipeRegistry.registerPotionRecipe(Potions.WATER, GodlySlimySlugPotionsMod.ORANGE_VINE_FLOWER_1, MENISCUS);
        BrewingRecipeRegistry.registerPotionRecipe(MENISCUS, Items.NETHER_WART, MUCUS);
        BrewingRecipeRegistry.registerPotionRecipe(MUCUS, Items.APPLE, GOD);
        BrewingRecipeRegistry.registerPotionRecipe(MUCUS, Items.SLIME_BALL, SLIMY);
        BrewingRecipeRegistry.registerPotionRecipe(GOD, Items.GLOWSTONE_DUST, GLOWING);
        BrewingRecipeRegistry.registerPotionRecipe(GOD, Items.GLISTERING_MELON_SLICE, GLOWING);
        BrewingRecipeRegistry.registerPotionRecipe(GOD, Items.GLOW_BERRIES, GLOWING);
        BrewingRecipeRegistry.registerPotionRecipe(GOD, Items.GLISTERING_MELON_SLICE, LIGHT_AURA);
        BrewingRecipeRegistry.registerPotionRecipe(GOD, Items.GOLD_NUGGET, LIGHT_AURA);
        BrewingRecipeRegistry.registerPotionRecipe(GOD, Items.SWEET_BERRIES, EDEN);
        BrewingRecipeRegistry.registerPotionRecipe(MUCUS, GOD, ENHANCED_GOD);
        BrewingRecipeRegistry.registerPotionRecipe(MUCUS, Items.LILY_OF_THE_VALLEY, INSTA_KILL);
    }

    public static void registerPotionTypes() {
        for (Potion potion : new Potion[]{MENISCUS, MUCUS, GOD, SLIMY, GLOWING, LIGHT_AURA, EDEN, ENHANCED_GOD, INSTA_KILL}) {
            PotionUtil.registerPotion(potion);
            PotionUtil.registerPotion(new SplashPotion(potion));
            PotionUtil.registerPotion(new LingeringPotion(potion));
        }
    }
}