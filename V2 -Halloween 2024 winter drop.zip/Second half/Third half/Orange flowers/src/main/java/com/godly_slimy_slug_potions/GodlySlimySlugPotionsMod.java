package com.godly_slimy_slug_potions;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.fabricmc.fabric.api.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.entity.FabricEntityTypeBuilder;
import net.minecraft.block.Block;
import net.minecraft.block.Material;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

public class GodlySlimySlugPotionsMod implements ModInitializer {
    public static final String MODID = "godly_slimy_slug_potions";
    
    // Register blocks
    public static final Block[] ORANGE_VINE_FLOWER_BLOCKS = new Block[9];
    
    // Register entity
    public static final EntityType<BigChungusSlimeEntity> BIG_CHUNGUS_SLIME = Registry.register(
            Registry.ENTITY_TYPE,
            new Identifier(MODID, "big_chungus_slime"),
            FabricEntityTypeBuilder.create(SpawnGroup.MONSTER, BigChungusSlimeEntity::new)
                    .dimensions(EntityDimensions.fixed(2.04f, 2.04f))
                    .trackRangeBlocks(10)
                    .trackedUpdateRate(1)
                    .build()
    );

    @Override
    public void onInitialize() {
        // Register blocks and items
        for (int i = 0; i < 9; i++) {
            ORANGE_VINE_FLOWER_BLOCKS[i] = new Block(FabricBlockSettings.of(Material.PLANT).noCollision().breakInstantly().sounds(BlockSoundGroup.GRASS));
            Registry.register(Registry.BLOCK, new Identifier(MODID, "orange_vine_flower_" + (i + 1)), ORANGE_VINE_FLOWER_BLOCKS[i]);
            Registry.register(Registry.ITEM, new Identifier(MODID, "orange_vine_flower_" + (i + 1)), new BlockItem(ORANGE_VINE_FLOWER_BLOCKS[i], new Item.Settings().group(ItemGroup.DECORATIONS)));
        }

        // Register effects, potions, and brewing recipes
        ModEffects.registerEffects();
        ModPotions.registerPotions();
        ModPotions.registerBrewingRecipes();
        ModPotions.registerPotionTypes();
        BigChungusSlimeEntity.registerEntities();

        // Initialize data generation
        FabricDataGenerator generator = new FabricDataGenerator();
        generator.run();
    }
}