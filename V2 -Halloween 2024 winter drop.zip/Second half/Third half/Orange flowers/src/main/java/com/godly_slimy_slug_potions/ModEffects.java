package com.godly_slimy_slug_potions;

import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectCategory;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

public class ModEffects {
    public static final StatusEffect HOLY = new HolyEffect();
    public static final StatusEffect MASTER = new MasterEffect();
    public static final StatusEffect INSTA_KILL = new InstaKillEffect();

    public static void registerEffects() {
        Registry.register(Registry.STATUS_EFFECT, new Identifier(GodlySlimySlugPotionsMod.MODID, "holy"), HOLY);
        Registry.register(Registry.STATUS_EFFECT, new Identifier(GodlySlimySlugPotionsMod.MODID, "master"), MASTER);
        Registry.register(Registry.STATUS_EFFECT, new Identifier(GodlySlimySlugPotionsMod.MODID, "insta_kill"), INSTA_KILL);
    }

    private static class HolyEffect extends StatusEffect {
        public HolyEffect() {
            super(StatusEffectCategory.BENEFICIAL, 0xFFFFFF);
        }

        @Override
        public void applyUpdateEffect(LivingEntity entity, int amplifier) {
            // Implement Holy effect: immunity to undead mobs
        }
    }

    private static class MasterEffect extends StatusEffect {
        public MasterEffect() {
            super(StatusEffectCategory.BENEFICIAL, 0xFFFFFF);
        }

        @Override
        public void applyUpdateEffect(LivingEntity entity, int amplifier) {
            // Implement Master effect: animals follow you
        }
    }

    private static class InstaKillEffect extends StatusEffect {
        public InstaKillEffect() {
            super(StatusEffectCategory.HARMFUL, 0xFFFFFF);
        }

        @Override
        public void applyUpdateEffect(LivingEntity entity, int amplifier) {
            if (entity.getDamageTracker().isInSource(Source.DAMAGE)) {
                entity.setHealth(0); // Implement Insta Kill effect
            }
        }
    }
}