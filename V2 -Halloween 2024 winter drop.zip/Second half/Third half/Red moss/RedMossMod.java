package com.example.redmossmod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.client.rendereregistry.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.datagen.v1.FabricDataGenerator;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricBlockLootTableProvider;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricItemModelProvider;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.*;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.render.entity.model.SkeletonEntityModel;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.mob.SkeletonEntity;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.item.*;
import net.minecraft.resource.ResourceType;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.registry.Registry;
import net.minecraft.world.StructureWorldAccess;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.biome.BiomeEffects;
import net.minecraft.world.biome.GenerationSettings;
import net.minecraft.world.biome.SpawnSettings;
import net.minecraft.world.gen.GenerationStep;
import net.minecraft.world.gen.feature.DefaultFeatureConfig;
import net.minecraft.world.gen.feature.Feature;
import net.minecraft.client.render.entity.SkeletonEntityRenderer;
import com.mojang.serialization.Codec;
import net.fabricmc.api.ClientModInitializer;
import org.jetbrains.annotations.Nullable;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.packet.s2c.play.BlockEntityUpdateS2CPacket;
import net.minecraft.network.Packet;
import java.util.Random;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;

public class RedMossMod implements ModInitializer, ClientModInitializer {
    public static final String MODID = "redmoss";

    // Registering Items
    public static final Item RED_MOSS_METAL_INGOT = new Item(new Item.Settings().group(ItemGroup.MATERIALS));
    public static final Item RED_MOSS_METAL_SHARD = new Item(new Item.Settings().group(ItemGroup.MATERIALS));
    public static final Item RED_MOSS_METAL_NUGGET = new Item(new Item.Settings().group(ItemGroup.MATERIALS));
    public static final Item RED_MOSS_METAL_SWORD = new SwordItem(ToolMaterials.IRON, 7, -2.4F, new Item.Settings().group(ItemGroup.COMBAT)) {
        @Override
        public boolean postHit(ItemStack stack, LivingEntity target, LivingEntity attacker) {
            if (target instanceof LivingEntity && new Random().nextInt(100) < 15) {
                target.dropStack(target.getMainHandStack(), true);
                target.setStackInHand(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
            }
            return super.postHit(stack, target, attacker);
        }
    };
    public static final Item RED_MOSS_METAL_PICKAXE = new PickaxeItem(ToolMaterials.IRON, 5, -2.8F, new Item.Settings().group(ItemGroup.TOOLS));
    public static final Item RED_MOSS_METAL_WAR_AXE = new AxeItem(ToolMaterials.IRON, 19, -3.0F, new Item.Settings().group(ItemGroup.COMBAT)) {
        @Override
        public boolean postHit(ItemStack stack, LivingEntity target, LivingEntity attacker) {
            if (target instanceof LivingEntity) {
                if (new Random().nextInt(100) < 50) {
                    target.dropStack(target.getMainHandStack(), true);
                    target.setStackInHand(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
                }
                if (target.getAttributeInstance(EntityAttributes.GENERIC_ARMOR) != null) {
                    target.getAttributeInstance(EntityAttributes.GENERIC_ARMOR).setBaseValue(0); // Bypass Armor
                }
                if (attacker.isSprinting()) {
                    target.disableShield(true); // Disable shield on sprint attack
                }
            }
            return super.postHit(stack, target, attacker);
        }

        @Override
        public int getCooldown() {
            return 30; // Cooldown of 1.5 seconds
        }
    };

    // Registering Blocks
    public static final Block RED_MOSS = new Block(AbstractBlock.Settings.of(Material.PLANT).strength(0.5F).requiresTool());
    public static final Block RED_MOSS_CARPET = new Block(AbstractBlock.Settings.of(Material.CARPET).strength(0.1F).requiresTool());
    public static final Block RED_MOSS_METAL_BLOCK = new Block(AbstractBlock.Settings.of(Material.METAL).strength(5.0F, 6.0F).requiresTool());
    public static final Block DIRECTIONAL_MAP_BLOCK = new DirectionalMapBlock(AbstractBlock.Settings.of(Material.METAL).strength(3.5F).requiresTool());
    public static final Block CRIMSON_QUEST_BLOCK = new CrimsonQuestBlock(AbstractBlock.Settings.of(Material.WOOD).strength(2.0F).requiresTool());

    // Registering Custom Entity for Red Moss Opacity Line
    public static final EntityType<RedMossOpacityLineEntity> RED_MOSS_OPACITY_LINE = Registry.register(
            Registry.ENTITY_TYPE,
            new Identifier(MODID, "red_moss_opacity_line"),
            FabricEntityTypeBuilder.create(SpawnGroup.MISC, RedMossOpacityLineEntity::new)
                    .dimensions(EntityDimensions.fixed(0.2F, 0.2F)).trackRangeBlocks(64).trackedUpdateRate(10).build()
    );

    // Block Entity Type
    public static BlockEntityType<DirectionalMapBlockEntity> DIRECTIONAL_MAP_BLOCK_ENTITY;

    // Registering Custom Entity
    public static final EntityType<RedMossDruidSkeletonEntity> RED_MOSS_DRUID_SKELETON = Registry.register(
            Registry.ENTITY_TYPE,
            new Identifier(MODID, "red_moss_druid_skeleton"),
            FabricEntityTypeBuilder.create(SpawnGroup.MONSTER, RedMossDruidSkeletonEntity::new)
                    .dimensions(EntityDimensions.fixed(0.6F, 1.99F)).build()
    );

    @Override
    public void onInitialize() {
        // Register items
        Registry.register(Registry.ITEM, new Identifier(MODID, "red_moss_metal_ingot"), RED_MOSS_METAL_INGOT);
        Registry.register(Registry.ITEM, new Identifier(MODID, "red_moss_metal_shard"), RED_MOSS_METAL_SHARD);
        Registry.register(Registry.ITEM, new Identifier(MODID, "red_moss_metal_nugget"), RED_MOSS_METAL_NUGGET);
        Registry.register(Registry.ITEM, new Identifier(MODID, "red_moss_metal_sword"), RED_MOSS_METAL_SWORD);
        Registry.register(Registry.ITEM, new Identifier(MODID, "red_moss_metal_pickaxe"), RED_MOSS_METAL_PICKAXE);
        Registry.register(Registry.ITEM, new Identifier(MODID, "red_moss_metal_war_axe"), RED_MOSS_METAL_WAR_AXE);

        // Register blocks
        Registry.register(Registry.BLOCK, new Identifier(MODID, "red_moss"), RED_MOSS);
        Registry.register(Registry.ITEM, new Identifier(MODID, "red_moss"), new BlockItem(RED_MOSS, new Item.Settings().group(ItemGroup.BUILDING_BLOCKS)));
        Registry.register(Registry.BLOCK, new Identifier(MODID, "red_moss_carpet"), RED_MOSS_CARPET);
        Registry.register(Registry.ITEM, new Identifier(MODID, "red_moss_carpet"), new BlockItem(RED_MOSS_CARPET, new Item.Settings().group(ItemGroup.DECORATIONS)));
        Registry.register(Registry.BLOCK, new Identifier(MODID, "red_moss_metal_block"), RED_MOSS_METAL_BLOCK);
        Registry.register(Registry.ITEM, new Identifier(MODID, "red_moss_metal_block"), new BlockItem(RED_MOSS_METAL_BLOCK, new Item.Settings().group(ItemGroup.BUILDING_BLOCKS)));
        Registry.register(Registry.BLOCK, new Identifier(MODID, "directional_map_block"), DIRECTIONAL_MAP_BLOCK);
        Registry.register(Registry.ITEM, new Identifier(MODID, "directional_map_block"), new BlockItem(DIRECTIONAL_MAP_BLOCK, new Item.Settings().group(ItemGroup.MISC)));
        Registry.register(Registry.BLOCK, new Identifier(MODID, "crimson_quest_block"), CRIMSON_QUEST_BLOCK);
        Registry.register(Registry.ITEM, new Identifier(MODID, "crimson_quest_block"), new BlockItem(CRIMSON_QUEST_BLOCK, new Item.Settings().group(ItemGroup.MISC)));

        // Register block entities
        DIRECTIONAL_MAP_BLOCK_ENTITY = Registry.register(Registry.BLOCK_ENTITY_TYPE, new Identifier(MODID, "directional_map_block_entity"), BlockEntityType.Builder.create(DirectionalMapBlockEntity::new, DIRECTIONAL_MAP_BLOCK).build(null));

        // Register custom entity spawn event for Red Moss Druid Skeletons wielding weapons
        ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
            if (entity instanceof RedMossDruidSkeletonEntity && world instanceof ServerWorld) {
                RedMossDruidSkeletonEntity redSkeleton = (RedMossDruidSkeletonEntity) entity;
                if (new Random().nextInt(100) < 15) { // 15% chance to wield an axe
                    redSkeleton.equipStack(EquipmentSlot.MAINHAND, new ItemStack(RED_MOSS_METAL_WAR_AXE));
                    if (redSkeleton.getAttributeInstance(EntityAttributes.GENERIC_ATTACK_DAMAGE) != null) {
                        redSkeleton.getAttributeInstance(EntityAttributes.GENERIC_ATTACK_DAMAGE).setBaseValue(19.0D);
                    }
                } else if (new Random().nextInt(100) < 25) {
                    redSkeleton.equipStack(EquipmentSlot.MAINHAND, new ItemStack(RED_MOSS_METAL_SWORD));
                    if (redSkeleton.getAttributeInstance(EntityAttributes.GENERIC_ATTACK_DAMAGE) != null) {
                        redSkeleton.getAttributeInstance(EntityAttributes.GENERIC_ATTACK_DAMAGE).setBaseValue(7.0D);
                    }
                }
                // Add baby variant for Red Moss Druid Skeletons
                if (new Random().nextInt(100) < 15) { // 15% chance of being a baby
                    redSkeleton.setBaby(true);
                }

                // Add 80% opacity nodes/lasers connecting moss blocks to carpet blocks
                BlockPos skeletonPos = redSkeleton.getBlockPos();
                Random random = new Random();
                for (int i = 0; i < 16; i++) {
                    BlockPos targetPos = skeletonPos.add(random.nextInt(16) - 8, random.nextInt(4) - 2, random.nextInt(16) - 8);
                    if (world.getBlockState(targetPos).getBlock() instanceof RedMossBlock || world.getBlockState(targetPos).getBlock() instanceof RedMossCarpetBlock) {
                        // Spawn Red Moss Opacity Line Entity to represent node/laser
                        RedMossOpacityLineEntity lineEntity = new RedMossOpacityLineEntity(RED_MOSS_OPACITY_LINE, world);
                        lineEntity.setPositions(skeletonPos, targetPos);
                        world.spawnEntity(lineEntity);
                    }
                }
            }
        });

        // Register structure generation
        Registry.register(Registry.FEATURE, new Identifier(MODID, "red_stronghold"), new RedStrongholdFeature(DefaultFeatureConfig.CODEC));

        // Register custom biomes
        Registry.register(Registry.BIOME, new Identifier(MODID, "red_moss_forest"), createRedMossForest());
        Registry.register(Registry.BIOME, new Identifier(MODID, "vanilla_moss_forest"), createVanillaMossForest());
    }

    @Override
    public void onInitializeClient() {
        // Register custom renderer for Skeleton
        EntityRendererRegistry.INSTANCE.register(RedMossDruidSkeletonEntity.class, (context) -> new CustomSkeletonRenderer(context));
        // Register custom renderer for Opacity Line
        EntityRendererRegistry.INSTANCE.register(RedMossOpacityLineEntity.class, (context) -> new RedMossOpacityLineRenderer(context));
    }

    private Biome createRedMossForest() {
        SpawnSettings.Builder spawnSettings = new SpawnSettings.Builder();
        spawnSettings.spawn(SpawnGroup.MONSTER, new SpawnSettings.SpawnEntry(RED_MOSS_DRUID_SKELETON, 100, 4, 4));

        GenerationSettings.Builder generationSettings = new GenerationSettings.Builder();
        generationSettings.feature(GenerationStep.Feature.VEGETAL_DECORATION, Feature.RANDOM_PATCH.configure(DefaultFeatureConfig.INSTANCE));

        BiomeEffects.Builder effects = new BiomeEffects.Builder();
        effects.foliageColor(0x2A5A1F).grassColor(0x2A5A1F).waterColor(0x3FBFFF).waterFogColor(0x050533);

        return new Biome.Builder()
                .precipitation(Biome.Precipitation.RAIN)
                .category(Biome.Category.FOREST)
                .temperature(0.7F)
                .downfall(0.8F)
                .effects(effects.build())
                .spawnSettings(spawnSettings.build())
                .generationSettings(generationSettings.build())
                .build();
    }

    private Biome createVanillaMossForest() {
        SpawnSettings.Builder spawnSettings = new SpawnSettings.Builder();

        GenerationSettings.Builder generationSettings = new GenerationSettings.Builder();
        generationSettings.feature(GenerationStep.Feature.VEGETAL_DECORATION, Feature.RANDOM_PATCH.configure(DefaultFeatureConfig.INSTANCE));

        BiomeEffects.Builder effects = new BiomeEffects.Builder();
        effects.foliageColor(0x2A5A1F).grassColor(0x2A5A1F).waterColor(0x3FBFFF).waterFogColor(0x050533);

        return new Biome.Builder()
                .precipitation(Biome.Precipitation.RAIN)
                .category(Biome.Category.FOREST)
                .temperature(0.7F)
                .downfall(0.8F)
                .effects(effects.build())
                .spawnSettings(spawnSettings.build())
                .generationSettings(generationSettings.build())
                .build();
    }
}
