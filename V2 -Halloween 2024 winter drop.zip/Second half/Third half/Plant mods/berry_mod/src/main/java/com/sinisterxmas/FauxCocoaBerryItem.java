package com.sinisterxmas;

import net.minecraft.block.Block;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class FauxCocoaBerryItem extends Item {
    private final Block block;

    public FauxCocoaBerryItem(Block block, Item.Settings settings) {
        super(settings);
        this.block = block;
    }

    @Override
    public ActionResult useOnBlock(ItemPlacementContext context) {
        World world = context.getWorld();
        BlockPos pos = context.getBlockPos().offset(context.getSide());
        PlayerEntity player = context.getPlayer();
        ItemStack itemStack = context.getStack();
        
        if (player.canPlaceOn(pos, context.getSide(), itemStack) && world.getBlockState(pos).isAir()) {
            world.setBlockState(pos, block.getDefaultState().with(FauxCocoaBerryBushBlock.AGE, 0));
            world.playSound(player, pos, SoundEvents.ITEM_CROP_PLANT, SoundCategory.BLOCKS, 1.0F, 1.0F);
            if (!player.getAbilities().creativeMode) {
                itemStack.decrement(1);
            }
            return ActionResult.SUCCESS;
        }

        return ActionResult.FAIL;
    }

    @Override
    public ItemStack finishUsing(ItemStack stack, World world, PlayerEntity user) {
        user.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 1000, 2));
        return super.finishUsing(stack, world, user);
    }
}