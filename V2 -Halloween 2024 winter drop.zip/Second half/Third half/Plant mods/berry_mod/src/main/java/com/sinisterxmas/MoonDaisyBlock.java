package com.sinisterxmas;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.PlantBlock;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.Random;

public class MoonDaisyBlock extends PlantBlock {
    public static final BooleanProperty GLOWING = Properties.LIT;

    public MoonDaisyBlock(Settings settings) {
        super(settings);
        setDefaultState(getStateManager().getDefaultState().with(GLOWING, false));
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(GLOWING);
    }

    @Override
    public void randomTick(BlockState state, ServerWorld world, BlockPos pos, Random random) {
        if (world.isNight() && world.getMoonSize() == 1.0F) {
            if (random.nextInt(10) == 0) {
                world.setBlockState(pos, state.with(GLOWING, true));
            }
        } else {
            world.setBlockState(pos, state.with(GLOWING, false));
        }
        super.randomTick(state, world, pos, random);
    }

    @Override
    public void onStacksDropped(BlockState state, ServerWorld world, BlockPos pos, int fortune) {
        super.onStacksDropped(state, world, pos, fortune);
        if (state.get(GLOWING)) {
            dropStack(world, pos, new ItemStack(Items.GLOWSTONE_DUST, random.nextInt(2) + 1));
        }
    }
}