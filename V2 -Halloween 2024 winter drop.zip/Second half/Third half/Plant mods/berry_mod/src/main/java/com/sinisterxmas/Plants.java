package com.sinisterxmas;

import net.minecraft.block.Block;
import net.minecraft.block.Material;
import net.minecraft.item.BlockItem;
import net.minecraft.item.FoodComponent;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import org.quiltmc.qsl.block.extensions.api.QuiltBlockSettings;

public class Plants {
    // Define the Frost Berry Bush block
    public static final Block FROST_BERRY_BUSH = new FrostBerryBushBlock(QuiltBlockSettings.of(Material.PLANT)
            .noCollision().ticksRandomly().breakInstantly().sounds(BlockSoundGroup.GRASS));

    // Define the Frost Berry item
    public static final Item FROST_BERRY = new FrostBerryItem(FROST_BERRY_BUSH, new Item.Settings()
            .group(ItemGroup.FOOD)
            .food(new FoodComponent.Builder()
                    .hunger(4)
                    .saturationModifier(8.0F)
                    .statusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 200, 1), 1.0F)
                    .build()));

    // Define the Frost Berry Drink item
    public static final Item FROST_BERRY_DRINK = new Item(new Item.Settings()
            .group(ItemGroup.BREWING)
            .food(new FoodComponent.Builder()
                    .hunger(2)
                    .saturationModifier(4.0F)
                    .statusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 400, 1), 1.0F)
                    .statusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 400, 0), 1.0F)
                    .build()));

    // Define the Frost Berry Pie item
    public static final Item FROST_BERRY_PIE = new Item(new Item.Settings()
            .group(ItemGroup.FOOD)
            .food(new FoodComponent.Builder()
                    .hunger(8)
                    .saturationModifier(8.0F)
                    .build()));

    // Define the Lava Berry Bush block
    public static final Block LAVA_BERRY_BUSH = new LavaBerryBushBlock(QuiltBlockSettings.of(Material.PLANT)
            .noCollision().ticksRandomly().breakInstantly().sounds(BlockSoundGroup.GRASS));

    // Define the Lava Berry item
    public static final Item LAVA_BERRY = new LavaBerryItem(LAVA_BERRY_BUSH, new Item.Settings()
            .group(ItemGroup.FOOD)
            .food(new FoodComponent.Builder()
                    .hunger(4)
                    .saturationModifier(8.0F)
                    .build()));

    // Define the Lava Berry Drink item
    public static final Item LAVA_BERRY_DRINK = new Item(new Item.Settings()
            .group(ItemGroup.BREWING)
            .food(new FoodComponent.Builder()
                    .hunger(2)
                    .saturationModifier(4.0F)
                    .statusEffect(new StatusEffectInstance(StatusEffects.FIRE_RESISTANCE, 400, 0), 1.0F)
                    .alwaysEdible()
                    .build()));

    // Define the Lava Berry Pie item
    public static final Item LAVA_BERRY_PIE = new Item(new Item.Settings()
            .group(ItemGroup.FOOD)
            .food(new FoodComponent.Builder()
                    .hunger(8)
                    .saturationModifier(8.0F)
                    .build()));

    // Define the Faux Cocoa Berry Bush block
    public static final Block FAUX_COCOA_BERRY_BUSH = new FauxCocoaBerryBushBlock(QuiltBlockSettings.of(Material.PLANT)
            .noCollision().ticksRandomly().breakInstantly().sounds(BlockSoundGroup.GRASS));

    // Define the Faux Cocoa Berry item
    public static final Item FAUX_COCOA_BERRY = new FauxCocoaBerryItem(FAUX_COCOA_BERRY_BUSH, new Item.Settings()
            .group(ItemGroup.FOOD)
            .food(new FoodComponent.Builder()
                    .hunger(4)
                    .saturationModifier(8.0F)
                    .statusEffect(new StatusEffectInstance(StatusEffects.SPEED, 1000, 2), 1.0F)
                    .build()));

    // Define the Faux Cocoa Berry Drink item
    public static final Item FAUX_COCOA_BERRY_DRINK = new Item(new Item.Settings()
            .group(ItemGroup.BREWING)
            .food(new FoodComponent.Builder()
                    .hunger(2)
                    .saturationModifier(4.0F)
                    .statusEffect(new StatusEffectInstance(StatusEffects.SPEED, 600, 3), 1.0F)
                    .statusEffect(new StatusEffectInstance(StatusEffects.JUMP_BOOST, 600, 3), 1.0F)
                    .build()));

    // Define the Faux Cocoa Berry Pie item
    public static final Item FAUX_COCOA_BERRY_PIE = new Item(new Item.Settings()
            .group(ItemGroup.FOOD)
            .food(new FoodComponent.Builder()
                    .hunger(8)
                    .saturationModifier(8.0F)
                    .build()));

public static final Item COMMON_MUG = new CommonMug();

    // Define the Moon Daisy block
    public static final Block MOON_DAISY = new MoonDaisyBlock(QuiltBlockSettings.of(Material.PLANT)
            .noCollision().breakInstantly().sounds(BlockSoundGroup.GRASS));

    // Define the Bloody Rose block
    public static final Block BLOODY_ROSE = new BloodyRoseBlock(QuiltBlockSettings.of(Material.PLANT)
            .noCollision().breakInstantly().sounds(BlockSoundGroup.GRASS));

    public static void registerPlants() {
        // Register the Frost Berry Bush block
        Registry.register(Registry.BLOCK, new Identifier(SinisterXmasMod.MODID, "frost_berry_bush"), FROST_BERRY_BUSH);
        // Register the Frost Berry Bush block item
        Registry.register(Registry.ITEM, new Identifier(SinisterXmasMod.MODID, "frost_berry_bush"),
                new BlockItem(FROST_BERRY_BUSH, new Item.Settings().group(ItemGroup.DECORATIONS)));
        // Register the Frost Berry item
        Registry.register(Registry.ITEM, new Identifier(SinisterXmasMod.MODID, "frost_berry"), FROST_BERRY);

        // Register the Lava Berry Bush block
        Registry.register(Registry.BLOCK, new Identifier(SinisterXmasMod.MODID, "lava_berry_bush"), LAVA_BERRY_BUSH);
        // Register the Lava Berry Bush block item
        Registry.register(Registry.ITEM, new Identifier(SinisterXmasMod.MODID, "lava_berry_bush"),
                new BlockItem(LAVA_BERRY_BUSH, new Item.Settings().group(ItemGroup.DECORATIONS)));
        // Register the Lava Berry item
        Registry.register(Registry.ITEM, new Identifier(SinisterXmasMod.MODID, "lava_berry"), LAVA_BERRY);

        // Register the Faux Cocoa Berry Bush block
        Registry.register(Registry.BLOCK, new Identifier(SinisterXmasMod.MODID, "faux_cocoa_berry_bush"), FAUX_COCOA_BERRY_BUSH);
        // Register the Faux Cocoa Berry Bush block item
        Registry.register(Registry.ITEM, new Identifier(SinisterXmasMod.MODID, "faux_cocoa_berry_bush"),
                new BlockItem(FAUX_COCOA_BERRY_BUSH, new Item.Settings().group(ItemGroup.DECORATIONS)));
        // Register the Faux Cocoa Berry item
        Registry.register(Registry.ITEM, new Identifier(SinisterXmasMod.MODID, "faux_cocoa_berry"), FAUX_COCOA_BERRY);

        // Register the Moon Daisy block
        Registry.register(Registry.BLOCK, new Identifier(SinisterXmasMod.MODID, "moon_daisy"), MOON_DAISY);
        // Register the Moon Daisy block item
        Registry.register(Registry.ITEM, new Identifier(SinisterXmasMod.MODID, "moon_daisy"),
                new BlockItem(MOON_DAISY, new Item.Settings().group(ItemGroup.DECORATIONS)));

        // Register the Bloody Rose block
        Registry.register(Registry.BLOCK, new 
        Identifier(SinisterXmasMod.MODID, "bloody_rose"), BLOODY_ROSE);
        // Register the Bloody Rose block item
        Registry.register(Registry.ITEM, new Identifier(SinisterXmasMod.MODID, "bloody_rose"),
                new BlockItem(BLOODY_ROSE, new Item.Settings().group(ItemGroup.DECORATIONS)));
    }

    public static void registerItems() {
        // Register the drinks
        Registry.register(Registry.ITEM, new Identifier(SinisterXmasMod.MODID, "frost_berry_drink"), FROST_BERRY_DRINK);
        Registry.register(Registry.ITEM, new Identifier(SinisterXmasMod.MODID, "lava_berry_drink"), LAVA_BERRY_DRINK);
        Registry.register(Registry.ITEM, new Identifier(SinisterXmasMod.MODID, "faux_cocoa_berry_drink"), FAUX_COCOA_BERRY_DRINK);
        // Register the pies
        Registry.register(Registry.ITEM, new Identifier(SinisterXmasMod.MODID, "frost_berry_pie"), FROST_BERRY_PIE);
        Registry.register(Registry.ITEM, new Identifier(SinisterXmasMod.MODID, "lava_berry_pie"), LAVA_BERRY_PIE);
Registry.register(Registry.ITEM, new Identifier(SinisterXmasMod.MODID, “faux_cocoa_berry_pie”), FAUX_COCOA_BERRY_PIE);￼

Registry.register(Registry.ITEM, new Identifier("sinisterxmas", "common_mug"), COMMON_MUG);

}
}