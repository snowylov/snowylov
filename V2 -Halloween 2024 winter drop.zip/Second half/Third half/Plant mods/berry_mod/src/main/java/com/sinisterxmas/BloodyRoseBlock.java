package com.sinisterxmas;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.PlantBlock;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.Random;

public class BloodyRoseBlock extends PlantBlock {
    public static final BooleanProperty BLOOMING = Properties.LIT;

    public BloodyRoseBlock(Settings settings) {
        super(settings);
        setDefaultState(getStateManager().getDefaultState().with(BLOOMING, false));
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(BLOOMING);
    }

    @Override
    public void randomTick(BlockState state, ServerWorld world, BlockPos pos, Random random) {
        if (random.nextInt(10) == 0) {
            world.setBlockState(pos, state.with(BLOOMING, true));
        } else {
            world.setBlockState(pos, state.with(BLOOMING, false));
        }
        super.randomTick(state, world, pos, random);
    }

    @Override
    public void onSteppedOn(World world, BlockPos pos, BlockState state, LivingEntity entity) {
        if (state.get(BLOOMING)) {
            if (entity instanceof PlayerEntity) {
                PlayerEntity player = (PlayerEntity) entity;
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 200, 1));
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.ABSORPTION, 200, 1));
            } else {
                entity.damage(DamageSource.MAGIC, 1.0F);
            }
        }
        super.onSteppedOn(world, pos, state, entity);
    }
}