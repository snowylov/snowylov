public static final class CommonMug extends Item {
        public CommonMug() {
            super(new Settings().group(ItemGroup.MISC));
        }
    }