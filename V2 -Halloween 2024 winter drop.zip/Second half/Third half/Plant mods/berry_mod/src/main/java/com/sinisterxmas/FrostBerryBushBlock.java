package com.sinisterxmas;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.PlantBlock;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.stat.Stats;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.IntProperty;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;

public class FrostBerryBushBlock extends PlantBlock {
    public static final IntProperty AGE = IntProperty.of("age", 0, 3);

    public FrostBerryBushBlock(Settings settings) {
        super(settings);
        this.setDefaultState(this.stateManager.getDefaultState().with(AGE, 0));
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(AGE);
    }

    @Override
    public void randomTick(BlockState state, ServerWorld world, BlockPos pos, Random random) {
        int age = state.get(AGE);
        if (age < 3 && random.nextInt(10) == 0) {
            world.setBlockState(pos, state.with(AGE, age + 1), 2);
        }
    }

    @Override
    public ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, Hand hand, BlockHitResult hit) {
        int age = state.get(AGE);
        boolean mature = age == 3;
        if (!mature && player.getStackInHand(hand).isEmpty()) {
            return ActionResult.PASS;
        } else if (mature) {
            dropStack(world, pos, new ItemStack(Plants.FROST_BERRY, 1));
            world.setBlockState(pos, state.with(AGE, 0), 2);
            world.playSound(null, pos, SoundEvents.ITEM_SWEET_BERRIES_PICK_FROM_BUSH, 1.0F, 1.0F);
            player.incrementStat(Stats.USED.getOrCreateStat(player.getStackInHand(hand).getItem()));
            return ActionResult.success(world.isClient);
        } else {
            return ActionResult.PASS;
        }
    }
}