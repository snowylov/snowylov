package com.sinisterxmas;

import net.fabricmc.api.ModInitializer;

public class SinisterXmasMod implements ModInitializer {
    public static final String MODID = "sinisterxmas";

   

    public static final class BrewingRecipes {
        public static void register() {
            BrewingRecipeRegistry.registerPotionRecipe(Plants.COMMON_MUG, Plants.LAVA_BERRY_ITEM, Plants.LAVA_BERRY_JUICE);
            BrewingRecipeRegistry.registerPotionRecipe(Plants.COMMON_MUG, Plants.FROST_BERRY_ITEM, Plants.FROST_BERRY_JUICE);
            BrewingRecipeRegistry.registerPotionRecipe(Plants.COMMON_MUG, Plants.FAUX_COCOA_BERRY_ITEM, Plants.FAUX_COCOA_BERRY_JUICE);
        }
    }

    @Override
    public void onInitialize() {
        // Register custom plants
        Plants.registerPlants();
        BrewingRecipes.register();
    }
}