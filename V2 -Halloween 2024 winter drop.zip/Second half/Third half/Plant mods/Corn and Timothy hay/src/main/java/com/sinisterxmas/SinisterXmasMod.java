
package com.sinisterxmas;

import net.fabricmc.api.ModInitializer;

public class SinisterXmasMod implements ModInitializer {
    public static final String MOD_ID = "sinisterxmas";

    @Override
    public void onInitialize() {
        ItemsRegistry.registerItems();
        BlocksRegistry.registerBlocks();
    }
}
