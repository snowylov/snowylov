
package com.sinisterxmas;

import com.sinisterxmas.block.CornCropBlock;
import com.sinisterxmas.block.TimothyHayCropBlock;
import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.minecraft.block.Block;
import net.minecraft.block.Material;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

public class BlocksRegistry {
    public static final Block TIMOTHY_HAY_CROP = new TimothyHayCropBlock(FabricBlockSettings.of(Material.PLANT).noCollision().ticksRandomly().breakInstantly().sounds(BlockSoundGroup.CROP));
    public static final Block TIMOTHY_HAY_BLOCK = new Block(FabricBlockSettings.of(Material.ORGANIC_PRODUCT).strength(1.0f).sounds(BlockSoundGroup.GRASS));

    public static final Block CORN_CROP = new CornCropBlock(FabricBlockSettings.of(Material.PLANT).noCollision().ticksRandomly().breakInstantly().sounds(BlockSoundGroup.CROP));

    public static void registerBlocks() {
        Registry.register(Registry.BLOCK, new Identifier(SinisterXmasMod.MOD_ID, "timothy_hay_crop"), TIMOTHY_HAY_CROP);
        Registry.register(Registry.BLOCK, new Identifier(SinisterXmasMod.MOD_ID, "timothy_hay_block"), TIMOTHY_HAY_BLOCK);
        Registry.register(Registry.ITEM, new Identifier(SinisterXmasMod.MOD_ID, "timothy_hay_block"), new BlockItem(TIMOTHY_HAY_BLOCK, new Item.Settings().group(ItemGroup.BUILDING_BLOCKS)));

        Registry.register(Registry.BLOCK, new Identifier(SinisterXmasMod.MOD_ID, "corn_crop"), CORN_CROP);
    }
}
