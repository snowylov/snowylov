package com.sinisterxmas;

import net.minecraft.item.FoodComponent;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

public class ItemsRegistry {
    public static final Item TIMOTHY_HAY = new Item(new Item.Settings().group(ItemGroup.MISC));
    public static final Item TIMOTHY_HAY_CUBE = new Item(new Item.Settings().group(ItemGroup.MISC));
    public static final Item TIMOTHY_HAY_BUNDLE = new Item(new Item.Settings().group(ItemGroup.MISC));
    public static final Item TIMOTHY_HAY_SEEDS = new Item(new Item.Settings().group(ItemGroup.MISC));

    public static final Item CORNCOB = new Item(new Item.Settings().group(ItemGroup.FOOD).food(new FoodComponent.Builder().hunger(3).saturationModifier(0.6F).build()));
    public static final Item CORN = new Item(new Item.Settings().group(ItemGroup.FOOD));
    public static final Item RAW_CANDY_CORN = new Item(new Item.Settings().group(ItemGroup.FOOD));
    public static final Item CANDY_CORN = new Item(new Item.Settings().group(ItemGroup.FOOD).food(new FoodComponent.Builder().hunger(2).saturationModifier(0.1F).build()));
    public static final Item CORN_FLOUR = new Item(new Item.Settings().group(ItemGroup.MISC));
    public static final Item CORN_BREAD = new Item(new Item.Settings().group(ItemGroup.FOOD).food(new FoodComponent.Builder().hunger(5).saturationModifier(0.6F).build()));

    public static final Item CORN_SEEDS = new Item(new Item.Settings().group(ItemGroup.MISC));
    public static final Item POPCORN = new Item(new Item.Settings().group(ItemGroup.FOOD).food(new FoodComponent.Builder().hunger(1).saturationModifier(0.4F).build()));
    public static final Item RAW_TORTILLA = new Item(new Item.Settings().group(ItemGroup.MISC));
    public static final Item TORTILLA = new Item(new Item.Settings().group(ItemGroup.FOOD).food(new FoodComponent.Builder().hunger(3).saturationModifier(0.6F).build()));
    public static final Item TORTILLA_CHIP = new Item(new Item.Settings().group(ItemGroup.FOOD).food(new FoodComponent.Builder().hunger(2).saturationModifier(0.3F).build()));
    public static final Item NACHOS = new Item(new Item.Settings().group(ItemGroup.FOOD).food(new FoodComponent.Builder().hunger(8).saturationModifier(0.8F).build()));

    public static void registerItems() {
        Registry.register(Registry.ITEM, new Identifier(SinisterXmasMod.MOD_ID, "timothy_hay"), TIMOTHY_HAY);
        Registry.register(Registry.ITEM, new Identifier(SinisterXmasMod.MOD_ID, "timothy_hay_cube"), TIMOTHY_HAY_CUBE);
        Registry.register(Registry.ITEM, new Identifier(SinisterXmasMod.MOD_ID, "timothy_hay_bundle"), TIMOTHY_HAY_BUNDLE);
        Registry.register(Registry.ITEM, new Identifier(SinisterXmasMod.MOD_ID, "timothy_hay_seeds"), TIMOTHY_HAY_SEEDS);

        Registry.register(Registry.ITEM, new Identifier(SinisterXmasMod.MOD_ID, "corncob"), CORNCOB);
        Registry.register(Registry.ITEM, new Identifier(SinisterXmasMod.MOD_ID, "corn"), CORN);
        Registry.register(Registry.ITEM, new Identifier(SinisterXmasMod.MOD_ID, "raw_candy_corn"), RAW_CANDY_CORN);
        Registry.register(Registry.ITEM, new Identifier(SinisterXmasMod.MOD_ID, "candy_corn"), CANDY_CORN);
        Registry.register(Registry.ITEM, new Identifier(SinisterXmasMod.MOD_ID, "corn_flour"), CORN_FLOUR);
        Registry.register(Registry.ITEM, new Identifier(SinisterXmasMod.MOD_ID, "corn_bread"), CORN_BREAD);

        Registry.register(Registry.ITEM, new Identifier(SinisterXmasMod.MOD_ID, "corn_seeds"), CORN_SEEDS);
        Registry.register(Registry.ITEM, new Identifier(SinisterXmasMod.MOD_ID, "popcorn"), POPCORN);
        Registry.register(Registry.ITEM, new Identifier(SinisterXmasMod.MOD_ID, "raw_tortilla"), RAW_TORTILLA);
        Registry.register(Registry.ITEM, new Identifier(SinisterXmasMod.MOD_ID, "tortilla"), TORTILLA);
        Registry.register(Registry.ITEM, new Identifier(SinisterXmasMod.MOD_ID, "tortilla_chip"), TORTILLA_CHIP);
        Registry.register(Registry.ITEM, new Identifier(SinisterXmasMod.MOD_ID, "nachos"), NACHOS);
    }
}