
package com.sinisterxmas.block;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.CropBlock;
import net.minecraft.item.ItemConvertible;
import net.minecraft.item.Items;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.IntProperty;
import net.minecraft.state.property.Properties;

public class TimothyHayCropBlock extends CropBlock {
    public static final IntProperty AGE = Properties.AGE_7;

    public TimothyHayCropBlock(Block.Settings settings) {
        super(settings);
    }

    @Override
    protected ItemConvertible getSeedsItem() {
        return ItemsRegistry.TIMOTHY_HAY_SEEDS;
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(AGE);
    }

    @Override
    public void randomTick(BlockState state, ServerWorld world, BlockPos pos, RandomGenerator random) {
        super.randomTick(state, world, pos, random);
    }

    @Override
    public ItemStack getPickStack(BlockView world, BlockPos pos, BlockState state) {
        return new ItemStack(ItemsRegistry.TIMOTHY_HAY_SEEDS);
    }

    @Override
    protected List<ItemStack> getDroppedStacks(BlockState state, net.minecraft.loot.context.LootContext.Builder builder) {
        List<ItemStack> drops = super.getDroppedStacks(state, builder);
        if (state.get(AGE) == 7) {  // Fully grown
            drops.add(new ItemStack(ItemsRegistry.TIMOTHY_HAY, 1));
        }
        return drops;
    }
}
