package com.example.enderlavish.datagen;

import net.fabricmc.fabric.api.datagen.v1.FabricDataGenerator;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricBlockLootTableProvider;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricModelProvider;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricBlockStateProvider;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricLanguageProvider;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricItemModelProvider;
import net.minecraft.data.server.BlockLootTableGenerator;
import net.minecraft.item.Items;
import net.minecraft.util.Identifier;

public class EnderLavishDataGenerator implements ModInitializer {

    @Override
    public void onInitialize() {
        FabricDataGenerator dataGenerator = new FabricDataGenerator(new File("output"), null);
        dataGenerator.addProvider(EnderLavishBlockStateProvider::new);
        dataGenerator.addProvider(EnderLavishModelProvider::new);
        dataGenerator.addProvider(EnderLavishLootTableProvider::new);
        dataGenerator.addProvider(EnderLavishLanguageProvider::new);
    }

    public static class EnderLavishBlockStateProvider extends FabricBlockStateProvider {

        public EnderLavishBlockStateProvider(FabricDataGenerator dataGenerator) {
            super(dataGenerator);
        }

        @Override
        protected void generateBlockState() {
            getVariantBuilder(ModBlocks.ENDER_LAVISH_CROP)
                .partialState().with(CropBlock.AGE, 0).modelForState().modelFile(new Identifier("enderlavish", "block/ender_lavish_stage0")).addModel()
                .partialState().with(CropBlock.AGE, 1).modelForState().modelFile(new Identifier("enderlavish", "block/ender_lavish_stage1")).addModel();
        }
    }

    public static class EnderLavishModelProvider extends FabricItemModelProvider {

        public EnderLavishModelProvider(FabricDataGenerator dataGenerator) {
            super(dataGenerator);
        }

        @Override
        protected void generateItemModels() {
            singleTexture("ender_lavish", new Identifier("item/generated"), "layer0", new Identifier("enderlavish", "item/ender_lavish_seed"));
            singleTexture("ender_thistle", new Identifier("item/generated"), "layer0", new Identifier("enderlavish", "item/ender_thistle"));
        }
    }

    public static class EnderLavishLootTableProvider extends FabricBlockLootTableProvider {

        public EnderLavishLootTableProvider(FabricDataGenerator dataGenerator) {
            super(dataGenerator);
        }

        @Override
        protected void generateBlockLootTables() {
            addDrop(ModBlocks.ENDER_LAVISH_CROP, BlockLootTableGenerator.dropsWithShears(ModBlocks.ENDER_LAVISH_CROP, ModItems.ENDER_LAVISH_SEEDS));
            addDrop(ModItems.ENDER_LAVISH_SEEDS, item -> item.withFunction(setCount(ConstantValue.exactly(1))).withFunction(ApplyBonus.uniformBonusCount(Enchantments.FORTUNE)));
        }
    }

    public static class EnderLavishLanguageProvider extends FabricLanguageProvider {

        public EnderLavishLanguageProvider(FabricDataGenerator dataGenerator) {
            super(dataGenerator);
        }

        @Override
        protected void generateTranslations() {
            addItem(ModItems.ENDER_LAVISH_SEEDS, "Ender Lavish Seeds");
            addItem(ModItems.ENDER_THISTLE, "Ender Thistle");
            addBlock(ModBlocks.ENDER_LAVISH_CROP, "Ender Lavish Crop");
        }
    }
}