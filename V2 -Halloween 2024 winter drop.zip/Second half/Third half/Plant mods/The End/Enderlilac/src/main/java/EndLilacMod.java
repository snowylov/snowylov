package com.example.end_lilac;

import org.quiltmc.loader.api.ModContainer;
import org.quiltmc.qsl.base.api.entrypoint.ModInitializer;
import org.quiltmc.qsl.item.setting.api.QuiltItemSettings;
import org.quiltmc.qsl.block.entity.api.QuiltBlockEntityTypeBuilder;
import org.quiltmc.qsl.registry.Registrar;
import org.quiltmc.qsl.registry.api.RegistryEntry;
import org.quiltmc.qsl.registry.api.RegistryKey;
import org.quiltmc.qsl.registry.api.RegistryManager;
import org.quiltmc.qsl.registry.api.entry.RegistryEntryReference;
import org.quiltmc.qsl.registry.api.entry.RegistryKeyBuilder;
import org.quiltmc.qsl.potion.api.QuiltBrewingRecipeRegistry;

import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.FlowerBlock;
import net.minecraft.data.server.recipe.RecipeJsonProvider;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectCategory;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.Items;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionUtil;
import net.minecraft.potion.Potions;
import net.minecraft.recipe.Ingredient;
import net.minecraft.recipe.ShapelessRecipeJsonBuilder;
import net.minecraft.util.Identifier;

import java.util.function.Consumer;

public class EndLilacMod implements ModInitializer {
    public static final String MOD_ID = "end_lilac";

public static final Block POTTED_END_LILAC = new FlowerPotBlock(() -> (FlowerPotBlock) Blocks.FLOWER_POT, END_LILAC_BLOCK::get, FabricBlockSettings.copy(Blocks.POTTED_POPPY));

    // Register the End Lilac block and item
    public static final RegistryKey<Block> END_LILAC_BLOCK_KEY = RegistryKey.of(RegistryManager.BLOCK, new Identifier(MOD_ID, "end_lilac"));
    public static final RegistryEntryReference<Block> END_LILAC_BLOCK = RegistryManager.BLOCK.createRegistryEntryReference(END_LILAC_BLOCK_KEY, new FlowerBlock(StatusEffects.NIGHT_VISION, 0, QuiltBlockEntityTypeBuilder.create(Blocks.DANDELION)));

    public static final RegistryKey<Item> END_LILAC_ITEM_KEY = RegistryKey.of(RegistryManager.ITEM, new Identifier(MOD_ID, "end_lilac"));
    public static final RegistryEntryReference<Item> END_LILAC_ITEM = RegistryManager.ITEM.createRegistryEntryReference(END_LILAC_ITEM_KEY, new Item(new QuiltItemSettings().group(ItemGroup.DECORATIONS)));

    // Potion Effect and Potion
    public static final StatusEffect ENDER_BOOST_EFFECT = new StatusEffect(StatusEffectCategory.BENEFICIAL, 0x6600FF) {
        @Override
        public void applyUpdateEffect(net.minecraft.entity.LivingEntity entity, int amplifier) {
            entity.addStatusEffect(new net.minecraft.entity.effect.StatusEffectInstance(StatusEffects.SPEED, 200, amplifier, false, false, true));
            entity.addStatusEffect(new net.minecraft.entity.effect.StatusEffectInstance(StatusEffects.JUMP_BOOST, 200, amplifier, false, false, true));
        }

        @Override
        public boolean canApplyUpdateEffect(int duration, int amplifier) {
            return true;
        }
    };

    public static final Potion ENDER_BOOST_POTION = new Potion(new net.minecraft.entity.effect.StatusEffectInstance(ENDER_BOOST_EFFECT, 3600));

    @Override
    public void onInitialize(ModContainer mod) {
        // Register the End Lilac block and item
        RegistryManager.BLOCK.register(END_LILAC_BLOCK_KEY, END_LILAC_BLOCK.get());
        RegistryManager.ITEM.register(END_LILAC_ITEM_KEY, END_LILAC_ITEM.get());

Registry.register(Registry.BLOCK, new Identifier(MOD_ID, "potted_end_lilac"), POTTED_END_LILAC);

        // Register the Ender Boost effect and potion
        RegistryManager.STATUS_EFFECT.register(new Identifier(MOD_ID, "ender_boost"), ENDER_BOOST_EFFECT);
        RegistryManager.POTION.register(new Identifier(MOD_ID, "ender_boost"), ENDER_BOOST_POTION);

        // Register brewing recipe for Ender Boost Potion
        QuiltBrewingRecipeRegistry.registerPotionRecipe(Potions.AWKWARD, END_LILAC_ITEM.get(), ENDER_BOOST_POTION);
    }

    private static class ModRecipeProvider extends FabricRecipeProvider {
        public ModRecipeProvider(FabricDataGenerator dataGenerator) {
            super(dataGenerator);
        }

        @Override
        protected void generateRecipes(Consumer<RecipeJsonProvider> exporter) {
            // Shapeless recipe for End Lilac to Magenta Dye
            ShapelessRecipeJsonBuilder.create(Items.MAGENTA_DYE)
                .input(Ingredient.ofItems(END_LILAC_ITEM.get()))
                .criterion("has_end_lilac", conditionsFromItem(END_LILAC_ITEM.get()))
                .offerTo(exporter, new Identifier(MOD_ID, "magenta_dye_from_end_lilac"));
        }
    }
}