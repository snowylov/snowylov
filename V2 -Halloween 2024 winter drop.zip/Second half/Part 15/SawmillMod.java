package com.example.sawmillmod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.screenhandler.v1.ScreenHandlerRegistry;
import net.fabricmc.fabric.api.client.screenhandler.v1.ScreenRegistry;
import net.minecraft.block.*;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.Inventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.*;
import net.minecraft.recipe.*;
import net.minecraft.screen.*;
import net.minecraft.screen.slot.Slot;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.registry.Registry;
import net.minecraft.world.World;
import net.minecraft.util.JsonHelper;
import net.minecraft.network.PacketByteBuf;
import com.google.gson.JsonObject;

import java.util.Optional;

public class SawmillMod implements ModInitializer {

    public static final String MOD_ID = "sawmillmod";
    public static final Block SAWMILL_BLOCK = new SawmillBlock(AbstractBlock.Settings.of(Material.WOOD).noCollision());
    public static final ScreenHandlerType<SawmillScreenHandler> SAWMILL_SCREEN_HANDLER =
            ScreenHandlerRegistry.registerSimple(new Identifier(MOD_ID, "sawmill"), SawmillScreenHandler::new);

    @Override
    public void onInitialize() {
        // Register block and item
        Registry.register(Registry.BLOCK, new Identifier(MOD_ID, "sawmill"), SAWMILL_BLOCK);
        Registry.register(Registry.ITEM, new Identifier(MOD_ID, "sawmill"),
                new BlockItem(SAWMILL_BLOCK, new Item.Settings().group(ItemGroup.DECORATIONS)));

        // Register the screen
        ScreenRegistry.register(SAWMILL_SCREEN_HANDLER, SawmillScreen::new);

        // Register vanilla log to plank recipes via Java
        registerVanillaRecipes();
    }

    // Block Implementation
    public static class SawmillBlock extends Block {
        public SawmillBlock(Settings settings) {
            super(settings);
        }

        @Override
        public ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, Hand hand, BlockHitResult hit) {
            if (!world.isClient) {
                player.openHandledScreen(new ExtendedScreenHandlerFactory() {
                    @Override
                    public Text getDisplayName() {
                        return Text.of("Sawmill");
                    }

                    @Override
                    public SawmillScreenHandler createMenu(int syncId, PlayerInventory inv, PlayerEntity player) {
                        return new SawmillScreenHandler(syncId, inv);
                    }

                    @Override
                    public void writeScreenOpeningData(ServerPlayerEntity player, PacketByteBuf buf) {
                        buf.writeBlockPos(pos);
                    }
                });
            }
            return ActionResult.SUCCESS;
        }
    }

    // Screen Handler
    public static class SawmillScreenHandler extends ScreenHandler {
        private final Inventory inventory;

        public SawmillScreenHandler(int syncId, PlayerInventory playerInventory) {
            super(SAWMILL_SCREEN_HANDLER, syncId);
            this.inventory = new SimpleInventory(2); // Input and output slots

            // Input slot
            this.addSlot(new Slot(inventory, 0, 53, 34));
            // Output slot
            this.addSlot(new Slot(inventory, 1, 107, 34) {
                @Override
                public boolean canInsert(ItemStack stack) {
                    return false; // Output slot, no insert
                }
            });

            // Player Inventory Slots
            for (int i = 0; i < 3; ++i) {
                for (int j = 0; j < 9; ++j) {
                    this.addSlot(new Slot(playerInventory, j + i * 9 + 9, 8 + j * 18, 84 + i * 18));
                }
            }
            for (int k = 0; k < 9; ++k) {
                this.addSlot(new Slot(playerInventory, k, 8 + k * 18, 142));
            }
        }

        @Override
        public boolean canUse(PlayerEntity player) {
            return true;
        }

        // Processes the sawmill recipe (finds matching recipe)
        public void process() {
            ItemStack inputStack = inventory.getStack(0);
            Optional<SawmillRecipe> recipe = findMatchingRecipe(inputStack);

            if (recipe.isPresent()) {
                ItemStack result = recipe.get().getOutput();
                inventory.setStack(1, result.copy());
                inventory.removeStack(0, 1); // Remove the input item after crafting
            }
        }

        // Find matching sawmill recipe
        private Optional<SawmillRecipe> findMatchingRecipe(ItemStack input) {
            return world.getRecipeManager().getFirstMatch(SawmillRecipe.Type.INSTANCE, inventory, world);
        }
    }

    // Sawmill Recipe Class
    public static class SawmillRecipe implements Recipe<Inventory> {
        private final Identifier id;
        private final Ingredient input;
        private final ItemStack output;

        public SawmillRecipe(Identifier id, Ingredient input, ItemStack output) {
            this.id = id;
            this.input = input;
            this.output = output;
        }

        @Override
        public boolean matches(Inventory inv, World world) {
            return input.test(inv.getStack(0));
        }

        @Override
        public ItemStack craft(Inventory inv) {
            return output.copy();
        }

        @Override
        public boolean fits(int width, int height) {
            return true;
        }

        @Override
        public ItemStack getOutput() {
            return output;
        }

        @Override
        public Identifier getId() {
            return id;
        }

        @Override
        public RecipeSerializer<?> getSerializer() {
            return Serializer.INSTANCE;
        }

        @Override
        public RecipeType<?> getType() {
            return Type.INSTANCE;
        }

        public static class Type implements RecipeType<SawmillRecipe> {
            public static final Type INSTANCE = new Type();
        }

        public static class Serializer implements RecipeSerializer<SawmillRecipe> {
            public static final Serializer INSTANCE = new Serializer();

            @Override
            public SawmillRecipe read(Identifier id, JsonObject json) {
                Ingredient input = Ingredient.fromJson(json.get("input"));
                ItemStack output = ShapedRecipe.outputFromJson(JsonHelper.getObject(json, "output"));
                return new SawmillRecipe(id, input, output);
            }

            @Override
            public SawmillRecipe read(Identifier id, PacketByteBuf buf) {
                Ingredient input = Ingredient.fromPacket(buf);
                ItemStack output = buf.readItemStack();
                return new SawmillRecipe(id, input, output);
            }

            @Override
            public void write(PacketByteBuf buf, SawmillRecipe recipe) {
                recipe.input.write(buf);
                buf.writeItemStack(recipe.output);
            }
        }
    }

    // Register Vanilla Log to Plank Recipes
    private void registerVanillaRecipes() {
        // Oak Log -> 16 Oak Planks
        registerSawmillRecipe("sawmill_oak_log", Items.OAK_LOG, Items.STRIPPED_OAK_LOG, Items.OAK_PLANKS);
        
        // Birch Log -> 16 Birch Planks
        registerSawmillRecipe("sawmill_birch_log", Items.BIRCH_LOG, Items.STRIPPED_BIRCH_LOG, Items.BIRCH_PLANKS);

        // Spruce Log -> 16 Spruce Planks
        registerSawmillRecipe("sawmill_spruce_log", Items.SPRUCE_LOG, Items.STRIPPED_SPRUCE_LOG, Items.SPRUCE_PLANKS);

        // Jungle Log -> 16 Jungle Planks
        registerSawmillRecipe("sawmill_jungle_log", Items.JUNGLE_LOG, Items.STRIPPED_JUNGLE_LOG, Items.JUNGLE_PLANKS);

        // Acacia Log -> 16 Acacia Planks
        registerSawmillRecipe("sawmill_acacia_log", Items.ACACIA_LOG, Items.STRIPPED_ACACIA_LOG, Items.ACACIA_PLANKS);

        // Dark Oak Log -> 16 Dark Oak Planks
        registerSawmillRecipe("sawmill_dark_oak_log", Items.DARK_OAK_LOG, Items.STRIPPED_DARK_OAK_LOG, Items.DARK_OAK_PLANKS);

        // Mangrove Log -> 16 Mangrove Planks
        registerSawmillRecipe("sawmill_mangrove_log", Items.MANGROVE_LOG, Items.STRIPPED_MANGROVE_LOG, Items.MANGROVE_PLANKS);

        // Cherry Log -> 16 Cherry Planks
        registerSawmillRecipe("sawmill_cherry_log", Items.CHERRY_LOG, Items.STRIPPED_CHERRY_LOG, Items.CHERRY_PLANKS);
    }

    // Helper method to register sawmill recipes
    private void registerSawmillRecipe(String recipeId, Item log, Item strippedLog, Item outputPlank) {
        Registry.register(Registry.RECIPE_SERIALIZER, new Identifier(MOD_ID, recipeId), new SawmillRecipe(
                new Identifier(MOD_ID, recipeId),
                Ingredient.ofItems(log, strippedLog),
                new ItemStack(outputPlank, 16)
        ));
    }
}