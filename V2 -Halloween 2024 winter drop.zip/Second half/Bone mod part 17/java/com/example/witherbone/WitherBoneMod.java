package com.example.witherbone;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.datagen.v1.DataGeneratorEntrypoint;
import net.minecraft.block.Block;
import net.minecraft.block.Material;
import net.minecraft.data.DataGenerator;
import net.minecraft.data.server.loot.EntityLootTableGenerator;
import net.minecraft.data.server.recipe.RecipeProvider;
import net.minecraft.data.server.recipe.ShapedRecipeJsonBuilder;
import net.minecraft.data.server.recipe.ShapelessRecipeJsonBuilder;
import net.minecraft.data.client.ModelProvider;
import net.minecraft.data.client.ItemModelGenerator;
import net.minecraft.data.client.Models;
import net.minecraft.entity.EntityType;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.Items;
import net.minecraft.loot.LootPool;
import net.minecraft.loot.entry.ItemEntry;
import net.minecraft.loot.provider.number.ConstantLootNumberProvider;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;
import net.minecraft.data.server.loot.LootTableProvider;
import net.minecraft.data.server.recipe.RecipeJsonProvider;
import net.minecraft.loot.LootTable;

import java.util.function.Consumer;
import java.util.function.BiConsumer;

public class WitherBoneMod implements ModInitializer, DataGeneratorEntrypoint {

    // Define items and blocks
    public static final Item WITHER_BONE = new Item(new Item.Settings().group(ItemGroup.MATERIALS));
    public static final Item WITHER_BONEMEAL = new Item(new Item.Settings().group(ItemGroup.MATERIALS));

    // Define the Wither Bone Block
    public static final Block WITHER_BONE_BLOCK = new Block(Block.Settings.of(Material.STONE).strength(2.0f));

    @Override
    public void onInitialize() {
        // Register the items and block
        Registry.register(Registry.ITEM, new Identifier("witherbone", "wither_bone"), WITHER_BONE);
        Registry.register(Registry.ITEM, new Identifier("witherbone", "wither_bonemeal"), WITHER_BONEMEAL);
        Registry.register(Registry.BLOCK, new Identifier("witherbone", "wither_bone_block"), WITHER_BONE_BLOCK);
        Registry.register(Registry.ITEM, new Identifier("witherbone", "wither_bone_block"),
            new BlockItem(WITHER_BONE_BLOCK, new Item.Settings().group(ItemGroup.BUILDING_BLOCKS)));
    }

    @Override
    public void onInitializeDataGenerator(DataGenerator generator) {
        // Register loot table, recipe, model, and blockstate data providers
        generator.addProvider(new LootTableAndRecipeAndModelProvider());
    }

    // Single class that handles loot tables, recipes, models, and blockstates
    public static class LootTableAndRecipeAndModelProvider extends LootTableProvider {

        @Override
        public void generate(DataGenerator generator) {
            // Loot table generation
            generator.addProvider(new EntityLootTableGenerator() {
                @Override
                public void accept(BiConsumer<Identifier, LootTable.Builder> consumer) {
                    // Wither Skeleton loot table with both skull and wither bone
                    consumer.accept(EntityType.WITHER_SKELETON.getLootTableId(),
                            LootTable.builder()
                                    .pool(LootPool.builder()
                                            .rolls(ConstantLootNumberProvider.create(1))
                                            .with(ItemEntry.builder(Items.WITHER_SKELETON_SKULL))
                                            .with(ItemEntry.builder(WITHER_BONE))
                                    ));
                }
            });

            // Recipe generation
            generator.addProvider(new RecipeProvider() {
                @Override
                protected void generateRecipes(Consumer<RecipeJsonProvider> exporter) {
                    // Shapeless recipe for wither bonemeal from wither bone
                    ShapelessRecipeJsonBuilder.create(WITHER_BONEMEAL)
                            .input(WITHER_BONE)
                            .criterion("has_wither_bone", conditionsFromItem(WITHER_BONE))
                            .offerTo(exporter, new Identifier("witherbone", "wither_bonemeal"));

                    // Recipe for crafting Wither Bone Block from Wither Bones
                    ShapedRecipeJsonBuilder.create(WITHER_BONE_BLOCK)
                            .pattern("XXX")
                            .pattern("XXX")
                            .pattern("XXX")
                            .input('X', WITHER_BONE)
                            .criterion("has_wither_bone", conditionsFromItem(WITHER_BONE))
                            .offerTo(exporter, new Identifier("witherbone", "wither_bone_block"));

                    // Recipe for breaking Wither Bone Block back into 9 Wither Bones
                    ShapelessRecipeJsonBuilder.create(WITHER_BONE)
                            .input(WITHER_BONE_BLOCK)
                            .criterion("has_wither_bone_block", conditionsFromItem(WITHER_BONE_BLOCK))
                            .offerTo(exporter, new Identifier("witherbone", "wither_bone_block_to_bones"));
                }
            });

            // Model and blockstate generation
            generator.addProvider(new ModelProvider() {
                @Override
                protected void generateItemModels(ItemModelGenerator itemModelGenerator) {
                    // Generate item models for both items and block
                    itemModelGenerator.register(WITHER_BONE, Models.GENERATED);
                    itemModelGenerator.register(WITHER_BONEMEAL, Models.GENERATED);
                    itemModelGenerator.register(WITHER_BONE_BLOCK, Models.CUBE_BOTTOM_TOP);
                }

                @Override
                public void generateBlockStateModels(Consumer<ItemModelGenerator> consumer) {
                    // Blockstate model for the Wither Bone Block with top, bottom, and side textures
                    BlockModelBuilder.create(WITHER_BONE_BLOCK)
                            .parent("block/cube_bottom_top")
                            .texture("top", new Identifier("witherbone", "block/wither_bone_block_top"))
                            .texture("bottom", new Identifier("witherbone", "block/wither_bone_block_bottom"))
                            .texture("side", new Identifier("witherbone", "block/wither_bone_block_side"));
                }
            });
        }
    }
}