package trees.alex;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.fabricmc.fabric.api.registry.StrippableBlockRegistry;
import net.fabricmc.fabric.api.registry.FlammableBlockRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.ColorProviderRegistry;
import net.fabricmc.fabric.api.datagen.v1.FabricDataGenerator;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricBlockLootTableProvider;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricBlockStateProvider;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricModelProvider;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricItemModelProvider;
import net.fabricmc.fabric.api.tag.TagFactory;
import net.minecraft.block.*;
import net.minecraft.data.server.BlockTagsProvider;
import net.minecraft.data.server.ItemTagsProvider;
import net.minecraft.item.*;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.tag.BlockTags;
import net.minecraft.tag.ItemTags;
import net.minecraft.tag.Tag;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;
import net.minecraft.util.registry.RegistryKey;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.biome.BiomeEffects;
import net.minecraft.world.biome.BiomeKeys;
import net.minecraft.world.biome.GenerationSettings;
import net.minecraft.world.biome.SpawnSettings;
import net.minecraft.world.gen.GenerationStep;
import net.minecraft.world.gen.feature.*;
import net.minecraft.world.gen.feature.DefaultBiomeFeatures;
import net.minecraft.world.gen.feature.VegetationPlacedFeatures;
import net.minecraft.world.gen.stateprovider.SimpleBlockStateProvider;
import net.minecraft.world.gen.trunk.TrunkPlacerType;
import net.minecraft.world.gen.placer.HeightRangePlacementModifier;
import net.minecraft.world.gen.heightprovider.TrapezoidHeightProvider;
import java.util.Optional;
import java.util.Random;

public class BlitzelwoodMod implements ModInitializer {
    public static final String MOD_ID = "somethingBlitzelThisWayComes";

    // Blocks
    public static final Block COMMON_BLITZELWOOD_LOG = new PillarBlock(FabricBlockSettings.of(Material.WOOD).strength(2.0f).sounds(BlockSoundGroup.WOOD));
    public static final Block STRIPPED_COMMON_BLITZELWOOD_LOG = new PillarBlock(FabricBlockSettings.of(Material.WOOD).strength(2.0f).sounds(BlockSoundGroup.WOOD));
    public static final Block COMMON_BLITZELWOOD_WOOD = new PillarBlock(FabricBlockSettings.of(Material.WOOD).strength(2.0f).sounds(BlockSoundGroup.WOOD));
    public static final Block STRIPPED_COMMON_BLITZELWOOD_WOOD = new PillarBlock(FabricBlockSettings.of(Material.WOOD).strength(2.0f).sounds(BlockSoundGroup.WOOD));
    public static final Block COMMON_BLITZELWOOD_PLANKS = new Block(FabricBlockSettings.of(Material.WOOD).strength(2.0f).sounds(BlockSoundGroup.WOOD));
    public static final Block COMMON_BLITZELWOOD_LEAVES = new LeavesBlock(FabricBlockSettings.of(Material.LEAVES).strength(0.2f).ticksRandomly().sounds(BlockSoundGroup.GRASS).nonOpaque());
    public static final SlabBlock COMMON_BLITZELWOOD_SLAB = new SlabBlock(FabricBlockSettings.of(Material.WOOD).strength(2.0f).sounds(BlockSoundGroup.WOOD));
    public static final StairsBlock COMMON_BLITZELWOOD_STAIRS = new StairsBlock(COMMON_BLITZELWOOD_PLANKS.getDefaultState(), FabricBlockSettings.of(Material.WOOD).strength(2.0f).sounds(BlockSoundGroup.WOOD));
    public static final TrapdoorBlock COMMON_BLITZELWOOD_TRAPDOOR = new TrapdoorBlock(FabricBlockSettings.of(Material.WOOD).strength(2.0f).sounds(BlockSoundGroup.WOOD));
    public static final DoorBlock COMMON_BLITZELWOOD_DOOR = new DoorBlock(FabricBlockSettings.of(Material.WOOD).strength(3.0f).sounds(BlockSoundGroup.WOOD));
    public static final FenceBlock COMMON_BLITZELWOOD_FENCE = new FenceBlock(FabricBlockSettings.of(Material.WOOD).strength(2.0f).sounds(BlockSoundGroup.WOOD));
    public static final FenceGateBlock COMMON_BLITZELWOOD_FENCE_GATE = new FenceGateBlock(FabricBlockSettings.of(Material.WOOD).strength(2.0f).sounds(BlockSoundGroup.WOOD));
    public static final WoodenButtonBlock COMMON_BLITZELWOOD_BUTTON = new WoodenButtonBlock(FabricBlockSettings.of(Material.WOOD).strength(0.5f).sounds(BlockSoundGroup.WOOD));
    public static final PressurePlateBlock COMMON_BLITZELWOOD_PRESSURE_PLATE = new PressurePlateBlock(PressurePlateBlock.ActivationRule.PLAYERS, FabricBlockSettings.of(Material.WOOD).strength(0.5f).sounds(BlockSoundGroup.WOOD));
    public static final SaplingBlock COMMON_BLITZELWOOD_SAPLING = new SaplingBlock(new BlitzelwoodSaplingGenerator(), FabricBlockSettings.of(Material.PLANT).noCollision().ticksRandomly().strength(0.0f).sounds(BlockSoundGroup.GRASS));
    public static final Block BLITZEL_MOSS = new Block(FabricBlockSettings.of(Material.MOSS).strength(0.1f).sounds(BlockSoundGroup.MOSS_BLOCK));
    public static final CarpetBlock BLITZEL_MOSS_CARPET = new CarpetBlock(FabricBlockSettings.of(Material.MOSS).strength(0.1f).sounds(BlockSoundGroup.MOSS_CARPET));

    @Override
    public void onInitialize() {
        // Register blocks
        autoRegisterBlockWithItem("common_blitzelwood_log", COMMON_BLITZELWOOD_LOG);
        autoRegisterBlockWithItem("stripped_common_blitzelwood_log", STRIPPED_COMMON_BLITZELWOOD_LOG);
        autoRegisterBlockWithItem("common_blitzelwood_wood", COMMON_BLITZELWOOD_WOOD);
        autoRegisterBlockWithItem("stripped_common_blitzelwood_wood", STRIPPED_COMMON_BLITZELWOOD_WOOD);
        autoRegisterBlockWithItem("common_blitzelwood_planks", COMMON_BLITZELWOOD_PLANKS);
        autoRegisterBlockWithItem("common_blitzelwood_leaves", COMMON_BLITZELWOOD_LEAVES);
        autoRegisterBlockWithItem("common_blitzelwood_slab", COMMON_BLITZELWOOD_SLAB);
        autoRegisterBlockWithItem("common_blitzelwood_stairs", COMMON_BLITZELWOOD_STAIRS);
        autoRegisterBlockWithItem("common_blitzelwood_trapdoor", COMMON_BLITZELWOOD_TRAPDOOR);
        autoRegisterBlockWithItem("common_blitzelwood_door", COMMON_BLITZELWOOD_DOOR);
        autoRegisterBlockWithItem("common_blitzelwood_fence", COMMON_BLITZELWOOD_FENCE);
        autoRegisterBlockWithItem("common_blitzelwood_fence_gate", COMMON_BLITZELWOOD_FENCE_GATE);
        autoRegisterBlockWithItem("common_blitzelwood_button", COMMON_BLITZELWOOD_BUTTON);
        autoRegisterBlockWithItem("common_blitzelwood_pressure_plate", COMMON_BLITZELWOOD_PRESSURE_PLATE);
        autoRegisterBlockWithItem("common_blitzelwood_sapling", COMMON_BLITZELWOOD_SAPLING);
        autoRegisterBlockWithItem("blitzel_moss", BLITZEL_MOSS);
        autoRegisterBlockWithItem("blitzel_moss_carpet", BLITZEL_MOSS_CARPET);

        // Register strippable log
        StrippableBlockRegistry.register(COMMON_BLITZELWOOD_LOG, STRIPPED_COMMON_BLITZELWOOD_LOG);
        StrippableBlockRegistry.register(COMMON_BLITZELWOOD_WOOD, STRIPPED_COMMON_BLITZELWOOD_WOOD);

        // Register biome modifications
        Registry.register(Registry.BIOME, new Identifier(MOD_ID, "common_blitzelwood_forest"), createBlitzelwoodForestBiome());
        BiomeModifications.addFeature(ctx -> ctx.getBiomeKey().getValue().equals(new Identifier(MOD_ID, "common_blitzelwood_forest")),
                GenerationStep.Feature.VEGETAL_DECORATION,
                RegistryKey.of(Registry.CONFIGURED_FEATURE_WORLDGEN, new Identifier(MOD_ID, "common_blitzelwood_tree")));
        BiomeModifications.addFeature(ctx -> ctx.getBiomeKey().getValue().equals(new Identifier(MOD_ID, "common_blitzelwood_forest")),
                GenerationStep.Feature.UNDERGROUND_DECORATION,
                RegistryKey.of(Registry.CONFIGURED_FEATURE_WORLDGEN, new Identifier(MOD_ID, "blitzel_moss_underground")));
        BiomeModifications.addFeature(ctx -> ctx.getBiomeKey().getValue().equals(new Identifier(MOD_ID, "common_blitzelwood_forest")),
                GenerationStep.Feature.VEGETAL_DECORATION,
                RegistryKey.of(Registry.PLACED_FEATURE_WORLDGEN, new Identifier(MOD_ID, "blitzel_moss_carpet_patches")));
    }

    private void autoRegisterBlockWithItem(String name, Block block) {
        // Register the block
        Registry.register(Registry.BLOCK, new Identifier(MOD_ID, name), block);
        // Register the block item
        Registry.register(Registry.ITEM, new Identifier(MOD_ID, name), new BlockItem(block, new Item.Settings().group(ItemGroup.BUILDING_BLOCKS)));
        // Automatically register block color provider for leaves
    }

    private Biome createBlitzelwoodForestBiome() {
        GenerationSettings.Builder generationSettings = new GenerationSettings.Builder();
        generationSettings.feature(GenerationStep.Feature.VEGETAL_DECORATION, RegistryKey.of(Registry.CONFIGURED_FEATURE_WORLDGEN, new Identifier(MOD_ID, "common_blitzelwood_tree")));
        generationSettings.feature(GenerationStep.Feature.VEGETAL_DECORATION, RegistryKey.of(Registry.PLACED_FEATURE_WORLDGEN, BiomeKeys.FLOWER_PLAINS.getValue()));
        generationSettings.feature(GenerationStep.Feature.VEGETAL_DECORATION, VegetationPlacedFeatures.FLOWER_WHITE_TULIP);
        generationSettings.feature(GenerationStep.Feature.VEGETAL_DECORATION, VegetationPlacedFeatures.FLOWER_LILY_OF_THE_VALLEY);
        generationSettings.feature(GenerationStep.Feature.UNDERGROUND_DECORATION, RegistryKey.of(Registry.CONFIGURED_FEATURE_WORLDGEN, new Identifier(MOD_ID, "blitzel_moss_underground")));
        generationSettings.feature(GenerationStep.Feature.VEGETAL_DECORATION, RegistryKey.of(Registry.PLACED_FEATURE_WORLDGEN, new Identifier(MOD_ID, "blitzel_moss_carpet_patches")));

        SpawnSettings.Builder spawnSettings = new SpawnSettings.Builder();

        return (new Biome.Builder())
                .precipitation(Biome.Precipitation.RAIN)
                .temperature(0.7F)
                .downfall(0.8F)
                .effects((new BiomeEffects.Builder())
                        .fogColor(12638463)
                        .skyColor(Biome.FogColor.calculateSkyColor(0.7F))
                        .waterColor(4159204)
                        .waterFogColor(329011)
                        .build())
                .spawnSettings(spawnSettings.build())
                .generationSettings(generationSettings.build())
                .build();
    }
}

class BlitzelwoodSaplingGenerator extends SaplingGenerator {
    @Override
    protected ConfiguredFeature<?, ?> createTreeFeature(Random random, boolean bl) {
        if (random.nextInt(2) == 0) {
            // Generate big blitzelwood tree
            return Feature.TREE.configure((new TreeFeatureConfig.Builder(
                    new SimpleBlockStateProvider(BlitzelwoodMod.COMMON_BLITZELWOOD_LOG.getDefaultState()),
                    new SimpleBlockStateProvider(BlitzelwoodMod.COMMON_BLITZELWOOD_LEAVES.getDefaultState()),
                    new TrunkPlacerType(7, 3, 1))).ignoreVines().build());
        } else {
            // Generate small blitzelwood tree
            return Feature.TREE.configure((new TreeFeatureConfig.Builder(
                    new SimpleBlockStateProvider(BlitzelwoodMod.COMMON_BLITZELWOOD_LOG.getDefaultState()),
                    new SimpleBlockStateProvider(BlitzelwoodMod.COMMON_BLITZELWOOD_LEAVES.getDefaultState()),
                    new TrunkPlacerType(4, 2, 0))).ignoreVines().build());
        }
    }
}

// Data Generation Classes
class BlitzelwoodModDataGenerator {
    public static void registerDataProviders(FabricDataGenerator dataGenerator) {
        dataGenerator.addProvider(FabricBlockStateProvider::new);
        dataGenerator.addProvider(FabricItemModelProvider::new);
        dataGenerator.addProvider(BlitzelwoodBlockLootTableProvider::new);
        dataGenerator.addProvider(BlitzelwoodTagProvider::new);
    }

    static class BlitzelwoodBlockLootTableProvider extends FabricBlockLootTableProvider {
        public BlitzelwoodBlockLootTableProvider(FabricDataGenerator dataGenerator) {
            super(dataGenerator);
        }

        @Override
        protected void generateBlockLootTables() {
            addDrop(BlitzelwoodMod.COMMON_BLITZELWOOD_LOG);
            addDrop(BlitzelwoodMod.STRIPPED_COMMON_BLITZELWOOD_LOG);
            addDrop(BlitzelwoodMod.COMMON_BLITZELWOOD_WOOD);
            addDrop(BlitzelwoodMod.STRIPPED_COMMON_BLITZELWOOD_WOOD);
            addDrop(BlitzelwoodMod.COMMON_BLITZELWOOD_PLANKS);
            addDrop(BlitzelwoodMod.COMMON_BLITZELWOOD_LEAVES, leavesDrops(BlitzelwoodMod.COMMON_BLITZELWOOD_LEAVES, BlitzelwoodMod.COMMON_BLITZELWOOD_SAPLING, 0.05f));
            addDrop(BlitzelwoodMod.COMMON_BLITZELWOOD_SLAB, slabDrops(BlitzelwoodMod.COMMON_BLITZELWOOD_SLAB));
            addDrop(BlitzelwoodMod.COMMON_BLITZELWOOD_STAIRS);
            addDrop(BlitzelwoodMod.COMMON_BLITZELWOOD_TRAPDOOR);
            addDrop(BlitzelwoodMod.COMMON_BLITZELWOOD_DOOR);
            addDrop(BlitzelwoodMod.COMMON_BLITZELWOOD_FENCE);
            addDrop(BlitzelwoodMod.COMMON_BLITZELWOOD_FENCE_GATE);
            addDrop(BlitzelwoodMod.COMMON_BLITZELWOOD_BUTTON);
            addDrop(BlitzelwoodMod.COMMON_BLITZELWOOD_PRESSURE_PLATE);
            addDrop(BlitzelwoodMod.COMMON_BLITZELWOOD_SAPLING);
            addDrop(BlitzelwoodMod.BLITZEL_MOSS);
            addDrop(BlitzelwoodMod.BLITZEL_MOSS_CARPET);
        }
    }

    static class BlitzelwoodTagProvider extends FabricTagProvider<Block> {
        public BlitzelwoodTagProvider(FabricDataGenerator dataGenerator) {
            super(dataGenerator, Registry.BLOCK);
        }

        @Override
        protected void generateTags() {
            getOrCreateTagBuilder(BlockTags.PLANKS).add(BlitzelwoodMod.COMMON_BLITZELWOOD_PLANKS);
            getOrCreateTagBuilder(BlockTags.LOGS).add(BlitzelwoodMod.COMMON_BLITZELWOOD_LOG, BlitzelwoodMod.STRIPPED_COMMON_BLITZELWOOD_LOG, BlitzelwoodMod.COMMON_BLITZELWOOD_WOOD, BlitzelwoodMod.STRIPPED_COMMON_BLITZELWOOD_WOOD);
            getOrCreateTagBuilder(BlockTags.LEAVES).add(BlitzelwoodMod.COMMON_BLITZELWOOD_LEAVES);
            getOrCreateTagBuilder(BlockTags.WOODEN_SLABS).add(BlitzelwoodMod.COMMON_BLITZELWOOD_SLAB);
            getOrCreateTagBuilder(BlockTags.WOODEN_STAIRS).add(BlitzelwoodMod.COMMON_BLITZELWOOD_STAIRS);
            getOrCreateTagBuilder(BlockTags.WOODEN_FENCES).add(BlitzelwoodMod.COMMON_BLITZELWOOD_FENCE);
            getOrCreateTagBuilder(BlockTags.DOORS).add(BlitzelwoodMod.COMMON_BLITZELWOOD_DOOR);
            getOrCreateTagBuilder(BlockTags.WOODEN_BUTTONS).add(BlitzelwoodMod.COMMON_BLITZELWOOD_BUTTON);
            getOrCreateTagBuilder(BlockTags.WOODEN_PRESSURE_PLATES).add(BlitzelwoodMod.COMMON_BLITZELWOOD_PRESSURE_PLATE);
            getOrCreateTagBuilder(BlockTags.CARPETS).add(BlitzelwoodMod.BLITZEL_MOSS_CARPET);
            getOrCreateTagBuilder(BlockTags.MOSS_REPLACEABLE).add(BlitzelwoodMod.BLITZEL_MOSS);

            // Register with "c" tags
            Tag<Block> cLogsTag = TagFactory.BLOCK.create(new Identifier("c", "common_blitzelwood_logs"));
            getOrCreateTagBuilder(cLogsTag).add(BlitzelwoodMod.COMMON_BLITZELWOOD_LOG, BlitzelwoodMod.STRIPPED_COMMON_BLITZELWOOD_LOG, BlitzelwoodMod.COMMON_BLITZELWOOD_WOOD, BlitzelwoodMod.STRIPPED_COMMON_BLITZELWOOD_WOOD);
        }
    }
}
