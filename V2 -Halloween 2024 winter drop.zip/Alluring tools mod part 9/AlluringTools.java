package com.example.alluringtools;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.client.itemgroup.FabricItemGroupBuilder;
import net.fabricmc.fabric.api.tag.TagFactory;
import net.minecraft.item.*;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.world.World;
import net.minecraft.util.math.BlockPos;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.recipe.Ingredient;
import net.minecraft.recipe.RecipeType;
import net.minecraft.recipe.ShapedRecipe;
import net.minecraft.recipe.book.RecipeCategory;
import net.minecraft.tag.TagKey;
import net.minecraft.util.collection.DefaultedList;

import java.util.ArrayList;
import java.util.List;

public class AlluringTools implements ModInitializer {
    public static final String MOD_ID = "alluringtools";
    public static final Item ALLURING_ORB = new AlluringOrbItem(new FabricItemSettings().group(ItemGroup.MISC));

    // Define Tags
    public static final TagKey<Item> ALLURING_TOOLS_TAG_C = TagKey.of(Registry.ITEM_KEY, new Identifier(MOD_ID, "c:alluring_tools"));
    public static final TagKey<Item> ALLURING_TOOLS_TAG_SMALL_C = TagKey.of(Registry.ITEM_KEY, new Identifier(MOD_ID, "alluring_tools"));
    public static final TagKey<Item> ALLURING_ORB_TAG_C = TagKey.of(Registry.ITEM_KEY, new Identifier(MOD_ID, "c:alluring_orb"));
    public static final TagKey<Item> ALLURING_ORB_TAG_SMALL_C = TagKey.of(Registry.ITEM_KEY, new Identifier(MOD_ID, "alluring_orb"));

    @Override
    public void onInitialize() {
        Registry.register(Registry.ITEM, new Identifier(MOD_ID, "alluring_orb"), ALLURING_ORB);
        Registry.register(Registry.ITEM, new Identifier(MOD_ID, "alluring_sword"), ALLURING_SWORD);
        Registry.register(Registry.ITEM, new Identifier(MOD_ID, "alluring_hoe"), ALLURING_HOE);
        Registry.register(Registry.ITEM, new Identifier(MOD_ID, "alluring_pickaxe"), ALLURING_PICKAXE);
        Registry.register(Registry.ITEM, new Identifier(MOD_ID, "alluring_shovel"), ALLURING_SHOVEL);
        Registry.register(Registry.ITEM, new Identifier(MOD_ID, "alluring_axe"), ALLURING_AXE);

        // Registering crafting recipes
        addRecipes();

        // Generate item models
        generateItemModels();

        // Add Items to Tags
        addItemsToTags();
    }

    // AlluringOrbItem Class
    public static class AlluringOrbItem extends Item {
        public AlluringOrbItem(Settings settings) {
            super(settings);
        }

        @Override
        public boolean postHit(ItemStack stack, LivingEntity target, LivingEntity attacker) {
            if (!attacker.world.isClient) {
                int xpToStore = target.getXpToDrop();
                storeXpInAlluringOrb(stack, xpToStore);
            }
            return super.postHit(stack, target, attacker);
        }

        private void storeXpInAlluringOrb(ItemStack stack, int xp) {
            NbtCompound nbt = stack.getOrCreateNbt();
            int currentXp = nbt.getInt("xp");
            nbt.putInt("xp", currentXp + xp);
        }

        @Override
    public String getTranslationKey(ItemStack stack) {
        int xp = getAvailableXp(stack);
        return xp > 0 ? "item.alluringtools.alluring_orb_full" : "item.alluringtools.alluring_orb_empty";
    }

    private int getAvailableXp(ItemStack stack) {
        NbtCompound nbt = stack.getOrCreateNbt();
        return nbt.getInt("xp");
    }
    }

    // Interface IAlluringOrb
    public interface IAlluringOrb {
        default void useXpForDurability(ItemStack toolStack, ItemStack alluringOrbStack) {
            int availableXp = AlluringOrbItem.getAvailableXp(alluringOrbStack);
            if (availableXp > 0 && toolStack.isDamaged()) {
                int repairAmount = Math.min(availableXp, toolStack.getDamage());
                toolStack.setDamage(toolStack.getDamage() - repairAmount);

                // Update the alluring orb NBT
                NbtCompound nbt = alluringOrbStack.getOrCreateNbt();
                nbt.putInt("xp", availableXp - repairAmount);
            }
        }
    }

    // Alluring Sword that Implements IAlluringOrb and Stores XP
    public static class AlluringSword extends Item implements IAlluringOrb {
        public AlluringSword(Settings settings) {
            super(settings);
        }

        @Override
        public boolean postHit(ItemStack stack, LivingEntity target, LivingEntity attacker) {
            if (!attacker.world.isClient) {
                int xpToStore = target.getXpToDrop() * 2; // Double XP
                Hand[] hands = Hand.values();
                for (Hand hand : hands) {
                    ItemStack heldItem = attacker.getStackInHand(hand);
                    if (heldItem.getItem() instanceof AlluringOrbItem) {
                        NbtCompound nbt = heldItem.getOrCreateNbt();
                        int currentXp = nbt.getInt("xp");
                        nbt.putInt("xp", currentXp + xpToStore);
                    }
                }
            }
            return super.postHit(stack, target, attacker);
        }
    }

    // Add crafting recipes for alluring orb and tools
    private void addRecipes() {
        // Alluring Orb Recipe
        DefaultedList<Ingredient> alluringOrbIngredients = DefaultedList.ofSize(9, Ingredient.EMPTY);
        alluringOrbIngredients.set(0, Ingredient.ofItems(Items.GLOWSTONE_DUST));
        alluringOrbIngredients.set(1, Ingredient.ofItems(Items.GLOWSTONE_DUST));
        alluringOrbIngredients.set(2, Ingredient.ofItems(Items.GLOWSTONE_DUST));
        alluringOrbIngredients.set(3, Ingredient.ofItems(Items.NETHERITE_INGOT));
        alluringOrbIngredients.set(4, Ingredient.ofItems(Items.DIAMOND));
        alluringOrbIngredients.set(5, Ingredient.ofItems(Items.NETHERITE_INGOT));
        alluringOrbIngredients.set(6, Ingredient.ofItems(Items.GLOWSTONE_DUST));
        alluringOrbIngredients.set(7, Ingredient.ofItems(Items.GLOWSTONE_DUST));
        alluringOrbIngredients.set(8, Ingredient.ofItems(Items.GLOWSTONE_DUST));
        Registry.register(Registry.RECIPE_SERIALIZER, new Identifier(MOD_ID, "alluring_orb"), new ShapedRecipe(new Identifier(MOD_ID, "alluring_orb"), "", new RecipeCategory(ItemGroup.MISC), 3, 3, alluringOrbIngredients, new ItemStack(ALLURING_ORB)).setSerializer(RecipeType.CRAFTING));

        // Alluring Tool Recipes
        addToolRecipe("alluring_sword", Items.DIAMOND_SWORD, ALLURING_SWORD);
        addToolRecipe("alluring_pickaxe", Items.DIAMOND_PICKAXE, ALLURING_PICKAXE);
        addToolRecipe("alluring_axe", Items.DIAMOND_AXE, ALLURING_AXE);
        addToolRecipe("alluring_shovel", Items.DIAMOND_SHOVEL, ALLURING_SHOVEL);
        addToolRecipe("alluring_hoe", Items.DIAMOND_HOE, ALLURING_HOE);
    }

    private void addToolRecipe(String name, Item baseTool, Item resultTool) {
        DefaultedList<Ingredient> ingredients = DefaultedList.ofSize(3, Ingredient.EMPTY);
        ingredients.set(0, Ingredient.ofItems(baseTool));
        ingredients.set(1, Ingredient.ofItems(ALLURING_ORB));
        ingredients.set(2, Ingredient.ofItems(Items.DIAMOND));
        Registry.register(Registry.RECIPE_SERIALIZER, new Identifier(MOD_ID, name), new ShapedRecipe(new Identifier(MOD_ID, name), "", new RecipeCategory(ItemGroup.TOOLS), 1, 3, ingredients, new ItemStack(resultTool)).setSerializer(RecipeType.CRAFTING));
    }

    // Alluring Hoe that Implements IAlluringOrb
    public static class AlluringHoe extends HoeItem implements IAlluringOrb {
        public AlluringHoe(ToolMaterial material, int attackDamage, float attackSpeed, Settings settings) {
            super(material, attackDamage, attackSpeed, settings);
        }
    }

    // Alluring Pickaxe that Implements IAlluringOrb
    public static class AlluringPickaxe extends PickaxeItem implements IAlluringOrb {
        public AlluringPickaxe(ToolMaterial material, int attackDamage, float attackSpeed, Settings settings) {
            super(material, attackDamage, attackSpeed, settings);
        }
    }

    // Alluring Shovel that Implements IAlluringOrb
    public static class AlluringShovel extends ShovelItem implements IAlluringOrb {
        public AlluringShovel(ToolMaterial material, float attackDamage, float attackSpeed, Settings settings) {
            super(material, attackDamage, attackSpeed, settings);
        }
    }

    // Alluring Axe that Implements IAlluringOrb
    public static class AlluringAxe extends AxeItem implements IAlluringOrb {
        public AlluringAxe(ToolMaterial material, float attackDamage, float attackSpeed, Settings settings) {
            super(material, attackDamage, attackSpeed, settings);
        }
    }

    // Register the Alluring Sword
    public static final Item ALLURING_SWORD = new AlluringSword(new FabricItemSettings().group(ItemGroup.COMBAT).maxDamage(800));
    // Register the Alluring Hoe
    public static final Item ALLURING_HOE = new AlluringHoe(ToolMaterials.DIAMOND, -1, -2.0F, new FabricItemSettings().group(ItemGroup.TOOLS).maxDamage(800));
    // Register the Alluring Pickaxe
    public static final Item ALLURING_PICKAXE = new AlluringPickaxe(ToolMaterials.DIAMOND, 1, -2.8F, new FabricItemSettings().group(ItemGroup.TOOLS).maxDamage(800));
    // Register the Alluring Shovel
    public static final Item ALLURING_SHOVEL = new AlluringShovel(ToolMaterials.DIAMOND, 1.5F, -3.0F, new FabricItemSettings().group(ItemGroup.TOOLS).maxDamage(800));
    // Register the Alluring Axe
    public static final Item ALLURING_AXE = new AlluringAxe(ToolMaterials.DIAMOND, 6.0F, -3.1F, new FabricItemSettings().group(ItemGroup.TOOLS).maxDamage(800));

    // Generate Item Models for all Tools and Alluring Orb
    private void generateItemModels() {
        // Assuming this function is part of your development environment
        // Alluring Orb Item Models
        generateItemModel("alluring_orb_empty", "textures/item/alluring_orb_empty.png");
        generateItemModel("alluring_orb_full", "textures/item/alluring_orb_full.png");

        // Alluring Tools Item Models
        generateItemModel("alluring_sword", "textures/item/alluring_sword.png");
        generateItemModel("alluring_hoe", "textures/item/alluring_hoe.png");
        generateItemModel("alluring_pickaxe", "textures/item/alluring_pickaxe.png");
        generateItemModel("alluring_shovel", "textures/item/alluring_shovel.png");
        generateItemModel("alluring_axe", "textures/item/alluring_axe.png");
    }

    private void generateItemModel(String itemName, String texturePath) {
        // Placeholder for item model generation logic
        System.out.println("Generating item model for: " + itemName + " with texture: " + texturePath);
    }

    // Add Items to Tags
    private void addItemsToTags() {
        Registry.ITEM.getOrCreateEntry(ALLURING_TOOLS_TAG_C).add(ALLURING_SWORD, ALLURING_HOE, ALLURING_PICKAXE, ALLURING_SHOVEL, ALLURING_AXE);
        Registry.ITEM.getOrCreateEntry(ALLURING_TOOLS_TAG_SMALL_C).add(ALLURING_SWORD, ALLURING_HOE, ALLURING_PICKAXE, ALLURING_SHOVEL, ALLURING_AXE);
        Registry.ITEM.getOrCreateEntry(ALLURING_ORB_TAG_C).add(ALLURING_ORB);
        Registry.ITEM.getOrCreateEntry(ALLURING_ORB_TAG_SMALL_C).add(ALLURING_ORB);
    }
}
