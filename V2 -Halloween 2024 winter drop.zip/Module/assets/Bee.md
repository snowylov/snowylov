Merge this

{
  "name": "BeeCore",
  "version": "1.8.0",
  "description": "Advanced bee breeding with DNA manipulation, cloning, crossbreeding, biome-specific bees, and comb production. This version includes enhanced breeding mechanics, new crossbreeds, added effects, natural bee spawning, and honey bottle crafting recipes. Bees now naturally build hives, and hives can be harvested using a Scoop tool to keep bees peaceful. Updated hive textures and models for snowy, desert, swamp, forest, meadows, and jungle hives, and added new desert and swamp bee behaviors. Added 50 new crossbreeds, including advanced crossbreeds like the Silk Bee.",
  "items": [
    {
      "name": "Beealizer",
      "type": "tool",
      "function": "view_bee_stats",
      "texture": "textures/item/beealizer.png"
    },
    {
      "name": "Scoop",
      "type": "tool",
      "function": "harvest_hive",
      "texture": "textures/item/scoop.png",
      "recipe": {
        "pattern": [
          " W ",
          "WSW",
          " W "
        ],
        "key": {
          "W": "minecraft:wool",
          "S": "minecraft:stick"
        }
      },
      ,
      "random_bee_stats_on_harvest": true
    },
    {
      "name": "comb_storage_chest",
      "type": "chest",
      "texture": "textures/block/chest.png",
      "function": "store_honeycombs"
    },
    {
      "name": "honey_bottle",
      "type": "food",
      "texture": "textures/item/honey_bottle.png",
      "function": "restore_hunger",
      "recipe": {
        "comb_recipes": [
          {
            "comb": "forest_comb",
            "output": "honey_bottle"
          },
          {
            "comb": "plains_comb",
            "output": "honey_bottle"
          },
          {
            "comb": "frost_comb",
            "output": "honey_bottle"
          },
          {
            "comb": "shadow_comb",
            "output": "honey_bottle"
          },
          {
            "comb": "sunburst_comb",
            "output": "honey_bottle"
          },
          {
            "comb": "nightshade_comb",
            "output": "honey_bottle"
          },
          {
            "comb": "rock_comb",
            "output": "honey_bottle"
          },
          {
            "comb": "sandy_comb",
            "output": "honey_bottle"
          },
          {
            "comb": "slime_comb",
            "output": "minecraft:slime_ball"
          },
          {
            "comb": "jungle_comb",
            "output": "minecraft:cocoa_beans"
          }
        ]
      }
    }
  ],
  "blocks": [
    {
      "name": "bee_house",
      "type": "beekeeping_structure",
      "inventory_slots": 6,
      "requires_flowers": true,
      "texture": "textures/block/bee_house.png",
      "recipe": {
        "pattern": [
          "SSS",
          "PPP",
          "PPP"
        ],
        "key": {
          "S": "minecraft:oak_slab",
          "P": "minecraft:oak_planks"
        }
      }
    },
    {
      "name": "apiary",
      "type": "advanced_beekeeping_structure",
      "inventory_slots": 12,
      "doubles_honey_production": true,
      "requires_flowers": true,
      "dna_storage": {
        "max_capacity": 1000,
        "liquid_dna": true,
        "filter_options": ["keep_good_stats", "discard_bad_stats"]
      },
      "texture": "textures/block/apiary.png",
      "recipe": {
        "pattern": [
          "SSS",
          "PCP",
          "PPP"
        ],
        "key": {
          "S": "minecraft:oak_slab",
          "P": "minecraft:oak_planks",
          "C": "modid:jungle_honeycomb"
        }
      },
      "functions": {
        "clone_bee": true,
        "set_standards": true
      }
    },
    {
      "name": "snowy_hive",
      
      "peaceful_with_campfire": true,
      "model": {
        "parent": "block/cube",
        "textures": {
          "particle": "textures/block/snow.side.png",
          "down": "textures/block/snow.bottom.png",
          "up": "textures/block/snow.top.png",
          "north": "textures/block/snow.side.png",
          "east": "textures/block/snow.side.png",
          "south": "textures/block/snow.side.png",
          "west": "textures/block/snow.side.png"
        }
      },
      "recipe": {
        "pattern": [
          "SSS",
          "SPS",
          "SSS"
        ],
        "key": {
          "S": "minecraft:snow_block",
          "P": "minecraft:oak_planks"
        }
      }
    },
    {
      "name": "desert_hive",
      
      "peaceful_with_campfire": true,
      "model": {
        "parent": "block/cube",
        "textures": {
          "particle": "textures/block/desert.side.png",
          "down": "textures/block/desert.bottom.png",
          "up": "textures/block/desert.top.png",
          "north": "textures/block/desert.side.png",
          "east": "textures/block/desert.side.png",
          "south": "textures/block/desert.side.png",
          "west": "textures/block/desert.side.png"
        }
      },
      "recipe": {
        "pattern": [
          "SSS",
          "SPS",
          "SSS"
        ],
        "key": {
          "S": "minecraft:sandstone",
          "P": "minecraft:oak_planks"
        }
      }
    },
    {
      "name": "swamp_hive",
      
      "peaceful_with_campfire": true,
      "model": {
        "parent": "block/cube",
        "textures": {
          "particle": "textures/block/swamp.side.png",
          "down": "textures/block/swamp.bottom.png",
          "up": "textures/block/swamp.top.png",
          "north": "textures/block/swamp.side.png",
          "east": "textures/block/swamp.side.png",
          "south": "textures/block/swamp.side.png",
          "west": "textures/block/swamp.side.png"
        }
      },
      "recipe": {
        "pattern": [
          "SSS",
          "SPS",
          "SSS"
        ],
        "key": {
          "S": "minecraft:vines",
          "P": "minecraft:oak_planks"
        }
      }
    },
    {
      "name": "forest_hive",
      
      "peaceful_with_campfire": true,
      "model": {
        "parent": "block/cube",
        "textures": {
          "particle": "textures/block/forest.side.png",
          "down": "textures/block/forest.bottom.png",
          "up": "textures/block/forest.top.png",
          "north": "textures/block/forest.side.png",
          "east": "textures/block/forest.side.png",
          "south": "textures/block/forest.side.png",
          "west": "textures/block/forest.side.png"
        }
      },
      "recipe": {
        "pattern": [
          "SSS",
          "SPS",
          "SSS"
        ],
        "key": {
          "S": "minecraft:oak_leaves",
          "P": "minecraft:oak_planks"
        }
      }
    },
    {
      "name": "meadows_hive",
      
      "peaceful_with_campfire": true,
      "model": {
        "parent": "block/cube",
        "textures": {
          "particle": "textures/block/meadows.side.png",
          "down": "textures/block/meadows.bottom.png",
          "up": "textures/block/meadows.top.png",
          "north": "textures/block/meadows.side.png",
          "east": "textures/block/meadows.side.png",
          "south": "textures/block/meadows.side.png",
          "west": "textures/block/meadows.side.png"
        }
      },
      "recipe": {
        "pattern": [
          "SSS",
          "SPS",
          "SSS"
        ],
        "key": {
          "S": "minecraft:grass_block",
          "P": "minecraft:oak_planks"
        }
      }
    },
    {
      "name": "jungle_hive",
      
      "peaceful_with_campfire": true,
      "model": {
        "parent": "block/cube",
        "textures": {
          "particle": "textures/block/jungle.side.png",
          "down": "textures/block/jungle.bottom.png",
          "up": "textures/block/jungle.top.png",
          "north": "textures/block/jungle.side.png",
          "east": "textures/block/jungle.side.png",
          "south": "textures/block/jungle.side.png",
          "west": "textures/block/jungle.side.png"
        }
      },
      "recipe": {
        "pattern": [
          "SSS",
          "SPS",
          "SSS"
        ],
        "key": {
          "S": "minecraft:jungle_leaves",
          "P": "minecraft:oak_planks"
        }
      }
    },
    {
      "name": "underground_hive",
      
      "peaceful_with_campfire": true,
      "texture": "textures/block/underground_hive.png",
      "recipe": {
        "pattern": [
          "SSS",
          "SPS",
          "SSS"
        ],
        "key": {
          "S": "minecraft:cobblestone",
          "P": "minecraft:oak_planks"
        }
      }
    }
  ],
  "bees": [
    {
      
        "random_stats": true,
        "honeycomb_production_rate": 0.5,
        "lifespan": "long",
        "night_work": false,
        "fertility": "high",
        "preferred_biome": "snowy"
      },
      "hive": "snowy_hive"
    },
    {
      
        "random_stats": true,
        "honeycomb_production_rate": 0.7,
        "lifespan": "medium",
        "night_work": true,
        "fertility": "high",
        "preferred_biome": "forest"
      },
      "comb": {
        "name": "forest_comb",
        "texture": "textures/item/forest_comb.png"
      },
      "hive": "meadows_hive"
    },
    {
      
        "random_stats": true,
        "honeycomb_production_rate": 0.6,
        "lifespan": "medium",
        "night_work": false,
        "fertility": "high",
        "preferred_biome": "plains"
      },
      "comb": {
        "name": "plains_comb",
        "texture": "textures/item/plains_comb.png"
      },
      "hive": "meadows_hive"
    },
    {
      
        "random_stats": true,
        "honeycomb_production_rate": 0.5,
        "lifespan": "long",
        "night_work": false,
        "fertility": "high",
        "preferred_biome": "swamp",
        "poisonous": true
      },
      "comb": {
        "name": "slime_comb",
        "texture": "textures/item/slime_comb.png"
      },
      "hive": "swamp_hive"
    },
    {
      
        "random_stats": true,
        "honeycomb_production_rate": 0.8,
        "lifespan": "short",
        "night_work": true,
        "fertility": "low",
        "preferred_biome": "jungle",
        "aggressive": true
      },
      "comb": {
        "name": "jungle_comb",
        "texture": "textures/item/jungle_comb.png"
      },
      "hive": "jungle_hive"
    },
    {
      
        "random_stats": true,
        "honeycomb_production_rate": 0.4,
        "lifespan": "long",
        "night_work": false,
        "fertility": "medium",
        "preferred_biome": "deepslate"
      },
      "comb": {
        "name": "rock_comb",
        "texture": "textures/item/rock_comb.png",
        "drops": {
          "stone": 97,
          "raw_ore": 2,
          "diamond_or_emerald": 1
        }
      },
      "hive": "underground_hive"
    },
    {
      
        "random_stats": true,
        "honeycomb_production_rate": 0.6,
        "lifespan": "medium",
        "night_work": false,
        "fertility": "medium",
        "preferred_biome": "desert",
        "aggressive": true
      },
      "comb": {
        "name": "sandy_comb",
        "texture": "textures/item/sandy_comb.png"
      },
      "hive": "desert_hive"
    }
  ],
  "crossbreeds": [
    {
      "name": "frostbee",
      "parents": ["snowy_bee", "jungle_bee"],
      "traits": {
        "honeycomb_production_rate": 1.0,
        "lifespan": "long",
        "night_work": true,
        "fertility": "high"
      },
      "comb": {
        "name": "frost_comb",
        "texture": "textures/item/frost_comb.png"
      }
    },
    {
      "name": "shadowbee",
      "parents": ["underground_bee", "swamp_bee"],
      "traits": {
        "honeycomb_production_rate": 1.2,
        "lifespan": "short",
        "night_work": true,
        "fertility": "medium"
      },
      "comb": {
        "name": "shadow_comb",
        "texture": "textures/item/shadow_comb.png"
      }
    },
    {
      "name": "sunburstbee",
      "parents": ["plains_bee", "desert_bee"],
      "traits": {
        "honeycomb_production_rate": 0.9,
        "lifespan": "medium",
        "night_work": false,
        "fertility": "medium"
      },
      "comb": {
        "name": "sunburst_comb",
        "texture": "textures/item/sunburst_comb.png"
      }
    },
    {
      "name": "nightshadebee",
      "parents": ["forest_bee", "swamp_bee"],
      "traits": {
        "honeycomb_production_rate": 1.1,
        "lifespan": "medium",
        "night_work": true,
        "fertility": "medium"
      },
      "comb": {
        "name": "nightshade_comb",
        "texture": "textures/item/nightshade_comb.png"
      }
    },
    {
      "name": "sandstormbee",
      "parents": ["desert_bee", "plains_bee"],
      "traits": {
        "honeycomb_production_rate": 1.0,
        "lifespan": "medium",
        "night_work": false,
        "fertility": "medium"
      },
      "comb": {
        "name": "sandstorm_comb",
        "texture": "textures/item/sandstorm_comb.png"
      }
    },
    {
      "name": "silk_bee",
      "parents": ["frostbee", "shadowbee"],
      "traits": {
        "honeycomb_production_rate": 0.8,
        "lifespan": "medium",
        "night_work": true,
        "fertility": "high"
      },
      "comb": {
        "name": "silk_comb",
        "texture": "textures/item/silk_comb.png",
        "output": "minecraft:string"
      }
    },
    {
      "name": "emeraldbee",
      "parents": ["shadowbee", "sunburstbee"],
      "traits": {
        "honeycomb_production_rate": 1.3,
        "lifespan": "medium",
        "night_work": false,
        "fertility": "medium"
      },
      "comb": {
        "name": "emerald_comb",
        "texture": "textures/item/emerald_comb.png",
        "drops": {
          "emerald": 5
        }
      }
    }
    // Additional 43 crossbreeds can be added here following similar structure.
  ],
  "breeding": {
    "inheritance": {
      "good_traits_probability": 0.7,
      "bad_traits_probability": 0.3,
      "infertility_chance": 0.2,
      "short_lifespan_chance": 0.1
    },
    "dna_management": {
      "filter_good_stats": true,
      "discard_bad_stats": true,
      "liquid_dna_storage": true,
      "clone_bee_function": true
    }
  },
  "tags": {
    "minecraft:flowers": ["dandelion", "poppy", "blue_orchid", "allium"]
  },
  ,
    {
      "name": "peacefulBeesWithCampfire",
      "trigger": "placeCampfireUnderHive",
      "effect": "make_bees_peaceful"
    },
    {
      "name": "spreadFlowers",
      "trigger": "onPollination",
      "effect": "spread_flower"
    },
    {
      "name": "infertilityMutation",
      "trigger": "onPoorBreeding",
      "effect": "infertility_increase"
    },
    {
      "name": "statEnhancement",
      "trigger": "onHighQualityBreeding",
      "effect": "stat_boost"
    }
  ],
  
    {
      "hive_type": "forest_hive",
      "biome": "forest",
      "spawn_count": 2,
      "spawn_location": "biome"
    },
    {
      "hive_type": "snowy_hive",
      "biome": "snowy",
      "spawn_count": 2,
      "spawn_location": "biome"
    },
    {
      "hive_type": "desert_hive",
      "biome": "desert",
      "spawn_count": 2,
      "spawn_location": "biome"
    },
    {
      "hive_type": "swamp_hive",
      "biome": "swamp",
      "spawn_count": 2,
      "spawn_location": "biome"
    },
    {
      "hive_type": "jungle_hive",
      "biome": "jungle",
      "spawn_count": 2,
      "spawn_location": "biome"
    },
    {
      "hive_type": "meadows_hive",
      "biome": "plains",
      "spawn_count": 2,
      "spawn_location": "biome"
    },
    {
      "bee": "forest_bee",
      "biome": "forest",
      "hive_type": "meadows_hive",
      "spawn_count": 4,
      "spawn_location": "hive"
    },
    {
      "bee": "underground_bee",
      "biome": "deepslate",
      "hive_type": "underground_hive",
      "spawn_count": 4,
      "spawn_location": "hive"
    },
    {
      "bee": "snowy_bee",
      "biome": "snowy",
      "hive_type": "snowy_hive",
      "spawn_count": 4,
      "spawn_location": "hive"
    },
    {
      "bee": "plains_bee",
      "biome": "plains",
      "hive_type": "meadows_hive",
      "spawn_count": 4,
      "spawn_location": "hive"
    },
    {
      "bee": "swamp_bee",
      "biome": "swamp",
      "hive_type": "swamp_hive",
      "spawn_count": 4,
      "spawn_location": "hive"
    },
    {
      "bee": "jungle_bee",
      "biome": "jungle",
      "hive_type": "jungle_hive",
      "spawn_count": 4,
      "spawn_location": "hive"
    },
    {
      "bee": "desert_bee",
      "biome": "desert",
      "hive_type": "desert_hive",
      "spawn_count": 4,
      "spawn_location": "hive"
    }
  ]
}

With this
{
  "name": "BeeFarming",
  "version": "1.9.1",
  "description": "Advanced bee breeding with DNA manipulation, cloning, crossbreeding, biome-specific bees, and comb production. This version includes enhanced breeding mechanics, new crossbreeds, added effects, natural bee spawning, and honey bottle crafting recipes. Bees now naturally build hives, and hives can be harvested using a Scoop tool to keep bees peaceful. Updated hive textures and models for snowy, desert, swamp, forest, meadows, and jungle hives, and added new desert and swamp bee behaviors. Added 50 new crossbreeds, including advanced crossbreeds like the Silk Bee. Introduced new Natural Power energy system, solar panels, power cables, and Natural Power machines like the Centrifuge and Furnace.",
  "items": [
    {
      "name": "Beealizer",
      "type": "tool",
      "function": "view_bee_stats",
      "texture": "textures/item/beealizer.png"
    },
    {
      "name": "Scoop",
      "type": "tool",
      "function": "harvest_hive",
      "drops_hive_block": true,
      "releases_bees_on_drop": true,
      "texture": "textures/item/scoop.png",
      "recipe": {
        "pattern": [
          " W ",
          "WSW",
          " W "
        ],
        "key": {
          "W": "minecraft:wool",
          "S": "minecraft:stick"
        }
      },
      "random_bee_stats_on_harvest": true
    },
    {
      "name": "comb_storage_chest",
      "type": "chest",
      "texture": "textures/block/chest.png",
      "function": "store_honeycombs",
      "inventory_slots": 54,
      "pages": 100
    },
    {
      "name": "honey_bottle",
      "type": "food",
      "texture": "textures/item/honey_bottle.png",
      "function": "restore_hunger",
      "recipe": {
        "comb_recipes": [
          {
            "comb": "forest_comb",
            "output": "honey_bottle"
          },
          {
            "comb": "plains_comb",
            "output": "honey_bottle"
          },
          {
            "comb": "frost_comb",
            "output": "honey_bottle"
          },
          {
            "comb": "shadow_comb",
            "output": "honey_bottle"
          },
          {
            "comb": "sunburst_comb",
            "output": "honey_bottle"
          },
          {
            "comb": "nightshade_comb",
            "output": "honey_bottle"
          },
          {
            "comb": "rock_comb",
            "output": "honey_bottle"
          },
          {
            "comb": "sandy_comb",
            "output": "honey_bottle",
            "drops": {
              "white_sand": 100
            }
          },
          {
            "comb": "slime_comb",
            "output": "minecraft:slime_ball"
          },
          {
            "comb": "jungle_comb",
            "output": "minecraft:cocoa_beans"
          },
          {
            "comb": "diamond_comb",
            "output": "minecraft:diamond"
          },
          {
            "comb": "stony_comb",
            "output": "minecraft:stone"
          },
          {
            "comb": "deepslate_comb",
            "output": "minecraft:deepslate"
          }
        ]
      }
    },
    {
      "name": "grafter",
      "type": "tool",
      "function": "increase_sapling_drop_rate",
      "durability": 7,
      "texture": "textures/item/grafter.png",
      "description": "Makes leaves drop saplings 100% of the time. Can be enchanted with Mending and Unbreaking."
    },
    {
      "name": "proven_grafter",
      "type": "tool",
      "function": "increase_sapling_drop_rate",
      "durability": 17,
      "texture": "textures/item/proven_grafter.png",
      "description": "Makes leaves drop saplings 100% of the time. Proven grafter has enhanced durability. Can be enchanted with Mending and Unbreaking."
    },
    {
      "name": "Natural Power Solar Panel",
      "type": "block",
      "function": "generate_power",
      "power_generation": 10,
      "energy_type": "Natural Power",
      "description": "Generates Natural Power. Only works during the day, produces half the energy if it's raining.",
      "texture": "textures/block/solar_panel.png",
      "item_texture": "textures/item/solar_panel.png"
    },
    {
      "name": "Natural Power Cable",
      "type": "block",
      "function": "transfer_power",
      "max_value": 20,
      "description": "Transfers Natural Power",
      "texture": "textures/block/natural_power_cable.png",
      "handheld_texture": "textures/item/natural_power_cable_handheld.png",
      "inventory_texture": "textures/item/natural_power_cable_inventory.png",
      "connectivity": "all_six_directions",
      "models": [
        "straight",
        "turn",
        "combined"
      ],
      "render_settings": {
        "glass_fiber": true,
        "tint": "#FFFF00B3"
      },
      "recipe": {
        "pattern": [
          " G ",
          "S S",
          " G "
        ],
        "key": {
          "G": "minecraft:glowstone_dust",
          "S": "minecraft:string"
        },
        "output": 16
      }
    },
    {
      "name": "Upgraded Natural Power Cable",
      "type": "block",
      "function": "transfer_power",
      "max_value": 40,
      "description": "Transfers Natural Power",
      "texture": "textures/block/upgraded_natural_power_cable.png"
    },
    {
      "name": "Natural Power Furnace",
      "type": "block",
      "function": "smelt",
      "power_consumption": 80,
      "energy_type": "Natural Power",
      "description": "Consumes 80 Natural Power per second while smelting. Only uses power when actively smelting.",
      "texture": "textures/block/natural_power_furnace.png"
    },
    {
      "name": "Centrifuge",
      "type": "block",
      "function": "process_comb",
      "processing_time": 8,
      "power_consumption": 40,
      "energy_type": "Natural Power",
      "description": "Turns comb into items. Requires 40 Natural Power per second.",
      "texture": "textures/block/centrifuge.png"
    }
  ],
  "bees": [
    {
      "name": "snowy_bee",
      "traits": {
        "random_stats": true,
        "honeycomb_production_rate": 0.5,
        "lifespan": "long",
        "night_work": false,
        "fertility": "high",
        "preferred_biome": "snowy"
      },
      "hive": "snowy_hive"
    },
    {
      "name": "forest_bee",
      "traits": {
        "random_stats": true,
        "honeycomb_production_rate": 0.7,
        "lifespan": "medium",
        "night_work": true,
        "fertility": "high",
        "preferred_biome": "forest"
      },
      "comb": {
        "name": "forest_comb",
        "texture": "textures/item/forest_comb.png"
      },
      "hive": "meadows_hive"
    },
    {
      "name": "plains_bee",
      "traits": {
        "random_stats": true,
        "honeycomb_production_rate": 0.6,
        "lifespan": "medium",
        "night_work": false,
        "fertility": "high",
        "preferred_biome": "plains"
      },
      "comb": {
        "name": "plains_comb",
        "texture": "textures/item/plains_comb.png"
      },
      "hive": "meadows_hive"
    },
    {
      "name": "swamp_bee",
      "traits": {
        "random_stats": true,
        "honeycomb_production_rate": 0.5,
        "lifespan": "long",
        "night_work": false,
        "fertility": "high",
        "preferred_biome": "swamp",
        "poisonous": true
      },
      "comb": {
        "name": "slime_comb",
        "texture": "textures/item/slime_comb.png"
      },
      "hive": "swamp_hive"
    },
    {
      "name": "jungle_bee",
      "traits": {
        "random_stats": true,
        "honeycomb_production_rate": 0.8,
        "lifespan": "short",
        "night_work": true,
        "fertility": "low",
        "preferred_biome": "jungle",
        "aggressive": true
      },
      "comb": {
        "name": "jungle_comb",
        "texture": "textures/item/jungle_comb.png"
      },
      "hive": "jungle_hive"
    },
    {
      "name": "underground_bee",
      "traits": {
        "random_stats": true,
        "honeycomb_production_rate": 0.4,
        "lifespan": "long",
        "night_work": false,
        "fertility": "medium",
        "preferred_biome": "deepslate"
      },
      "comb": {
        "name": "rock_comb",
        "texture": "textures/item/rock_comb.png",
        "drops": {
          "stone": 97,
          "raw_ore": 2,
          "diamond_or_emerald": 1
        }
      },
      "hive": "underground_hive"
    },
    {
      "name": "desert_bee",
      "traits": {
        "random_stats": true,
        "honeycomb_production_rate": 0.6,
        "lifespan": "medium",
        "night_work": false,
        "fertility": "medium",
        "preferred_biome": "desert",
        "aggressive": true
      },
      "comb": {
        "name": "sandy_comb",
        "texture": "textures/item/sandy_comb.png"
      },
      "hive": "desert_hive"
    },
    {
      "name": "meadows_bee",
      "parents": ["forest_bee", "plains_bee"],
      "crossbreed_chance": 75,
      "traits": {
        "honeycomb_production_rate": 0.75,
        "lifespan": "medium",
        "night_work": false,
        "fertility": "medium"
      },
      "hive": "meadows_hive"
    },
    {
      "name": "diamond_bee",
      "parents": ["emerald_bee", "rock_bee"],
      "crossbreed_chance": 2,
      "traits": {
        "honeycomb_production_rate": 0.3,
        "lifespan": "medium",
        "night_work": false,
        "fertility": "low"
      },
      "comb": {
        "name": "diamond_comb",
        "texture": "textures/item/diamond_comb.png"
      },
      "hive": "rock_hive"
    },
    {
      "name": "stone_bee",
      "parents": ["rock_bee", "rock_bee"],
      "crossbreed_chance": 14,
      "traits": {
        "honeycomb_production_rate": 0.5,
        "lifespan": "long",
        "night_work": false,
        "fertility": "medium"
      },
      "comb": {
        "name": "stony_comb",
        "texture": "textures/item/stony_comb.png",
        "output": "minecraft:stone"
      },
      "hive": "rock_hive"
    }
  ]
}
With this

"bees": [
    {
      "name": "snowy_bee",
      "traits": {
        "random_stats": true,
        "honeycomb_production_rate": 0.5,
        "lifespan": "long",
        "night_work": false,
        "fertility": "high",
        "preferred_biome": "snowy"
      },
      "hive": "snowy_hive"
    },
    {
      "name": "forest_bee",
      "traits": {
        "random_stats": true,
        "honeycomb_production_rate": 0.7,
        "lifespan": "medium",
        "night_work": true,
        "fertility": "high",
        "preferred_biome": "forest"
      },
      "comb": {
        "name": "forest_comb",
        "texture": "textures/item/forest_comb.png"
      },
      "hive": "forest_hive"
    },
    {
      "name": "plains_bee",
      "traits": {
        "random_stats": true,
        "honeycomb_production_rate": 0.6,
        "lifespan": "medium",
        "night_work": false,
        "fertility": "high",
        "preferred_biome": "plains"
      },
      "comb": {
        "name": "plains_comb",
        "texture": "textures/item/plains_comb.png"
      },
      "hive": "meadows_hive"
    },
    {
      "name": "swamp_bee",
      "traits": {
        "random_stats": true,
        "honeycomb_production_rate": 0.5,
        "lifespan": "long",
        "night_work": false,
        "fertility": "high",
        "preferred_biome": "swamp",
        "poisonous": true
      },
      "comb": {
        "name": "slime_comb",
        "texture": "textures/item/slime_comb.png"
      },
      "hive": "swamp_hive"
    },
    {
      "name": "jungle_bee",
      "traits": {
        "random_stats": true,
        "honeycomb_production_rate": 0.8,
        "lifespan": "short",
        "night_work": true,
        "fertility": "low",
        "preferred_biome": "jungle",
        "aggressive": true
      },
      "comb": {
        "name": "jungle_comb",
        "texture": "textures/item/jungle_comb.png"
      },
      "hive": "jungle_hive"
    },
    {
      "name": "underground_bee",
      "traits": {
        "random_stats": true,
        "honeycomb_production_rate": 0.4,
        "lifespan": "long",
        "night_work": false,
        "fertility": "medium",
        "preferred_biome": "deepslate"
      },
      "comb": {
        "name": "rock_comb",
        "texture": "textures/item/rock_comb.png",
        "drops": {
          "stone": 97,
          "raw_ore": 2,
          "diamond_or_emerald": 1
        }
      },
      "hive": "underground_hive"
    },
    {
      "name": "desert_bee",
      "traits": {
        "random_stats": true,
        "honeycomb_production_rate": 0.6,
        "lifespan": "medium",
        "night_work": false,
        "fertility": "medium",
        "preferred_biome": "desert",
        "aggressive": true
      },
      "comb": {
        "name": "sandy_comb",
        "texture": "textures/item/sandy_comb.png"
      },
      "hive": "desert_hive"
    },
    {
      "name": "meadows_bee",
      "parents": ["forest_bee", "plains_bee"],
      "crossbreed_chance": 75,
      "traits": {
        "honeycomb_production_rate": 0.75,
        "lifespan": "medium",
        "night_work": false,
        "fertility": "medium"
      },
      "hive": "meadows_hive"
    },
    {
      "name": "diamond_bee",
      "parents": ["emerald_bee", "rock_bee"],
      "crossbreed_chance": 2,
      "traits": {
        "honeycomb_production_rate": 0.3,
        "lifespan": "medium",
        "night_work": false,
        "fertility": "low"
      },
      "comb": {
        "name": "diamond_comb",
        "texture": "textures/item/diamond_comb.png"
      },
      "hive": "rock_hive"
    },
    {
      "name": "stone_bee",
      "parents": ["rock_bee", "rock_bee"],
      "crossbreed_chance": 14,
      "traits": {
        "honeycomb_production_rate": 0.5,
        "lifespan": "long",
        "night_work": false,
        "fertility": "medium"
      },
      "comb": {
        "name": "stony_comb",
        "texture": "textures/item/stony_comb.png",
        "output": "minecraft:stone"
      },
      "hive": "rock_hive"
    }
  ]
And this

"bees": [
    {
      "name": "snowy_bee",
      "traits": {
        "random_stats": true,
        "honeycomb_production_rate": 0.5,
        "lifespan": "long",
        "night_work": false,
        "fertility": "high",
        "preferred_biome": "snowy"
      },
      "hive": "snowy_hive"
    },
    {
      "name": "forest_bee",
      "traits": {
        "random_stats": true,
        "honeycomb_production_rate": 0.7,
        "lifespan": "medium",
        "night_work": true,
        "fertility": "high",
        "preferred_biome": "forest"
      },
      "comb": {
        "name": "forest_comb",
        "texture": "textures/item/forest_comb.png"
      },
      "hive": "forest_hive"
    },
    {
      "name": "plains_bee",
      "traits": {
        "random_stats": true,
        "honeycomb_production_rate": 0.6,
        "lifespan": "medium",
        "night_work": false,
        "fertility": "high",
        "preferred_biome": "plains"
      },
      "comb": {
        "name": "plains_comb",
        "texture": "textures/item/plains_comb.png"
      },
      "hive": "meadows_hive"
    },
    {
      "name": "swamp_bee",
      "traits": {
        "random_stats": true,
        "honeycomb_production_rate": 0.5,
        "lifespan": "long",
        "night_work": false,
        "fertility": "high",
        "preferred_biome": "swamp",
        "poisonous": true
      },
      "comb": {
        "name": "slime_comb",
        "texture": "textures/item/slime_comb.png"
      },
      "hive": "swamp_hive"
    },
    {
      "name": "jungle_bee",
      "traits": {
        "random_stats": true,
        "honeycomb_production_rate": 0.8,
        "lifespan": "short",
        "night_work": true,
        "fertility": "low",
        "preferred_biome": "jungle",
        "aggressive": true
      },
      "comb": {
        "name": "jungle_comb",
        "texture": "textures/item/jungle_comb.png"
      },
      "hive": "jungle_hive"
    },
    {
      "name": "underground_bee",
      "traits": {
        "random_stats": true,
        "honeycomb_production_rate": 0.4,
        "lifespan": "long",
        "night_work": false,
        "fertility": "medium",
        "preferred_biome": "deepslate"
      },
      "comb": {
        "name": "rock_comb",
        "texture": "textures/item/rock_comb.png",
        "drops": {
          "stone": 97,
          "raw_ore": 2,
          "diamond_or_emerald": 1
        }
      },
      "hive": "underground_hive"
    },
    {
      "name": "desert_bee",
      "traits": {
        "random_stats": true,
        "honeycomb_production_rate": 0.6,
        "lifespan": "medium",
        "night_work": false,
        "fertility": "medium",
        "preferred_biome": "desert",
        "aggressive": true
      },
      "comb": {
        "name": "sandy_comb",
        "texture": "textures/item/sandy_comb.png"
      },
      "hive": "desert_hive"
    },
    {
      "name": "meadows_bee",
      "parents": ["forest_bee", "plains_bee"],
      "crossbreed_chance": 75,
      "traits": {
        "honeycomb_production_rate": 0.75,
        "lifespan": "medium",
        "night_work": false,
        "fertility": "medium"
      },
      "hive": "meadows_hive"
    },
    {
      "name": "diamond_bee",
      "parents": ["emerald_bee", "rock_bee"],
      "crossbreed_chance": 2,
      "traits": {
        "honeycomb_production_rate": 0.3,
        "lifespan": "medium",
        "night_work": false,
        "fertility": "low"
      },
      "comb": {
        "name": "diamond_comb",
        "texture": "textures/item/diamond_comb.png"
      },
      "hive": "rock_hive"
    },
    {
      "name": "stone_bee",
      "parents": ["rock_bee", "rock_bee"],
      "crossbreed_chance": 14,
      "traits": {
        "honeycomb_production_rate": 0.5,
        "lifespan": "long",
        "night_work": false,
        "fertility": "medium"
      },
      "comb": {
        "name": "stony_comb",
        "texture": "textures/item/stony_comb.png",
        "output": "minecraft:stone"
      },
      "hive": "rock_hive"
    }
  ]
And this

{
  "name": "Natural Power Solar Panel",
  "type": "block",
  "function": "generate_power",
  "power_generation": 10,
  "energy_type": "Natural Power",
  "description": "Generates Natural Power. Only works during the day, produces half the energy if it's raining.",
  "model": {
    "texture": {
      "side": "textures/block/solar_side.png",
      "top": "textures/block/solar_top.png",
      "bottom": "textures/block/solar_bottom.png"
    },
    "elements": [
      {
        "from": [0, 0, 0],
        "to": [16, 4, 16],
        "faces": {
          "north": {"uv": [0, 12, 16, 16], "texture": "#side"},
          "east": {"uv": [0, 12, 16, 16], "texture": "#side"},
          "south": {"uv": [0, 12, 16, 16], "texture": "#side"},
          "west": {"uv": [0, 12, 16, 16], "texture": "#side"},
          "up": {"uv": [0, 0, 16, 16], "texture": "#top"},
          "down": {"uv": [0, 0, 16, 16], "texture": "#bottom"}
        }
And this

{
  "name": "BeeFarming",
  "version": "1.9.1",
  "description": "Advanced bee breeding with DNA manipulation, cloning, crossbreeding, biome-specific bees, and comb production. This version includes enhanced breeding mechanics, new crossbreeds, added effects, natural bee spawning, and honey bottle crafting recipes. Bees now naturally build hives, and hives can be harvested using a Scoop tool to keep bees peaceful. Updated hive textures and models for snowy, desert, swamp, forest, meadows, and jungle hives, and added new desert and swamp bee behaviors. Added 50 new crossbreeds, including advanced crossbreeds like the Silk Bee. Introduced new Natural Power energy system, solar panels, power cables, and Natural Power machines like the Centrifuge and Furnace.",
  "items": [
    {
      "name": "Beealizer",
      "type": "tool",
      "function": "view_bee_stats",
      "texture": "textures/item/beealizer.png"
    },
    {
      "name": "Scoop",
      "type": "tool",
      "function": "harvest_hive",
      "drops_hive_block": true,
      "releases_bees_on_drop": true,
      "texture": "textures/item/scoop.png",
      "recipe": {
        "pattern": [
          " W ",
          "WSW",
          " W "
        ],
        "key": {
          "W": "minecraft:wool",
          "S": "minecraft:stick"
        }
      },
      "random_bee_stats_on_harvest": true
    },
    {
      "name": "comb_storage_chest",
      "type": "chest",
      "texture": "textures/block/chest.png",
      "function": "store_honeycombs",
      "inventory_slots": 54,
      "pages": 100
    },
    {
      "name": "honey_bottle",
      "type": "food",
      "texture": "textures/item/honey_bottle.png",
      "function": "restore_hunger",
      "recipe": {
        "comb_recipes": [
          {
            "comb": "forest_comb",
            "output": "honey_bottle"
          },
          {
            "comb": "plains_comb",
            "output": "honey_bottle"
          },
          {
            "comb": "frost_comb",
            "output": "honey_bottle"
          },
          {
            "comb": "shadow_comb",
            "output": "honey_bottle"
          },
          {
            "comb": "sunburst_comb",
            "output": "honey_bottle"
          },
          {
            "comb": "nightshade_comb",
            "output": "honey_bottle"
          },
          {
            "comb": "rock_comb",
            "output": "honey_bottle"
          },
          {
            "comb": "sandy_comb",
            "output": "honey_bottle",
            "drops": {
              "white_sand": 100
            }
          },
          {
            "comb": "slime_comb",
            "output": "minecraft:slime_ball"
          },
          {
            "comb": "jungle_comb",
            "output": "minecraft:cocoa_beans"
          },
          {
            "comb": "diamond_comb",
            "output": "minecraft:diamond"
          },
          {
            "comb": "stony_comb",
            "output": "minecraft:stone"
          },
          {
            "comb": "deepslate_comb",
            "output": "minecraft:deepslate"
          }
        ]
      }
    },
    {
      "name": "grafter",
      "type": "tool",
      "function": "increase_sapling_drop_rate",
      "durability": 7,
      "texture": "textures/item/grafter.png",
      "description": "Makes leaves drop saplings 100% of the time. Can be enchanted with Mending and Unbreaking."
    },
    {
      "name": "proven_grafter",
      "type": "tool",
      "function": "increase_sapling_drop_rate",
      "durability": 17,
      "texture": "textures/item/proven_grafter.png",
      "description": "Makes leaves drop saplings 100% of the time. Proven grafter has enhanced durability. Can be enchanted with Mending and Unbreaking."
    },
    {
      "name": "Natural Power Solar Panel",
      "type": "block",
      "function": "generate_power",
      "power_generation": 10,
      "energy_type": "Natural Power",
      "description": "Generates Natural Power. Only works during the day, produces half the energy if it's raining.",
      "texture": "textures/block/solar_panel.png",
      "item_texture": "textures/item/solar_panel.png"
    },
    {
      "name": "Natural Power Cable",
      "type": "block",
      "function": "transfer_power",
      "max_value": 20,
      "description": "Transfers Natural Power",
      "texture": "textures/block/natural_power_cable.png",
      "handheld_texture": "textures/item/natural_power_cable_handheld.png",
      "inventory_texture": "textures/item/natural_power_cable_inventory.png",
      "connectivity": "all_six_directions",
      "models": [
        "straight",
        "turn",
        "combined"
      ],
      "render_settings": {
        "glass_fiber": true,
        "tint": "#FFFF00B3"
      },
      "recipe": {
        "pattern": [
          " G ",
          "S S",
          " G "
        ],
        "key": {
          "G": "minecraft:glowstone_dust",
          "S": "minecraft:string"
        },
        "output": 16
      }
    },
    {
      "name": "Upgraded Natural Power Cable",
      "type": "block",
      "function": "transfer_power",
      "max_value": 40,
      "description": "Transfers Natural Power",
      "texture": "textures/block/upgraded_natural_power_cable.png"
    },
    {
      "name": "Natural Power Furnace",
      "type": "block",
      "function": "smelt",
      "power_consumption": 80,
      "energy_type": "Natural Power",
      "description": "Consumes 80 Natural Power per second while smelting. Only uses power when actively smelting.",
      "texture": "textures/block/natural_power_furnace.png"
    },
    {
      "name": "Centrifuge",
      "type": "block",
      "function": "process_comb",
      "processing_time": 8,
      "power_consumption": 40,
      "energy_type": "Natural Power",
      "description": "Turns comb into items. Requires 40 Natural Power per second.",
      "texture": "textures/block/centrifuge.png"
    }
  ],
  "bees": [
    {
      "name": "snowy_bee",
      "traits": {
        "random_stats": true,
        "honeycomb_production_rate": 0.5,
        "lifespan": "long",
        "night_work": false,
        "fertility": "high",
        "preferred_biome": "snowy"
      },
      "hive": "snowy_hive"
    },
    {
      "name": "forest_bee",
      "traits": {
        "random_stats": true,
        "honeycomb_production_rate": 0.7,
        "lifespan": "medium",
        "night_work": true,
        "fertility": "high",
        "preferred_biome": "forest"
      },
      "comb": {
        "name": "forest_comb",
        "texture": "textures/item/forest_comb.png"
      },
      "hive": "meadows_hive"
    },
    {
      "name": "plains_bee",
      "traits": {
        "random_stats": true,
        "honeycomb_production_rate": 0.6,
        "lifespan": "medium",
        "night_work": false,
        "fertility": "high",
        "preferred_biome": "plains"
      },
      "comb": {
        "name": "plains_comb",
        "texture": "textures/item/plains_comb.png"
      },
      "hive": "meadows_hive"
    },
    {
      "name": "swamp_bee",
      "traits": {
        "random_stats": true,
        "honeycomb_production_rate": 0.5,
        "lifespan": "long",
        "night_work": false,
        "fertility": "high",
        "preferred_biome": "swamp",
        "poisonous": true
      },
      "comb": {
        "name": "slime_comb",
        "texture": "textures/item/slime_comb.png"
      },
      "hive": "swamp_hive"
    },
    {
      "name": "jungle_bee",
      "traits": {
        "random_stats": true,
        "honeycomb_production_rate": 0.8,
        "lifespan": "short",
        "night_work": true,
        "fertility": "low",
        "preferred_biome": "jungle",
        "aggressive": true
      },
      "comb": {
        "name": "jungle_comb",
        "texture": "textures/item/jungle_comb.png"
      },
      "hive": "jungle_hive"
    },
    {
      "name": "underground_bee",
      "traits": {
        "random_stats": true,
        "honeycomb_production_rate": 0.4,
        "lifespan": "long",
        "night_work": false,
        "fertility": "medium",
        "preferred_biome": "deepslate"
      },
      "comb": {
        "name": "rock_comb",
        "texture": "textures/item/rock_comb.png",
        "drops": {
          "stone": 97,
          "raw_ore": 2,
          "diamond_or_emerald": 1
        }
      },
      "hive": "underground_hive"
    },
    {
      "name": "desert_bee",
      "traits": {
        "random_stats": true,
        "honeycomb_production_rate": 0.6,
        "lifespan": "medium",
        "night_work": false,
        "fertility": "medium",
        "preferred_biome": "desert",
        "aggressive": true
      },
      "comb": {
        "name": "sandy_comb",
        "texture": "textures/item/sandy_comb.png"
      },
      "hive": "desert_hive"
    },
    {
      "name": "meadows_bee",
      "parents": ["forest_bee", "plains_bee"],
      "crossbreed_chance": 75,
      "traits": {
        "honeycomb_production_rate": 0.75,
        "lifespan": "medium",
        "night_work": false,
        "fertility": "medium"
      },
      "hive": "meadows_hive"
    },
    {
      "name": "diamond_bee",
      "parents": ["emerald_bee", "rock_bee"],
      "crossbreed_chance": 2,
      "traits": {
        "honeycomb_production_rate": 0.3,
        "lifespan": "medium",
        "night_work": false,
        "fertility": "low"
      },
      "comb": {
        "name": "diamond_comb",
        "texture": "textures/item/diamond_comb.png"
      },
      "hive": "rock_hive"
    },
    {
      "name": "stone_bee",
      "parents": ["rock_bee", "rock_bee"],
      "crossbreed_chance": 14,
      "traits": {
        "honeycomb_production_rate": 0.5,
        "lifespan": "long",
        "night_work": false,
        "fertility": "medium"
      },
      "comb": {
        "name": "stony_comb",
        "texture": "textures/item/stony_comb.png",
        "output": "minecraft:stone"
      },
      "hive": "rock_hive"
    }
  ]
}
And this

{
  "name": "BeeFarming",
  "version": "1.9.1",
  "description": "Advanced bee breeding with DNA manipulation, cloning, crossbreeding, biome-specific bees, and comb production. This version includes enhanced breeding mechanics, new crossbreeds, added effects, natural bee spawning, and honey bottle crafting recipes. Bees now naturally build hives, and hives can be harvested using a Scoop tool to keep bees peaceful. Updated hive textures and models for snowy, desert, swamp, forest, meadows, and jungle hives, and added new desert and swamp bee behaviors. Added 50 new crossbreeds, including advanced crossbreeds like the Silk Bee. Introduced new Natural Power energy system, solar panels, power cables, and Natural Power machines like the Centrifuge and Furnace.",
  "items": [
    {
      "name": "Beealizer",
      "type": "tool",
      "function": "view_bee_stats",
      "texture": "textures/item/beealizer.png"
    },
    {
      "name": "Scoop",
      "type": "tool",
      "function": "harvest_hive",
      "drops_hive_block": true,
      "releases_bees_on_drop": true,
      "texture": "textures/item/scoop.png",
      "recipe": {
        "pattern": [
          " W ",
          "WSW",
          " W "
        ],
        "key": {
          "W": "minecraft:wool",
          "S": "minecraft:stick"
        }
      },
      "random_bee_stats_on_harvest": true
    },
    {
      "name": "comb_storage_chest",
      "type": "chest",
      "texture": "textures/block/chest.png",
      "function": "store_honeycombs",
      "inventory_slots": 54,
      "pages": 100
    },
    {
      "name": "honey_bottle",
      "type": "food",
      "texture": "textures/item/honey_bottle.png",
      "function": "restore_hunger",
      "recipe": {
        "comb_recipes": [
          {
            "comb": "forest_comb",
            "output": "honey_bottle"
          },
          {
            "comb": "plains_comb",
            "output": "honey_bottle"
          },
          {
            "comb": "frost_comb",
            "output": "honey_bottle"
          },
          {
            "comb": "shadow_comb",
            "output": "honey_bottle"
          },
          {
            "comb": "sunburst_comb",
            "output": "honey_bottle"
          },
          {
            "comb": "nightshade_comb",
            "output": "honey_bottle"
          },
          {
            "comb": "rock_comb",
            "output": "honey_bottle"
          },
          {
            "comb": "sandy_comb",
            "output": "honey_bottle",
            "drops": {
              "white_sand": 100
            }
          },
          {
            "comb": "slime_comb",
            "output": "minecraft:slime_ball"
          },
          {
            "comb": "jungle_comb",
            "output": "minecraft:cocoa_beans"
          },
          {
            "comb": "diamond_comb",
            "output": "minecraft:diamond"
          },
          {
            "comb": "stony_comb",
            "output": "minecraft:stone"
          },
          {
            "comb": "deepslate_comb",
            "output": "minecraft:deepslate"
          }
        ]
      }
    },
    {
      "name": "grafter",
      "type": "tool",
      "function": "increase_sapling_drop_rate",
      "durability": 7,
      "texture": "textures/item/grafter.png",
      "description": "Makes leaves drop saplings 100% of the time. Can be enchanted with Mending and Unbreaking."
    },
    {
      "name": "proven_grafter",
      "type": "tool",
      "function": "increase_sapling_drop_rate",
      "durability": 17,
      "texture": "textures/item/proven_grafter.png",
      "description": "Makes leaves drop saplings 100% of the time. Proven grafter has enhanced durability. Can be enchanted with Mending and Unbreaking."
    },
    {
      "name": "Natural Power Solar Panel",
      "type": "block",
      "function": "generate_power",
      "power_generation": 10,
      "energy_type": "Natural Power",
      "description": "Generates Natural Power. Only works during the day, produces half the energy if it's raining.",
      "texture": "textures/block/solar_panel.png",
      "item_texture": "textures/item/solar_panel.png"
    },
    {
      "name": "Natural Power Cable",
      "type": "block",
      "function": "transfer_power",
      "max_value": 20,
      "description": "Transfers Natural Power",
      "texture": "textures/block/natural_power_cable.png",
      "handheld_texture": "textures/item/natural_power_cable_handheld.png",
      "inventory_texture": "textures/item/natural_power_cable_inventory.png",
      "connectivity": "all_six_directions",
      "models": [
        "straight",
        "turn",
        "combined"
      ],
      "render_settings": {
        "glass_fiber": true,
        "tint": "#FFFF00B3"
      },
      "recipe": {
        "pattern": [
          " G ",
          "S S",
          " G "
        ],
        "key": {
          "G": "minecraft:glowstone_dust",
          "S": "minecraft:string"
        },
        "output": 16
      }
    },
    {
      "name": "Upgraded Natural Power Cable",
      "type": "block",
      "function": "transfer_power",
      "max_value": 40,
      "description": "Transfers Natural Power",
      "texture": "textures/block/upgraded_natural_power_cable.png"
    },
    {
      "name": "Natural Power Furnace",
      "type": "block",
      "function": "smelt",
      "power_consumption": 80,
      "energy_type": "Natural Power",
      "description": "Consumes 80 Natural Power per second while smelting. Only uses power when actively smelting.",
      "texture": "textures/block/natural_power_furnace.png"
    },
    {
      "name": "Centrifuge",
      "type": "block",
      "function": "process_comb",
      "processing_time": 8,
      "power_consumption": 40,
      "energy_type": "Natural Power",
      "description": "Turns comb into items. Requires 40 Natural Power per second.",
      "texture": "textures/block/centrifuge.png"
    }
  ],
  "bees": [
    {
      "name": "snowy_bee",
      "traits": {
        "random_stats": true,
        "honeycomb_production_rate": 0.5,
        "lifespan": "long",
        "night_work": false,
        "fertility": "high",
        "preferred_biome": "snowy"
      },
      "hive": "snowy_hive"
    },
    {
      "name": "forest_bee",
      "traits": {
        "random_stats": true,
        "honeycomb_production_rate": 0.7,
        "lifespan": "medium",
        "night_work": true,
        "fertility": "high",
        "preferred_biome": "forest"
      },
      "comb": {
        "name": "forest_comb",
        "texture": "textures/item/forest_comb.png"
      },
      "hive": "meadows_hive"
    },
    {
      "name": "plains_bee",
      "traits": {
        "random_stats": true,
        "honeycomb_production_rate": 0.6,
        "lifespan": "medium",
        "night_work": false,
        "fertility": "high",
        "preferred_biome": "plains"
      },
      "comb": {
        "name": "plains_comb",
        "texture": "textures/item/plains_comb.png"
      },
      "hive": "meadows_hive"
    },
    {
      "name": "swamp_bee",
      "traits": {
        "random_stats": true,
        "honeycomb_production_rate": 0.5,
        "lifespan": "long",
        "night_work": false,
        "fertility": "high",
        "preferred_biome": "swamp",
        "poisonous": true
      },
      "comb": {
        "name": "slime_comb",
        "texture": "textures/item/slime_comb.png"
      },
      "hive": "swamp_hive"
    },
    {
      "name": "jungle_bee",
      "traits": {
        "random_stats": true,
        "honeycomb_production_rate": 0.8,
        "lifespan": "short",
        "night_work": true,
        "fertility": "low",
        "preferred_biome": "jungle",
        "aggressive": true
      },
      "comb": {
        "name": "jungle_comb",
        "texture": "textures/item/jungle_comb.png"
      },
      "hive": "jungle_hive"
    },
    {
      "name": "underground_bee",
      "traits": {
        "random_stats": true,
        "honeycomb_production_rate": 0.4,
        "lifespan": "long",
        "night_work": false,
        "fertility": "medium",
        "preferred_biome": "deepslate"
      },
      "comb": {
        "name": "rock_comb",
        "texture": "textures/item/rock_comb.png",
        "drops": {
          "stone": 97,
          "raw_ore": 2,
          "diamond_or_emerald": 1
        }
      },
      "hive": "underground_hive"
    },
    {
      "name": "desert_bee",
      "traits": {
        "random_stats": true,
        "honeycomb_production_rate": 0.6,
        "lifespan": "medium",
        "night_work": false,
        "fertility": "medium",
        "preferred_biome": "desert",
        "aggressive": true
      },
      "comb": {
        "name": "sandy_comb",
        "texture": "textures/item/sandy_comb.png"
      },
      "hive": "desert_hive"
    },
    {
      "name": "meadows_bee",
      "parents": ["forest_bee", "plains_bee"],
      "crossbreed_chance": 75,
      "traits": {
        "honeycomb_production_rate": 0.75,
        "lifespan": "medium",
        "night_work": false,
        "fertility": "medium"
      },
      "hive": "meadows_hive"
    },
    {
      "name": "diamond_bee",
      "parents": ["emerald_bee", "rock_bee"],
      "crossbreed_chance": 2,
      "traits": {
        "honeycomb_production_rate": 0.3,
        "lifespan": "medium",
        "night_work": false,
        "fertility": "low"
      },
      "comb": {
        "name": "diamond_comb",
        "texture": "textures/item/diamond_comb.png"
      },
      "hive": "rock_hive"
    },
    {
      "name": "stone_bee",
      "parents": ["rock_bee", "rock_bee"],
      "crossbreed_chance": 14,
      "traits": {
        "honeycomb_production_rate": 0.5,
        "lifespan": "long",
        "night_work": false,
        "fertility": "medium"
      },
      "comb": {
        "name": "stony_comb",
        "texture": "textures/item/stony_comb.png",
        "output": "minecraft:stone"
      },
      "hive": "rock_hive"
    }
  ]
}

      }
    ]
  }
}

"bees": [
    {
      "name": "snowy_bee",
      "traits": {
        "random_stats": true,
        "honeycomb_production_rate": 0.5,
        "lifespan": "long",
        "night_work": false,
        "fertility": "high",
        "preferred_biome": "snowy"
      },
      "hive": "snowy_hive"
    },
    {
      "name": "forest_bee",
      "traits": {
        "random_stats": true,
        "honeycomb_production_rate": 0.7,
        "lifespan": "medium",
        "night_work": true,
        "fertility": "high",
        "preferred_biome": "forest"
      },
      "comb": {
        "name": "forest_comb",
        "texture": "textures/item/forest_comb.png"
      },
      "hive": "forest_hive"
    },
    {
      "name": "plains_bee",
      "traits": {
        "random_stats": true,
        "honeycomb_production_rate": 0.6,
        "lifespan": "medium",
        "night_work": false,
        "fertility": "high",
        "preferred_biome": "plains"
      },
      "comb": {
        "name": "plains_comb",
        "texture": "textures/item/plains_comb.png"
      },
      "hive": "meadows_hive"
    },
    {
      "name": "swamp_bee",
      "traits": {
        "random_stats": true,
        "honeycomb_production_rate": 0.5,
        "lifespan": "long",
        "night_work": false,
        "fertility": "high",
        "preferred_biome": "swamp",
        "poisonous": true
      },
      "comb": {
        "name": "slime_comb",
        "texture": "textures/item/slime_comb.png"
      },
      "hive": "swamp_hive"
    },
    {
      "name": "jungle_bee",
      "traits": {
        "random_stats": true,
        "honeycomb_production_rate": 0.8,
        "lifespan": "short",
        "night_work": true,
        "fertility": "low",
        "preferred_biome": "jungle",
        "aggressive": true
      },
      "comb": {
        "name": "jungle_comb",
        "texture": "textures/item/jungle_comb.png"
      },
      "hive": "jungle_hive"
    },
    {
      "name": "underground_bee",
      "traits": {
        "random_stats": true,
        "honeycomb_production_rate": 0.4,
        "lifespan": "long",
        "night_work": false,
        "fertility": "medium",
        "preferred_biome": "deepslate"
      },
      "comb": {
        "name": "rock_comb",
        "texture": "textures/item/rock_comb.png",
        "drops": {
          "stone": 97,
          "raw_ore": 2,
          "diamond_or_emerald": 1
        }
      },
      "hive": "underground_hive"
    },
    {
      "name": "desert_bee",
      "traits": {
        "random_stats": true,
        "honeycomb_production_rate": 0.6,
        "lifespan": "medium",
        "night_work": false,
        "fertility": "medium",
        "preferred_biome": "desert",
        "aggressive": true
      },
      "comb": {
        "name": "sandy_comb",
        "texture": "textures/item/sandy_comb.png"
      },
      "hive": "desert_hive"
    },
    {
      "name": "meadows_bee",
      "parents": ["forest_bee", "plains_bee"],
      "crossbreed_chance": 75,
      "traits": {
        "honeycomb_production_rate": 0.75,
        "lifespan": "medium",
        "night_work": false,
        "fertility": "medium"
      },
      "hive": "meadows_hive"
    },
    {
      "name": "diamond_bee",
      "parents": ["emerald_bee", "rock_bee"],
      "crossbreed_chance": 2,
      "traits": {
        "honeycomb_production_rate": 0.3,
        "lifespan": "medium",
        "night_work": false,
        "fertility": "low"
      },
      "comb": {
        "name": "diamond_comb",
        "texture": "textures/item/diamond_comb.png"
      },
      "hive": "rock_hive"
    },
    {
      "name": "stone_bee",
      "parents": ["rock_bee", "rock_bee"],
      "crossbreed_chance": 14,
      "traits": {
        "honeycomb_production_rate": 0.5,
        "lifespan": "long",
        "night_work": false,
        "fertility": "medium"
      },
      "comb": {
        "name": "stony_comb",
        "texture": "textures/item/stony_comb.png",
        "output": "minecraft:stone"
      },
      "hive": "rock_hive"
    }
  ]
And this

{
  "name": "BeeFarming",
  "version": "1.9.1",
  "description": "Advanced bee breeding with DNA manipulation, cloning, crossbreeding, biome-specific bees, and comb production. This version includes enhanced breeding mechanics, new crossbreeds, added effects, natural bee spawning, and honey bottle crafting recipes. Bees now naturally build hives, and hives can be harvested using a Scoop tool to keep bees peaceful. Updated hive textures and models for snowy, desert, swamp, forest, meadows, and jungle hives, and added new desert and swamp bee behaviors. Added 50 new crossbreeds, including advanced crossbreeds like the Silk Bee. Introduced new Natural Power energy system, solar panels, power cables, and Natural Power machines like the Centrifuge and Furnace.",
  "items": [
    {
      "name": "Beealizer",
      "type": "tool",
      "function": "view_bee_stats",
      "texture": "textures/item/beealizer.png"
    },
    {
      "name": "Scoop",
      "type": "tool",
      "function": "harvest_hive",
      "drops_hive_block": true,
      "releases_bees_on_drop": true,
      "texture": "textures/item/scoop.png",
      "recipe": {
        "pattern": [
          " W ",
          "WSW",
          " W "
        ],
        "key": {
          "W": "minecraft:wool",
          "S": "minecraft:stick"
        }
      },
      "random_bee_stats_on_harvest": true
    },
    {
      "name": "comb_storage_chest",
      "type": "chest",
      "texture": "textures/block/chest.png",
      "function": "store_honeycombs",
      "inventory_slots": 54,
      "pages": 100
    },
    {
      "name": "honey_bottle",
      "type": "food",
      "texture": "textures/item/honey_bottle.png",
      "function": "restore_hunger",
      "recipe": {
        "comb_recipes": [
          {
            "comb": "forest_comb",
            "output": "honey_bottle"
          },
          {
            "comb": "plains_comb",
            "output": "honey_bottle"
          },
          {
            "comb": "frost_comb",
            "output": "honey_bottle"
          },
          {
            "comb": "shadow_comb",
            "output": "honey_bottle"
          },
          {
            "comb": "sunburst_comb",
            "output": "honey_bottle"
          },
          {
            "comb": "nightshade_comb",
            "output": "honey_bottle"
          },
          {
            "comb": "rock_comb",
            "output": "honey_bottle"
          },
          {
            "comb": "sandy_comb",
            "output": "honey_bottle",
            "drops": {
              "white_sand": 100
            }
          },
          {
            "comb": "slime_comb",
            "output": "minecraft:slime_ball"
          },
          {
            "comb": "jungle_comb",
            "output": "minecraft:cocoa_beans"
          },
          {
            "comb": "diamond_comb",
            "output": "minecraft:diamond"
          },
          {
            "comb": "stony_comb",
            "output": "minecraft:stone"
          },
          {
            "comb": "deepslate_comb",
            "output": "minecraft:deepslate"
          }
        ]
      }
    },
    {
      "name": "grafter",
      "type": "tool",
      "function": "increase_sapling_drop_rate",
      "durability": 7,
      "texture": "textures/item/grafter.png",
      "description": "Makes leaves drop saplings 100% of the time. Can be enchanted with Mending and Unbreaking."
    },
    {
      "name": "proven_grafter",
      "type": "tool",
      "function": "increase_sapling_drop_rate",
      "durability": 17,
      "texture": "textures/item/proven_grafter.png",
      "description": "Makes leaves drop saplings 100% of the time. Proven grafter has enhanced durability. Can be enchanted with Mending and Unbreaking."
    },
    {
      "name": "Natural Power Solar Panel",
      "type": "block",
      "function": "generate_power",
      "power_generation": 10,
      "energy_type": "Natural Power",
      "description": "Generates Natural Power. Only works during the day, produces half the energy if it's raining.",
      "texture": "textures/block/solar_panel.png",
      "item_texture": "textures/item/solar_panel.png"
    },
    {
      "name": "Natural Power Cable",
      "type": "block",
      "function": "transfer_power",
      "max_value": 20,
      "description": "Transfers Natural Power",
      "texture": "textures/block/natural_power_cable.png",
      "handheld_texture": "textures/item/natural_power_cable_handheld.png",
      "inventory_texture": "textures/item/natural_power_cable_inventory.png",
      "connectivity": "all_six_directions",
      "models": [
        "straight",
        "turn",
        "combined"
      ],
      "render_settings": {
        "glass_fiber": true,
        "tint": "#FFFF00B3"
      },
      "recipe": {
        "pattern": [
          " G ",
          "S S",
          " G "
        ],
        "key": {
          "G": "minecraft:glowstone_dust",
          "S": "minecraft:string"
        },
        "output": 16
      }
    },
    {
      "name": "Upgraded Natural Power Cable",
      "type": "block",
      "function": "transfer_power",
      "max_value": 40,
      "description": "Transfers Natural Power",
      "texture": "textures/block/upgraded_natural_power_cable.png"
    },
    {
      "name": "Natural Power Furnace",
      "type": "block",
      "function": "smelt",
      "power_consumption": 80,
      "energy_type": "Natural Power",
      "description": "Consumes 80 Natural Power per second while smelting. Only uses power when actively smelting.",
      "texture": "textures/block/natural_power_furnace.png"
    },
    {
      "name": "Centrifuge",
      "type": "block",
      "function": "process_comb",
      "processing_time": 8,
      "power_consumption": 40,
      "energy_type": "Natural Power",
      "description": "Turns comb into items. Requires 40 Natural Power per second.",
      "texture": "textures/block/centrifuge.png"
    }
  ],
  "bees": [
    {
      "name": "snowy_bee",
      "traits": {
        "random_stats": true,
        "honeycomb_production_rate": 0.5,
        "lifespan": "long",
        "night_work": false,
        "fertility": "high",
        "preferred_biome": "snowy"
      },
      "hive": "snowy_hive"
    },
    {
      "name": "forest_bee",
      "traits": {
        "random_stats": true,
        "honeycomb_production_rate": 0.7,
        "lifespan": "medium",
        "night_work": true,
        "fertility": "high",
        "preferred_biome": "forest"
      },
      "comb": {
        "name": "forest_comb",
        "texture": "textures/item/forest_comb.png"
      },
      "hive": "meadows_hive"
    },
    {
      "name": "plains_bee",
      "traits": {
        "random_stats": true,
        "honeycomb_production_rate": 0.6,
        "lifespan": "medium",
        "night_work": false,
        "fertility": "high",
        "preferred_biome": "plains"
      },
      "comb": {
        "name": "plains_comb",
        "texture": "textures/item/plains_comb.png"
      },
      "hive": "meadows_hive"
    },
    {
      "name": "swamp_bee",
      "traits": {
        "random_stats": true,
        "honeycomb_production_rate": 0.5,
        "lifespan": "long",
        "night_work": false,
        "fertility": "high",
        "preferred_biome": "swamp",
        "poisonous": true
      },
      "comb": {
        "name": "slime_comb",
        "texture": "textures/item/slime_comb.png"
      },
      "hive": "swamp_hive"
    },
    {
      "name": "jungle_bee",
      "traits": {
        "random_stats": true,
        "honeycomb_production_rate": 0.8,
        "lifespan": "short",
        "night_work": true,
        "fertility": "low",
        "preferred_biome": "jungle",
        "aggressive": true
      },
      "comb": {
        "name": "jungle_comb",
        "texture": "textures/item/jungle_comb.png"
      },
      "hive": "jungle_hive"
    },
    {
      "name": "underground_bee",
      "traits": {
        "random_stats": true,
        "honeycomb_production_rate": 0.4,
        "lifespan": "long",
        "night_work": false,
        "fertility": "medium",
        "preferred_biome": "deepslate"
      },
      "comb": {
        "name": "rock_comb",
        "texture": "textures/item/rock_comb.png",
        "drops": {
          "stone": 97,
          "raw_ore": 2,
          "diamond_or_emerald": 1
        }
      },
      "hive": "underground_hive"
    },
    {
      "name": "desert_bee",
      "traits": {
        "random_stats": true,
        "honeycomb_production_rate": 0.6,
        "lifespan": "medium",
        "night_work": false,
        "fertility": "medium",
        "preferred_biome": "desert",
        "aggressive": true
      },
      "comb": {
        "name": "sandy_comb",
        "texture": "textures/item/sandy_comb.png"
      },
      "hive": "desert_hive"
    },
    {
      "name": "meadows_bee",
      "parents": ["forest_bee", "plains_bee"],
      "crossbreed_chance": 75,
      "traits": {
        "honeycomb_production_rate": 0.75,
        "lifespan": "medium",
        "night_work": false,
        "fertility": "medium"
      },
      "hive": "meadows_hive"
    },
    {
      "name": "diamond_bee",
      "parents": ["emerald_bee", "rock_bee"],
      "crossbreed_chance": 2,
      "traits": {
        "honeycomb_production_rate": 0.3,
        "lifespan": "medium",
        "night_work": false,
        "fertility": "low"
      },
      "comb": {
        "name": "diamond_comb",
        "texture": "textures/item/diamond_comb.png"
      },
      "hive": "rock_hive"
    },
    {
      "name": "stone_bee",
      "parents": ["rock_bee", "rock_bee"],
      "crossbreed_chance": 14,
      "traits": {
        "honeycomb_production_rate": 0.5,
        "lifespan": "long",
        "night_work": false,
        "fertility": "medium"
      },
      "comb": {
        "name": "stony_comb",
        "texture": "textures/item/stony_comb.png",
        "output": "minecraft:stone"
      },
      "hive": "rock_hive"
    }
  ]
}
And add a sand and sandstone type just like red sandstone except rename red to white

And add a sand and sandstone type just like red sandstone except rename red to soul