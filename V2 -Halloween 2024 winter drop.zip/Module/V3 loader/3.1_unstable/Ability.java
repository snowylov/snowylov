public interface Ability {
    void activate(ServerPlayerEntity player);
    boolean canActivate(ServerPlayerEntity player);
}