{
    "pack": {
        "pack_format": 6,
        "description": "main Resource Pack for stone chests! HEYO"
    }
}