package com.example.pumpkinresizemod;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.minecraft.block.Block;
import net.minecraft.block.Material;
import net.minecraft.block.PumpkinBlock;
import net.minecraft.block.ShapeContext;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ShearsItem;
import net.minecraft.item.Items;
import net.minecraft.recipe.*;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.state.property.Properties;
import net.minecraft.text.Text;
import net.minecraft.util.*;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.registry.Registry;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.World;
import net.minecraft.server.world.ServerWorld;

import java.util.HashMap;
import java.util.Map;

public class PumpkinResizeMod implements ModInitializer {

    public static final String MOD_ID = "pumpkinresizemod";

    // Define the sizes
    private static final int[] SIZES = {2, 4, 6, 8, 10, 12, 14};

    // Maps to hold blocks based on type and size
    private final Map<Integer, Block> regularPumpkins = new HashMap<>();
    private final Map<Integer, Block> carvedPumpkins = new HashMap<>();
    private final Map<Integer, Block> jackOLanterns = new HashMap<>();

    @Override
    public void onInitialize() {
        // Initialize and register all blocks
        for (int size : SIZES) {
            // Create and register Regular Pumpkins
            Block regularPumpkin = createRegularPumpkin(size);
            regularPumpkins.put(size, regularPumpkin);
            registerBlock("regular_pumpkin_" + size + "x" + size, regularPumpkin);

            // Create and register Carved Pumpkins
            Block carvedPumpkin = createCarvedPumpkin(size);
            carvedPumpkins.put(size, carvedPumpkin);
            registerBlock("carved_pumpkin_" + size + "x" + size, carvedPumpkin);

            // Create and register Jack-O’-Lanterns
            Block jackOLantern = createJackOLantern(size);
            jackOLanterns.put(size, jackOLantern);
            registerBlock("jack_o_lantern_" + size + "x" + size, jackOLantern);
        }

        // Register crafting recipes programmatically
        registerAllRecipes();

        // Register the /pumpkin command
        registerPumpkinCommand();

        // Register Shears Interaction Callback
        registerShearsInteraction();
    }

    /**
     * Creates a Regular Pumpkin block.
     *
     * @param size The size of the pumpkin.
     * @return The Regular Pumpkin block.
     */
    private Block createRegularPumpkin(int size) {
        return new PumpkinBlock(FabricBlockSettings.of(Material.GOURD)
                .luminance(state -> 0) // No light emitted
                .strength(1.0F)
                .sounds(BlockSoundGroup.WOOD)
                .nonOpaque()) {
            @Override
            public VoxelShape getOutlineShape(BlockState state, World world, BlockPos pos, ShapeContext context) {
                return createVoxelShape(size);
            }
        };
    }

    /**
     * Creates a Carved Pumpkin block.
     *
     * @param size The size of the pumpkin.
     * @return The Carved Pumpkin block.
     */
    private Block createCarvedPumpkin(int size) {
        return new PumpkinBlock(FabricBlockSettings.of(Material.GOURD)
                .luminance(state -> 10) // Emit light, adjust as needed
                .strength(1.0F)
                .sounds(BlockSoundGroup.WOOD)
                .nonOpaque()) {
            @Override
            public VoxelShape getOutlineShape(BlockState state, World world, BlockPos pos, ShapeContext context) {
                return createVoxelShape(size);
            }
        };
    }

    /**
     * Creates a Jack-O’-Lantern block.
     *
     * @param size The size of the Jack-O’-Lantern.
     * @return The Jack-O’-Lantern block.
     */
    private Block createJackOLantern(int size) {
        return new PumpkinBlock(FabricBlockSettings.of(Material.GOURD)
                .luminance(state -> 15) // Maximum light emission
                .strength(1.0F)
                .sounds(BlockSoundGroup.WOOD)
                .nonOpaque()) {
            @Override
            public VoxelShape getOutlineShape(BlockState state, World world, BlockPos pos, ShapeContext context) {
                return createVoxelShape(size);
            }
        };
    }

    /**
     * Creates a voxel shape based on the pumpkin size.
     *
     * @param size The size of the pumpkin.
     * @return The voxel shape.
     */
    private VoxelShape createVoxelShape(int size) {
        double offset = (16 - size) / 32.0;  // Centering offset
        return VoxelShapes.cuboid(offset, 0, offset, 1.0 - offset, (double) size / 16.0, 1.0 - offset);
    }

    /**
     * Registers a block and its corresponding item.
     *
     * @param id    The identifier for the block.
     * @param block The block to register.
     */
    private void registerBlock(String id, Block block) {
        Identifier blockId = new Identifier(MOD_ID, id);
        Registry.register(Registry.BLOCK, blockId, block);
        Registry.register(Registry.ITEM, blockId, new BlockItem(block, new Item.Settings().group(ItemGroup.DECORATIONS)));
    }

    /**
     * Registers all crafting recipes programmatically.
     */
    private void registerAllRecipes() {
        for (int size : SIZES) {
            Block carvedPumpkin = carvedPumpkins.get(size);
            Block jackOLantern = jackOLanterns.get(size);

            // Define the recipe identifier
            Identifier recipeId = new Identifier(MOD_ID, "jack_o_lantern_" + size + "x" + size);

            // Create the shaped recipe
            ShapedRecipe recipe = new ShapedRecipe(
                    recipeId,
                    "", // Group
                    3, 3, // Width and height
                    // Pattern
                    createPattern(),
                    // Key
                    createKey(carvedPumpkin),
                    // Result
                    new ItemStack(jackOLantern)
            );

            // Register the recipe serializer
            Registry.register(Registry.RECIPE_SERIALIZER, recipeId, ShapedRecipe.Serializer.INSTANCE);

            // Register the recipe
            Registry.register(Registry.RECIPE_TYPE, recipeId, RecipeType.CRAFTING);
        }
    }

    /**
     * Creates the crafting pattern for Jack-O’-Lanterns.
     *
     * @return The pattern array.
     */
    private String[] createPattern() {
        return new String[]{" C ", " T ", "   "};
    }

    /**
     * Creates the key mapping for the crafting recipe.
     *
     * @param carvedPumpkin The carved pumpkin block used in the recipe.
     * @return The key mapping.
     */
    private Map<Character, Ingredient> createKey(Block carvedPumpkin) {
        Map<Character, Ingredient> key = new HashMap<>();
        key.put('C', Ingredient.ofItems(carvedPumpkin.asItem()));
        key.put('T', Ingredient.ofItems(Items.TORCH));
        return key;
    }

    /**
     * Registers the /pumpkin command.
     */
    private void registerPumpkinCommand() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(CommandManager.literal("pumpkin")
                    .then(CommandManager.argument("type", StringArgumentType.word())
                            .then(CommandManager.argument("size", IntegerArgumentType.integer(2, 14))
                                    .executes(context -> {
                                        String type = StringArgumentType.getString(context, "type").toLowerCase();
                                        int size = IntegerArgumentType.getInteger(context, "size");
                                        ServerCommandSource source = context.getSource();
                                        PlayerEntity player = source.getPlayer();

                                        if (player == null) {
                                            source.sendError(Text.literal("Only players can execute this command."));
                                            return 0;
                                        }

                                        Block blockToPlace = null;
                                        switch (type) {
                                            case "jackolantern":
                                                blockToPlace = jackOLanterns.get(size);
                                                break;
                                            case "carved":
                                                blockToPlace = carvedPumpkins.get(size);
                                                break;
                                            case "regular":
                                                blockToPlace = regularPumpkins.get(size);
                                                break;
                                            default:
                                                source.sendError(Text.literal("Unknown pumpkin type. Use jackolantern, carved, or regular."));
                                                return 0;
                                        }

                                        if (blockToPlace == null) {
                                            source.sendError(Text.literal("Invalid size for the specified pumpkin type."));
                                            return 0;
                                        }

                                        // Spawn the block at the player's position offset by their facing direction
                                        BlockPos playerPos = player.getBlockPos().offset(player.getHorizontalFacing(), 1);
                                        source.getWorld().setBlockState(playerPos, blockToPlace.getDefaultState());

                                        source.sendFeedback(Text.literal("Spawned " + type + " pumpkin of size " + size + "x" + size), true);
                                        return 1;
                                    })
                            )
                    )
            );
        });
    }

    /**
     * Registers the Shears interaction to transform Regular Pumpkins into Carved Pumpkins.
     */
    private void registerShearsInteraction() {
        UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
            ItemStack heldItem = player.getStackInHand(hand);
            if (!(heldItem.getItem() instanceof ShearsItem)) {
                return ActionResult.PASS;
            }

            BlockPos pos = hitResult.getBlockPos();
            BlockState state = world.getBlockState(pos);
            Block block = state.getBlock();

            // Check if the block is a Regular Pumpkin
            if (isRegularPumpkin(block)) {
                // Determine the size of the pumpkin
                int size = getPumpkinSize(block);
                if (size == -1) {
                    return ActionResult.PASS; // Unknown size
                }

                // Get the corresponding Carved Pumpkin block
                Block carvedPumpkin = carvedPumpkins.get(size);
                if (carvedPumpkin == null) {
                    return ActionResult.PASS;
                }

                if (!world.isClient()) {
                    // Replace the block with the Carved Pumpkin
                    world.setBlockState(pos, carvedPumpkin.getDefaultState());

                    // Drop 1-3 Pumpkin Seeds
                    Random random = world.getRandom();
                    int seedCount = random.nextBetween(1, 3);
                    dropItemStack(world, pos, new ItemStack(Items.PUMPKIN_SEEDS, seedCount));

                    // Play shearing sound
                    world.playSound(null, pos, SoundEvents.ENTITY_SHEEP_SHEAR, SoundCategory.BLOCKS, 1.0F, 1.0F);
                }

                return ActionResult.SUCCESS;
            }

            return ActionResult.PASS;
        });
    }

    /**
     * Checks if a block is a Regular Pumpkin.
     *
     * @param block The block to check.
     * @return True if it's a Regular Pumpkin, false otherwise.
     */
    private boolean isRegularPumpkin(Block block) {
        return regularPumpkins.containsValue(block);
    }

    /**
     * Retrieves the size of a pumpkin based on its block.
     *
     * @param block The pumpkin block.
     * @return The size, or -1 if unknown.
     */
    private int getPumpkinSize(Block block) {
        for (Map.Entry<Integer, Block> entry : regularPumpkins.entrySet()) {
            if (entry.getValue() == block) {
                return entry.getKey();
            }
        }
        return -1;
    }

    /**
     * Drops an ItemStack in the world at the specified position.
     *
     * @param world The world.
     * @param pos   The position.
     * @param stack The ItemStack to drop.
     */
    private void dropItemStack(World world, BlockPos pos, ItemStack stack) {
        if (world instanceof ServerWorld serverWorld) {
            ItemEntity itemEntity = new ItemEntity(serverWorld, pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5, stack);
            itemEntity.setToDefaultPickupDelay();
            serverWorld.spawnEntity(itemEntity);
        }
    }
}