package com.example.useful_features;

import com.jozufozu.flywheel.api.Flywheel;
import com.jozufozu.flywheel.api.animation.AnimationBuilder;
import com.jozufozu.flywheel.api.effects.EffectBuilder;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.tag.TagRegistry;
import net.minecraft.block.*;
import net.minecraft.block.enums.SlabType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.DyeItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.EnumProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.tag.Tag;
import net.minecraft.text.LiteralText;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.registry.Registry;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

public class UsefulFeaturesMod implements ModInitializer {

    public static final EnumProperty<SlabType> SLAB_TYPE = Properties.SLAB_TYPE;

    
    public static final Item REMOTE_ITEM = new Item(new FabricItemSettings().group(ItemGroup.MISC));

    @Override
    public void onInitialize() {
        register();
    }

    public static void register() {
                        Registry.register(Registry.ITEM, new Identifier("useful_features", "remote"), REMOTE_ITEM);
    }

                }
        }
    }

    @Mixin(Block.class)
    public static abstract class GlassLoggingMixin {

        @Inject(method = "onUse", at = @At("HEAD"), cancellable = true)
        private void onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, Hand hand, CallbackInfoReturnable<ActionResult> cir) {
            ItemStack heldItem = player.getStackInHand(hand);
            if (!world.isClient && (heldItem.getItem() == Items.GLASS || heldItem.getItem() == Items.GLASS_PANE || heldItem.getItem() == Items.IRON_BARS || heldItem.getItem() instanceof StainedGlassItem || heldItem.getItem() instanceof TintedGlassItem || heldItem.getItem() == Items.STAINED_GLASS_PANE)) {
                if (!state.get(Properties.WATERLOGGED)) {
                    world.setBlockState(pos, state.with(Properties.WATERLOGGED, true));
                    player.sendMessage(new LiteralText("Block successfully logged with glass or similar material!"), true);
                    cir.setReturnValue(ActionResult.SUCCESS);
                }
            }
        }
    }

    @Mixin(SlabBlock.class)
    public static abstract class MixedSlabMixin {
        @Inject(method = "getPlacementState", at = @At("HEAD"), cancellable = true)
        private void onGetPlacementState(PlayerEntity player, BlockPos pos, Hand hand, BlockState currentState, CallbackInfoReturnable<BlockState> cir) {
            ItemStack heldItem = player.getStackInHand(hand);
            BlockState blockState = player.world.getBlockState(pos);
            if (blockState.getBlock() instanceof SlabBlock && heldItem.getItem() instanceof BlockItem) {
                BlockItem blockItem = (BlockItem) heldItem.getItem();
                BlockState newState = blockItem.getBlock().getDefaultState();
                if (blockState.get(SLAB_TYPE) == SlabType.BOTTOM && newState.getBlock() instanceof SlabBlock) {
                    cir.setReturnValue(blockState.with(SLAB_TYPE, SlabType.DOUBLE).with(Properties.BLOCK_STATE, newState));
                }
            }
        }
    }

    @Mixin(Block.class)
    public static abstract class WallSlabCarpetMixin {
        @Inject(method = "canPlaceAt", at = @At("HEAD"), cancellable = true)
        private void onCanPlaceAt(BlockState state, World world, BlockPos pos, CallbackInfoReturnable<Boolean> cir) {
            if (state.getBlock() instanceof SlabBlock || state.getBlock() instanceof CarpetBlock) {
                Direction facing = Direction.fromVector(pos.getX(), pos.getY(), pos.getZ());
                if (facing != Direction.UP && facing != Direction.DOWN) {
                    cir.setReturnValue(true);
                }
            }
        }
    }

    @Mixin(TorchBlock.class)
    public static abstract class TorchCollisionMixin {
        @Inject(method = "getCollisionShape", at = @At("HEAD"), cancellable = true)
        private void onGetCollisionShape(BlockState state, World world, BlockPos pos, CallbackInfoReturnable<VoxelShape> cir) {
            if (world.getBlockState(pos).getBlock().isIn(NO_COLLISION_TAG)) {
                cir.setReturnValue(VoxelShapes.empty());
            }
        }
    }

    @Mixin(SlabBlock.class)
    public static abstract class VerticalSlabMixin {
        @Inject(method = "getPlacementState", at = @At("HEAD"), cancellable = true)
        private void onGetPlacementState(ItemPlacementContext context, CallbackInfoReturnable<BlockState> cir) {
            Direction direction = context.getSide();
            if (direction == Direction.NORTH || direction == Direction.SOUTH || direction == Direction.EAST || direction == Direction.WEST) {
                cir.setReturnValue(this.getDefaultState().with(Properties.SLAB_TYPE, SlabType.VERTICAL));
            }
        }

        @Inject(method = "onUse", at = @At("HEAD"), cancellable = true)
        private void onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, Hand hand, CallbackInfoReturnable<ActionResult> cir) {
            ItemStack heldItem = player.getStackInHand(hand);
            if (state.get(SLAB_TYPE) == SlabType.VERTICAL && heldItem.getItem() instanceof BlockItem) {
                BlockItem blockItem = (BlockItem) heldItem.getItem();
                if (blockItem.getBlock() instanceof SlabBlock) {
                    cir.setReturnValue(state.with(SLAB_TYPE, SlabType.DOUBLE));
                    Flywheel.initAnimation(new AnimationBuilder("vertical_slab_combine")
                        .add(state, world, pos)
                        .duration(500)
                        .addEffect(Flywheel.sparkleEffect()));
                }
            }
        }
    }

    @Mixin(StairsBlock.class)
    public static abstract class CornerStairsMixin {
        @Inject(method = "getPlacementState", at = @At("HEAD"), cancellable = true)
        private void onGetPlacementState(ItemPlacementContext context, CallbackInfoReturnable<BlockState> cir) {
            Direction direction = context.getPlayerFacing();
            if (context.getHitPos().distanceTo(Vec3d.ofCenter(context.getBlockPos())) < 0.5) {
                cir.setReturnValue(this.getDefaultState().with(Properties.HORIZONTAL_FACING, direction.rotateYClockwise()));
            }
        }
    }
}
