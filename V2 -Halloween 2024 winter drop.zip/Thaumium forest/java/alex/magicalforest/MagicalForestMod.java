package alex.magicalforest;

import com.google.common.collect.ImmutableList;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltinRegistries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.util.valueproviders.ConstantInt;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.BiomeGenerationSettings;
import net.minecraft.world.level.biome.BiomeSpecialEffects;
import net.minecraft.world.level.biome.MobSpawnSettings;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.GenerationStep;
import net.minecraft.world.level.levelgen.feature.ConfiguredFeature;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.configurations.TreeConfiguration;
import net.minecraft.world.level.levelgen.feature.featuresize.TwoLayersFeatureSize;
import net.minecraft.world.level.levelgen.feature.foliageplacers.FancyFoliagePlacer;
import net.minecraft.world.level.levelgen.feature.stateproviders.BlockStateProvider;
import net.minecraft.world.level.levelgen.feature.trunkplacers.FancyTrunkPlacer;
import net.minecraft.world.level.levelgen.placement.*;
import net.minecraft.data.worldgen.BiomeDefaultFeatures;
import net.minecraft.data.worldgen.features.FeatureUtils;
import net.minecraft.data.worldgen.placement.PlacementUtils;

import java.util.List;
import java.util.OptionalInt;

public class MagicalForestMod implements ModInitializer {

    // Color constants for biome visuals
    public static class ColorConstants {
        public static final int STANDARD_WATER = 0x3F76E4;
        public static final int STANDARD_WATERFOG = 0x050533;
        public static final int MAGICAL_FOREST_FOLIAGE_COLOR = 0x33FF68;
        public static final int MAGICAL_FOREST_GRASS_COLOR = 0x45F396;
        public static final int STANDARD_FOG = 0x7AABFA;
    }

    public static final ResourceKey<Biome> FANCY_OAK_FOREST = ResourceKey.create(
        BuiltinRegistries.BIOME.key(),
        new ResourceLocation("magicalforest", "fancy_oak_forest")
    );

    // Define the Fancy Oak Tree configuration
    private static TreeConfiguration.TreeConfigurationBuilder createFancyOak() {
        return new TreeConfiguration.TreeConfigurationBuilder(
            BlockStateProvider.simple(Blocks.OAK_LOG),
            new FancyTrunkPlacer(3, 11, 0),
            BlockStateProvider.simple(Blocks.OAK_LEAVES),
            new FancyFoliagePlacer(ConstantInt.of(2), ConstantInt.of(4), 4),
            new TwoLayersFeatureSize(0, 0, 0, OptionalInt.of(4))
        ).ignoreVines();
    }

    // Register the configured and placed Fancy Oak tree feature
    public static final Holder<ConfiguredFeature<TreeConfiguration, ?>> FANCY_OAK_TREES = FeatureUtils.register("trees_fancy_oak", Feature.TREE, createFancyOak().build());
    static final Holder<PlacedFeature> FANCY_OAK_TREES_FEATURE = PlacementUtils.register("trees_fancy_oak_feature", FANCY_OAK_TREES, treePlacement(PlacementUtils.countExtra(5, 0.1f, 1)));

    private static List<PlacementModifier> treePlacement(PlacementModifier placement) {
        return ImmutableList.of(
            placement,
            InSquarePlacement.spread(),
            SurfaceWaterDepthFilter.forMaxDepth(0),
            PlacementUtils.HEIGHTMAP_OCEAN_FLOOR,
            PlacementUtils.HEIGHTMAP_WORLD_SURFACE,
            PlacementUtils.HEIGHTMAP_TOP_SOLID,
            BiomeFilter.biome()
        );
    }

    // Add the Fancy Oak trees to the biome generation settings
    private static void addFancyOakTrees(BiomeGenerationSettings.Builder builder) {
        builder.addFeature(GenerationStep.Decoration.VEGETAL_DECORATION, FANCY_OAK_TREES_FEATURE);
    }

    // Calculate sky color based on temperature
    private static int getSkyColorWithTemperatureModifier(float temperature) {
        float f = temperature / 3.0F;
        f = Mth.clamp(f, -1.0F, 1.0F);
        return Mth.hsvToRgb(0.6325F - f * 0.1F, 0.44F + f * 0.11F, 1F);
    }

    // Create and configure the Fancy Oak Forest biome
    public static Biome createFancyOakForest() {
        BiomeGenerationSettings.Builder biomeFeatures = new BiomeGenerationSettings.Builder();

        BiomeDefaultFeatures.addDefaultCarversAndLakes(biomeFeatures);
        BiomeDefaultFeatures.addDefaultCrystalFormations(biomeFeatures);
        BiomeDefaultFeatures.addDefaultMonsterRoom(biomeFeatures);
        BiomeDefaultFeatures.addDefaultUndergroundVariety(biomeFeatures);
        BiomeDefaultFeatures.addDefaultSprings(biomeFeatures);
        BiomeDefaultFeatures.addSurfaceFreezing(biomeFeatures);
        BiomeDefaultFeatures.addDefaultOres(biomeFeatures);
        BiomeDefaultFeatures.addDefaultSoftDisks(biomeFeatures);
        BiomeDefaultFeatures.addForestFlowers(biomeFeatures);
        BiomeDefaultFeatures.addFerns(biomeFeatures);
        BiomeDefaultFeatures.addMossyStoneBlock(biomeFeatures);
        BiomeDefaultFeatures.addMushroomFieldVegetation(biomeFeatures);
        BiomeDefaultFeatures.addMeadowVegetation(biomeFeatures);
        BiomeDefaultFeatures.addDefaultMushrooms(biomeFeatures);
        BiomeDefaultFeatures.addDefaultExtraVegetation(biomeFeatures);
        BiomeDefaultFeatures.addCommonBerryBushes(biomeFeatures);
        BiomeDefaultFeatures.addJungleMelons(biomeFeatures);
        addFancyOakTrees(biomeFeatures);

        MobSpawnSettings.Builder spawnSettings = new MobSpawnSettings.Builder();
        BiomeDefaultFeatures.farmAnimals(spawnSettings);

        BiomeSpecialEffects.Builder specialEffects = new BiomeSpecialEffects.Builder()
            .fogColor(ColorConstants.STANDARD_FOG)
            .waterColor(ColorConstants.STANDARD_WATER)
            .waterFogColor(ColorConstants.STANDARD_WATERFOG)
            .foliageColorOverride(ColorConstants.MAGICAL_FOREST_FOLIAGE_COLOR)
            .grassColorOverride(ColorConstants.MAGICAL_FOREST_GRASS_COLOR)
            .skyColor(getSkyColorWithTemperatureModifier(0.5F));

        return new Biome.BiomeBuilder()
            .precipitation(Biome.Precipitation.RAIN)
            .temperature(0.5F)
            .downfall(0.7F)
            .specialEffects(specialEffects.build())
            .generationSettings(biomeFeatures.build())
            .mobSpawnSettings(spawnSettings.build())
            .build();
    }

    @Override
    public void onInitialize() {
        Registry.register(BuiltinRegistries.BIOME, FANCY_OAK_FOREST.location(), createFancyOakForest());

        BiomeModifications.addBiome(
            BiomeSelectors.foundInOverworld(),
            context -> context.getBiomeKey() == FANCY_OAK_FOREST
        );
    }
}